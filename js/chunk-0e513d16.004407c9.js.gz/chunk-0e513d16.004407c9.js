(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-0e513d16","chunk-25a2af2a","chunk-25a2af2a"],{

/***/ "62af":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "692a":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "7bd0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupportedImportDetails_vue_vue_type_style_index_0_id_051bf002_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("692a");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupportedImportDetails_vue_vue_type_style_index_0_id_051bf002_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SupportedImportDetails_vue_vue_type_style_index_0_id_051bf002_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "8d7e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModalTemplate_vue_vue_type_style_index_0_id_1c4e04a7_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("62af");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModalTemplate_vue_vue_type_style_index_0_id_1c4e04a7_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ModalTemplate_vue_vue_type_style_index_0_id_1c4e04a7_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "984b":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "aaa3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"66eac875-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/modalContent/SupportedImportDetails.vue?vue&type=template&id=051bf002
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('modal-template', {
    attrs: {
      "active": true
    }
  }, [_c('template', {
    slot: "modal-header"
  }, [_vm._v(" Supported Import Files & Formats ")]), _c('template', {
    slot: "modal-body"
  }, [_c('div', {
    staticClass: "tabs"
  }, [_c('ul', [_c('li', {
    class: [_vm.tab === 'csv' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'csv';
      }
    }
  }, [_vm._v(" CSV ")])]), !_vm.conceptMode && !_vm.progressionMode ? _c('li', {
    class: [_vm.tab === 'html' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'html';
      }
    }
  }, [_vm._v(" HTML ")])]) : _vm._e(), !_vm.conceptMode && !_vm.progressionMode ? _c('li', {
    class: [_vm.tab === 'xml' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'xml';
      }
    }
  }, [_vm._v(" XML ")])]) : _vm._e(), _c('li', {
    class: [_vm.tab === 'json' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'json';
      }
    }
  }, [_vm._v(" JSON ")])]), !_vm.conceptMode && !_vm.progressionMode ? _c('li', {
    class: [_vm.tab === 'pdf' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'pdf';
      }
    }
  }, [_vm._v(" PDF ")])]) : _vm._e(), !_vm.conceptMode && !_vm.progressionMode ? _c('li', {
    class: [_vm.tab === 'docx' ? 'is-active' : '', '']
  }, [_c('button', {
    on: {
      "click": function click($event) {
        _vm.newTab = 'docx';
      }
    }
  }, [_vm._v(" DOCX ")])]) : _vm._e()])]), _vm.tab === 'docx' ? _c('div', {
    staticClass: "section"
  }, [_c('h3', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" WORD/DOCX "), _c('span', {
    staticClass: "icon is-pulled-right has-text-warning has-text-link"
  }, [_c('i', {
    staticClass: "fa fa-exclamation-circle"
  })])]), _c('p', [_vm._v(" CaSS experimentally supports the import of frameworks in DOCX document formats. Because DOCX files come in many shapes and sizes there may be defects when importing frameworks. The import interface allows you to review and make changes to the detected framework before importing. ")]), false ? undefined : _vm._e()]) : _vm._e(), _vm.tab === 'html' ? _c('div', {
    staticClass: "section"
  }, [_c('h3', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" HTML "), _c('span', {
    staticClass: "icon is-pulled-right has-text-warning has-text-link"
  }, [_c('i', {
    staticClass: "fa fa-exclamation-circle"
  })])]), _c('p', [_vm._v(" CaSS experimentally supports the import of frameworks in HTML document formats. Because HTML files come in many shapes and sizes there may be defects when importing frameworks. The import interface allows you to review and make changes to the detected framework before importing. ")]), false ? undefined : _vm._e()]) : _vm._e(), _vm.tab === 'pdf' ? _c('div', {
    staticClass: "section"
  }, [_c('h3', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" PDF "), _c('span', {
    staticClass: "icon is-pulled-right has-text-warning has-text-link"
  }, [_c('i', {
    staticClass: "fa fa-exclamation-circle"
  })])]), _c('p', [_vm._v(" CaSS experimentally supports the import of frameworks in PDF document format. Because PDF files come in many shapes and sizes there may be deviances when importing frameworks. The import interface allows you to review and make changes to the detected framework before importing. ")]), false ? undefined : _vm._e()]) : _vm._e(), _vm.tab === 'csv' && !_vm.conceptMode && !_vm.progressionMode ? _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" CSV "), _c('span', {
    staticClass: "icon is-pulled-right has-text-success"
  }, [_c('i', {
    staticClass: "fa fa-check-circle"
  })])]), _c('p', [_vm._v(" CSV file imports are supported with CaSS. In order to upload competencies as CSV files, your framework CSV files need to be formatted in a CaSS readable format. ")]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" CaSS Formatted ")]), _c('p', [_vm._v(" For this import, you can use one or two CSVs. The first (required) CSV describes the competencies to include in a new framework. The second (optional) CSV describes the relations between the competencies found in the first framework. Each row in the first CSV will represent one competency, and each row in the second CSV will represent one relation between two competencies. The relations can be between competencies found in the first CSV, competencies found in other frameworks, or a mixture of the two. You can select the columns to use to describe the id, name, description, and other fields. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvExampleCompetenciesFile,
      "target": "_blank",
      "download": "CAP Software Engineering - Competencies.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Competencies Example")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvTemplateCompetenciesFile,
      "target": "_blank",
      "download": "Template - Competencies.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Competencies Template")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvExampleRelationsFile,
      "target": "_blank",
      "download": "CAP Software Engineering - Relations.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Relations Example")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvTemplateRelationsFile,
      "target": "_blank",
      "download": "Template - Relations.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Relations Template")])])]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" CTDL-ASN Formatted ")]), _c('p', [_vm._v(" For this import, you use one CSV. Each row in the CSV will represent one object, whether that be a competency, or a competency framework. Particular fields will be used to determine hierarchy. Using this format, you can import several frameworks, each with their own competencies. Competencies may not be shared across frameworks, and each competency may only have one parent. It is also important that the rows be sequenced correctly, with competency frameworks appearing before the competencies inside of them, and for a parent to be in a row above a child of that parent. Any field with multiple values must be formatted as entry 1|entry 2. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnCsvExampleFile,
      "target": "_blank",
      "download": "Example of a Mininum Data Competency Framework Upload - HIST 101, SURVEY OF AMERICAN HISTORY I.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example - Minimum")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnCsvTemplateFile,
      "target": "_blank",
      "download": "Template of a Mininum Data Competency Framework.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Template - Minimum")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnCsvBenchmarkExampleFile,
      "target": "_blank",
      "download": "Example of a Benchmark Competency Framework - DOLWorkCharacteristicsDownloadfromCaSSAug25_2021.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example - Benchmark")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnCsvBenchmarkTemplateFile,
      "target": "_blank",
      "download": "Template of a Benchmark Competency Framework.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Template - Benchmark")])])])]) : _vm._e(), _vm.tab === 'csv' && (_vm.conceptMode || _vm.progressionMode) ? _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" CSV "), _c('span', {
    staticClass: "icon is-pulled-right has-text-success"
  }, [_c('i', {
    staticClass: "fa fa-check-circle"
  })])]), _c('p', [_vm._v(" CSV file imports are supported with CaSS. In order to upload " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept schemes' : 'taxonomies') + " as CSV files your " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept scheme' : 'taxonomy') + " CSV files need to be formatted in a CaSS readable format. ")]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" CTDL-ASN Formatted ")]), _c('p', [_vm._v(" For this import, you use one CSV. Each row in the CSV will represent one object, whether that be a concept, or a " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept scheme' : 'taxonomy') + ". Particular fields will be used to determine hierarchy. Using this format, you can import several " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept schemes' : 'taxonomies') + ", each with their own concepts. Concepts may not be shared across " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'schemes' : 'taxonomies') + ", and each concept may only have one parent. It is also important that any field with multiple values be formatted exactly as in the sample file, e.g. entry 1|entry 2. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvConceptExampleFile,
      "target": "_blank",
      "download": "Concept Scheme Example.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example")])]), _c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.csvConceptTemplateFile,
      "target": "_blank",
      "download": "Concept Scheme Template.csv"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Template")])])])]) : _vm._e(), _vm.tab === 'xml' ? _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" XML "), _c('span', {
    staticClass: "icon is-pulled-right has-text-success"
  }, [_c('i', {
    staticClass: "fa fa-check-circle"
  })])]), _c('p', [_vm._v(" At this time CaSS supports XML imports in the Medbiquitous XML format. ")]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" Medbiquitous XML ")]), _c('p', [_vm._v(" Medbiquitous is a standards body that includes medical competencies as one of their XML based formats. Using this format, you can import competencies exported from a system that exports Medbiquitous formatted XML. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.medbiquitousFile,
      "target": "_blank",
      "download": "educational_achievement_sample_1June2012.xml"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v(" Example")])])])]) : _vm._e(), _vm.tab === 'json' && !_vm.conceptMode && !_vm.progressionMode ? _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" JSON "), _c('span', {
    staticClass: "icon is-pulled-right has-text-success"
  }, [_c('i', {
    staticClass: "fa fa-check-circle"
  })])]), _c('p', [_vm._v("CaSS supports importing frameworks from JSON files in the below listed two formats.")]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" Achievement Standards Network RDF+JSON ")]), _c('p', [_vm._v(" The Achievement Standards Network set of standards, or ASN standard for short, is a legacy standard used primarily by achievementstandards.org to transmit state standards and other national and organizational standards. Using this format, you can import competencies exported from achievementstandards.org and other systems in an RDF JSON format. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.asnRdfJsonFile,
      "target": "_blank",
      "download": "D2695955.json"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example")])])]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" CTDL-ASN formatted JSON-LD ")]), _c('p', [_vm._v(" For this import, you use one JSON-LD file that includes a graph of the framework and all of its competencies. Using this format, you can import a framework and competencies from a system that exports CTDL-ASN formatted JSON-LD. If you wish to edit the framework after importing this file type, please be sure you are signed in. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnJsonldFile,
      "target": "_blank",
      "download": "DQP.jsonld"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example")])])])]) : _vm._e(), _vm.tab === 'json' && (_vm.conceptMode || _vm.progressionMode) ? _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title has-text-weight-bold is-size-2"
  }, [_vm._v(" JSON "), _c('span', {
    staticClass: "icon is-pulled-right has-text-success"
  }, [_c('i', {
    staticClass: "fa fa-check-circle"
  })])]), _c('p', [_vm._v("CaSS supports importing " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept schemes' : 'taxonomies') + " from JSON files in the below listed format.")]), _c('h5', {
    staticClass: "header is-size-4 has-text-weight-bold"
  }, [_vm._v(" CTDL-ASN formatted JSON-LD ")]), _c('p', [_vm._v(" For this import, you use one JSON-LD file that includes a graph of the " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept scheme' : 'taxonomy') + " and all of its concepts. Using this format, you can import a " + _vm._s(_vm.queryParams.ceasnDataFields === 'true' ? 'concept scheme' : 'taxonomy') + " and concepts from a system that exports CTDL-ASN formatted JSON-LD. ")]), _c('div', {
    staticClass: "buttons is-right"
  }, [_c('a', {
    staticClass: "button is-small is-outlined is-primary",
    attrs: {
      "href": _vm.ctdlAsnJsonldConceptsFile,
      "target": "_blank",
      "download": "ConnectingCredentialsLevels.jsonld"
    }
  }, [_c('span', {
    staticClass: "icon",
    attrs: {
      "title": ""
    }
  }, [_c('i', {
    staticClass: "fa fa-download"
  })]), _c('span', [_vm._v("Example")])])])]) : _vm._e()]), _c('template', {
    slot: "modal-foot"
  }, [_c('div', {
    staticClass: "buttons is-right",
    on: {
      "click": function click($event) {
        return _vm.$store.commit('app/closeModal');
      }
    }
  }, [_c('button', {
    staticClass: "button is-primary is-large is-outlined"
  }, [_vm._v(" Back to import screen ")])])])], 2);
};
var staticRenderFns = [];

// CONCATENATED MODULE: ./src/components/modalContent/SupportedImportDetails.vue?vue&type=template&id=051bf002

// EXTERNAL MODULE: ./src/components/modalContent/ModalTemplate.vue + 4 modules
var ModalTemplate = __webpack_require__("af07");

// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Example of a Mininum Data Competency Framework Upload - HIST 101, SURVEY OF AMERICAN HISTORY I.csv
/* harmony default export */ var Example_of_a_Mininum_Data_Competency_Framework_Upload_HIST_101_SURVEY_OF_AMERICAN_HISTORY_I = (__webpack_require__.p + "3afc46be9c96e4f9424ebf77d6a846ce.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Template of a Mininum Data Competency Framework.csv
/* harmony default export */ var Template_of_a_Mininum_Data_Competency_Framework = (__webpack_require__.p + "f03e7101598521113971af392f3d60d9.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Example of a Benchmark Competency Framework - DOLWorkCharacteristicsDownloadfromCaSSAug25_2021.csv
/* harmony default export */ var Example_of_a_Benchmark_Competency_Framework_DOLWorkCharacteristicsDownloadfromCaSSAug25_2021 = (__webpack_require__.p + "1c57980d674a6a846d56489caec5640a.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Template of a Benchmark Competency Framework.csv
/* harmony default export */ var Template_of_a_Benchmark_Competency_Framework = (__webpack_require__.p + "693b81b90a1ee026223bb48912246ad6.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/CAP Software Engineering - Competencies.csv
/* harmony default export */ var CAP_Software_Engineering_Competencies = (__webpack_require__.p + "a484eef92ff7182dc0411c8cffd0a32c.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/CAP Software Engineering - Relations.csv
/* harmony default export */ var CAP_Software_Engineering_Relations = (__webpack_require__.p + "9c0f78f5d5a66aeb8cddd225edeb9b22.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Template - Competencies.csv
/* harmony default export */ var Template_Competencies = (__webpack_require__.p + "22ec9de44a51623348df2e0a338a5a8e.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Template - Relations.csv
/* harmony default export */ var Template_Relations = (__webpack_require__.p + "82e91c069dad20a39997a56fe0915cae.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Concept Scheme Example.csv
/* harmony default export */ var Concept_Scheme_Example = (__webpack_require__.p + "5664a4f8f7eebaf6edd9627f08229e50.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/Concept Scheme Template.csv
/* harmony default export */ var Concept_Scheme_Template = (__webpack_require__.p + "69e765ca351048bdcaa72715728dab8e.csv");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/ConnectingCredentialsLevels.jsonld
/* harmony default export */ var ConnectingCredentialsLevels_jsonld = (__webpack_require__.p + "7625e92311aea18ccbf5212ef4123cac.jsonld");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/DQP.jsonld
/* harmony default export */ var DQP_jsonld = (__webpack_require__.p + "14f32ce1d76a37d598beeef9a16a9a03.jsonld");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/D2695955
/* harmony default export */ var D2695955 = (__webpack_require__.p + "c450f7e5f454de6e0e29195aaa1dd151.bin");
// CONCATENATED MODULE: ./node_modules/file-loader/dist/cjs.js!./files/educational_achievement_sample_1June2012.xml
/* harmony default export */ var educational_achievement_sample_1June2012 = (__webpack_require__.p + "99cfb12c9ff1a4253690ae423a22fd1b.xml");
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/modalContent/SupportedImportDetails.vue?vue&type=script&lang=js















/* harmony default export */ var SupportedImportDetailsvue_type_script_lang_js = ({
  name: 'SupportedImportDetails',
  props: {
    initialTab: {
      type: String
    }
  },
  components: {
    ModalTemplate: ModalTemplate["a" /* default */]
  },
  data: function data() {
    return {
      newTab: '',
      ctdlAsnCsvExampleFile: Example_of_a_Mininum_Data_Competency_Framework_Upload_HIST_101_SURVEY_OF_AMERICAN_HISTORY_I,
      ctdlAsnCsvTemplateFile: Template_of_a_Mininum_Data_Competency_Framework,
      ctdlAsnCsvBenchmarkExampleFile: Example_of_a_Benchmark_Competency_Framework_DOLWorkCharacteristicsDownloadfromCaSSAug25_2021,
      ctdlAsnCsvBenchmarkTemplateFile: Template_of_a_Benchmark_Competency_Framework,
      csvExampleCompetenciesFile: CAP_Software_Engineering_Competencies,
      csvExampleRelationsFile: CAP_Software_Engineering_Relations,
      csvTemplateCompetenciesFile: Template_Competencies,
      csvTemplateRelationsFile: Template_Relations,
      csvConceptExampleFile: Concept_Scheme_Example,
      csvConceptTemplateFile: Concept_Scheme_Template,
      ctdlAsnJsonldConceptsFile: ConnectingCredentialsLevels_jsonld,
      ctdlAsnJsonldFile: DQP_jsonld,
      asnRdfJsonFile: D2695955,
      medbiquitousFile: educational_achievement_sample_1June2012
    };
  },
  computed: {
    modal: function modal() {
      return this.$store.getters['app/dynamicModalContent'];
    },
    content: function content() {
      return this.modal.documentContent;
    },
    tab: function tab() {
      if (this.newTab !== '') {
        return this.newTab;
      } else {
        return this.content;
      }
    },
    conceptMode: function conceptMode() {
      return this.$store.getters['editor/conceptMode'];
    },
    progressionMode: function progressionMode() {
      return this.$store.getters['editor/progressionMode'];
    },
    queryParams: function queryParams() {
      return this.$store.getters['editor/queryParams'];
    }
  }
});
// CONCATENATED MODULE: ./src/components/modalContent/SupportedImportDetails.vue?vue&type=script&lang=js
 /* harmony default export */ var modalContent_SupportedImportDetailsvue_type_script_lang_js = (SupportedImportDetailsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/modalContent/SupportedImportDetails.vue?vue&type=style&index=0&id=051bf002&prod&lang=scss
var SupportedImportDetailsvue_type_style_index_0_id_051bf002_prod_lang_scss = __webpack_require__("7bd0");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/modalContent/SupportedImportDetails.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  modalContent_SupportedImportDetailsvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var SupportedImportDetails = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "af07":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"66eac875-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/modalContent/ModalTemplate.vue?vue&type=template&id=1c4e04a7
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "modal cass-editor___modal",
    class: [{
      'is-active': _vm.active
    }, 'is-' + _vm.size, 'cass-editor__modal--' + _vm.content],
    attrs: {
      "id": "cass-modal"
    }
  }, [_c('div', {
    staticClass: "modal-background"
  }), _c('div', {
    staticClass: "modal-card",
    class: 'cass-editor__modal-card--' + _vm.size
  }, [_c('header', {
    staticClass: "modal-card-head is-size-4 has-text-weight-bold",
    class: ['has-background-' + _vm.type, 'has-text-' + _vm.fontColor]
  }, [_c('p', {
    staticClass: "modal-card-title"
  }, [_vm._t("modal-header")], 2), _vm.canClose ? _c('button', {
    staticClass: "delete",
    attrs: {
      "aria-label": "close"
    },
    on: {
      "click": function click($event) {
        _vm.$store.commit('app/closeModal');
        _vm.$emit('close');
      }
    }
  }) : _vm._e()]), _c('div', {
    staticClass: "modal-card-body has-text-dark"
  }, [_vm._t("modal-body")], 2), _c('footer', {
    staticClass: "modal-card-foot has-background-white"
  }, [_vm._t("modal-foot")], 2)])]);
};
var staticRenderFns = [];

// CONCATENATED MODULE: ./src/components/modalContent/ModalTemplate.vue?vue&type=template&id=1c4e04a7

// EXTERNAL MODULE: ./src/scss/modal-template.scss
var modal_template = __webpack_require__("984b");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/modalContent/ModalTemplate.vue?vue&type=script&lang=js

/* harmony default export */ var ModalTemplatevue_type_script_lang_js = ({
  name: 'ModalTemplate',
  props: {
    canClose: {
      type: Boolean,
      default: true
    },
    active: {
      type: Boolean,
      default: false
    },
    type: {
      default: 'primary',
      type: String
    },
    fontColor: {
      type: String,
      default: 'white'
    },
    size: {
      type: String,
      default: 'medium'
    },
    content: {
      defualt: 'default',
      type: String
    }
  },
  data: function data() {
    return {};
  },
  computed: {}
});
// CONCATENATED MODULE: ./src/components/modalContent/ModalTemplate.vue?vue&type=script&lang=js
 /* harmony default export */ var modalContent_ModalTemplatevue_type_script_lang_js = (ModalTemplatevue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/modalContent/ModalTemplate.vue?vue&type=style&index=0&id=1c4e04a7&prod&lang=scss
var ModalTemplatevue_type_style_index_0_id_1c4e04a7_prod_lang_scss = __webpack_require__("8d7e");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/modalContent/ModalTemplate.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  modalContent_ModalTemplatevue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var ModalTemplate = __webpack_exports__["a"] = (component.exports);

/***/ })

}]);
//# sourceMappingURL=chunk-0e513d16.004407c9.js.map