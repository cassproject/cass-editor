(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["forbidden"],{

/***/ "a215":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Forbidden_vue_vue_type_style_index_0_id_aedbfea6_prod_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e434");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Forbidden_vue_vue_type_style_index_0_id_aedbfea6_prod_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Forbidden_vue_vue_type_style_index_0_id_aedbfea6_prod_scoped_true_lang_css__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "dc82":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"cb2182ec-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Forbidden.vue?vue&type=template&id=aedbfea6&scoped=true
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    attrs: {
      "id": "internal-error"
    }
  }, [_vm._m(0), _c('div', {
    staticClass: "section"
  }, [_c('div', {
    staticClass: "buttons is-centered"
  }, [_c('router-link', {
    staticClass: "button is-primary is-centered",
    attrs: {
      "to": {
        path: '/frameworks',
        query: _vm.queryParams
      }
    }
  }, [_vm._v(" return home ")])], 1)])]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "section"
  }, [_c('h2', {
    staticClass: "title is-size-3"
  }, [_vm._v(" Forbidden ")]), _c('p', [_vm._v(" You do not have permission to perform this operation. Please check that you are properly logged in. ")])]);
}];

// CONCATENATED MODULE: ./src/views/Forbidden.vue?vue&type=template&id=aedbfea6&scoped=true

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/Forbidden.vue?vue&type=script&lang=js
/* harmony default export */ var Forbiddenvue_type_script_lang_js = ({
  name: 'Forbidden',
  computed: {
    queryParams: function queryParams() {
      return this.$store.getters['editor/queryParams'];
    }
  }
});
// CONCATENATED MODULE: ./src/views/Forbidden.vue?vue&type=script&lang=js
 /* harmony default export */ var views_Forbiddenvue_type_script_lang_js = (Forbiddenvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/views/Forbidden.vue?vue&type=style&index=0&id=aedbfea6&prod&scoped=true&lang=css
var Forbiddenvue_type_style_index_0_id_aedbfea6_prod_scoped_true_lang_css = __webpack_require__("a215");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/views/Forbidden.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  views_Forbiddenvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  "aedbfea6",
  null
  
)

/* harmony default export */ var Forbidden = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "e434":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);
//# sourceMappingURL=forbidden.0320e243.js.map