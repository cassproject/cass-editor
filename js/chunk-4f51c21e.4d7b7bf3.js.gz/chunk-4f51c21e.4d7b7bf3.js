(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-4f51c21e"],{

/***/ "1443":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Comments_vue_vue_type_style_index_0_id_4ed1e043_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("72d6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Comments_vue_vue_type_style_index_0_id_4ed1e043_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Comments_vue_vue_type_style_index_0_id_4ed1e043_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "3109":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FilterAndSort_vue_vue_type_style_index_0_id_e134a7f8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d261");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FilterAndSort_vue_vue_type_style_index_0_id_e134a7f8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_FilterAndSort_vue_vue_type_style_index_0_id_e134a7f8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "3486":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RightAside_vue_vue_type_style_index_0_id_10c69596_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("fb6a7");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RightAside_vue_vue_type_style_index_0_id_10c69596_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RightAside_vue_vue_type_style_index_0_id_10c69596_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "3558":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListItemInfo_vue_vue_type_style_index_0_id_3aebcc9e_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("bf12");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListItemInfo_vue_vue_type_style_index_0_id_3aebcc9e_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ListItemInfo_vue_vue_type_style_index_0_id_3aebcc9e_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "6675":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Comment.vue?vue&type=template&id=9343bfcc
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('ul', {
    staticClass: "comment-list-item"
  }, [_c('li', {
    staticClass: "comment-list__user",
    attrs: {
      "title": _vm.comment.creatorEmail
    }
  }, [_vm._v(" " + _vm._s(_vm.comment.creatorName) + " ")]), _c('li', {
    staticClass: "comment-list__email"
  }, [_vm._v(" " + _vm._s(_vm.comment.creatorEmail) + " ")]), _c('li', {
    staticClass: "comment-list__timestamp"
  }, [_vm._v(" " + _vm._s(_vm.toPrettyDateString(_vm.comment.dateCreated)) + " ")]), _c('li', {
    directives: [{
      name: "click-outside",
      rawName: "v-click-outside",
      value: _vm.closeCommentListDropDown,
      expression: "closeCommentListDropDown"
    }],
    staticClass: "comment-list__message-container"
  }, [_vm.comment.canModify ? _c('div', {
    staticClass: "dropdown",
    class: {
      'is-active': _vm.commentListDropDownActive
    }
  }, [_c('div', {
    staticClass: "dropdown-trigger"
  }, [_c('button', {
    staticClass: "button is-text has-text-dark",
    attrs: {
      "aria-haspopup": "true",
      "aria-controls": "dropdown-menu"
    },
    on: {
      "click": function click($event) {
        _vm.commentListDropDownActive = !_vm.commentListDropDownActive;
      }
    }
  }, [_vm._m(0)])]), _c('div', {
    staticClass: "dropdown-menu",
    attrs: {
      "id": "dropdown-menu",
      "role": "menu"
    }
  }, [_c('div', {
    staticClass: "dropdown-content"
  }, [_c('a', {
    staticClass: "dropdown-item",
    attrs: {
      "href": "#"
    },
    on: {
      "click": _vm.handleClickEdit
    }
  }, [_vm._v(" edit ")]), _c('a', {
    staticClass: "dropdown-item",
    on: {
      "click": _vm.handleClickDelete
    }
  }, [_vm._v(" delete ")])])])]) : _vm._e(), _c('div', {
    staticClass: "comment-list__message-container__message",
    class: {
      'show-more': _vm.showMore
    }
  }, [_vm._v(" " + _vm._s(_vm.comment.commentText) + " ")]), _vm.comment.commentText.length > 90 ? _c('div', {
    staticClass: "buttons is-right"
  }, [_vm.showMore ? _c('div', {
    staticClass: "button is-text has-text-primary",
    on: {
      "click": function click($event) {
        _vm.showMore = false;
      }
    }
  }, [_vm._v(" show less ")]) : _c('div', {
    staticClass: "button is-text has-text-primary",
    on: {
      "click": function click($event) {
        _vm.showMore = true;
      }
    }
  }, [_vm._v(" show more ")])]) : _vm._e()]), _vm.comment.lastEditDate ? _c('li', {
    staticClass: "comment-list__message_edit"
  }, [_vm._v(" *Edited: " + _vm._s(_vm.toPrettyDateString(_vm.comment.lastEditDate)) + " ")]) : _vm._e(), _vm._m(1), _vm.comment.replies.length > 0 ? _c('li', _vm._l(_vm.comment.replies, function (reply) {
    return _c('comment', {
      key: reply.commentId,
      attrs: {
        "comment": reply,
        "canReply": false
      }
    });
  }), 1) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon has-text-primary"
  }, [_c('i', {
    staticClass: "fas fa-ellipsis-v"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('li', {
    staticClass: "comment-list__reply_hr"
  }, [_c('hr')]);
}];

// CONCATENATED MODULE: ./src/components/framework/Comment.vue?vue&type=template&id=9343bfcc

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js
var createForOfIteratorHelper = __webpack_require__("b85c");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__("14d9");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__("3ca3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// EXTERNAL MODULE: ./src/mixins/common.js
var common = __webpack_require__("872c");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Comment.vue?vue&type=script&lang=js






/* harmony default export */ var Commentvue_type_script_lang_js = ({
  name: 'Comment',
  mixins: [common["a" /* default */]],
  components: {
    comment: function comment() {
      return Promise.resolve(/* import() */).then(__webpack_require__.bind(null, "6675"));
    }
  },
  props: {
    comment: {
      type: Object
    },
    canReply: {
      type: Boolean,
      default: false
    }
  },
  data: function data() {
    return {
      showMore: false,
      commentListDropDownActive: false
    };
  },
  methods: {
    closeCommentListDropDown: function closeCommentListDropDown() {
      this.commentListDropDownActive = false;
    },
    handleClickReply: function handleClickReply() {
      this.$store.commit('editor/setAddCommentAboutId', this.comment.aboutId);
      this.$store.commit('editor/setAddCommentType', 'reply');
      this.$store.commit('editor/setCommentToReply', this.comment.comment);
      this.$store.commit('app/showModal', {
        component: 'AddComment'
      });
    },
    handleClickEdit: function handleClickEdit() {
      this.commentListDropDownActive = false;
      this.$store.commit('editor/setAddCommentAboutId', this.comment.aboutId);
      this.$store.commit('editor/setAddCommentType', 'edit');
      this.$store.commit('editor/setCommentToEdit', this.comment.comment);
      this.$store.commit('app/showModal', {
        component: 'AddComment'
      });
    },
    handleClickEditReply: function handleClickEditReply(replyIdx) {
      this.$store.commit('editor/setAddCommentAboutId', this.comment.aboutId);
      this.$store.commit('editor/setAddCommentType', 'edit');
      this.$store.commit('editor/setCommentToEdit', this.comment.replies[replyIdx].comment);
      this.$store.commit('app/showModal', {
        component: 'AddComment'
      });
    },
    handleClickDelete: function handleClickDelete() {
      var ctd = [];
      ctd.push(this.comment.comment);
      if (this.comment.replies && this.comment.replies.length > 0) {
        var _iterator = Object(createForOfIteratorHelper["a" /* default */])(this.comment.replies),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var r = _step.value;
            ctd.push(r.comment);
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      this.$store.commit('editor/setCommentsToDelete', ctd);
      this.$store.commit('app/showModal', {
        component: 'DeleteCommentConfirm'
      });
    },
    handleClickDeleteReply: function handleClickDeleteReply(replyIdx) {
      var ctd = [];
      ctd.push(this.comment.replies[replyIdx].comment);
      this.$store.commit('editor/setCommentsToDelete', ctd);
      this.$store.commit('app/showModal', {
        component: 'DeleteCommentConfirm'
      });
    }
  },
  computed: {
    commentId: function commentId() {
      return this.comment.commentId;
    }
  }
});
// CONCATENATED MODULE: ./src/components/framework/Comment.vue?vue&type=script&lang=js
 /* harmony default export */ var framework_Commentvue_type_script_lang_js = (Commentvue_type_script_lang_js); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/framework/Comment.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  framework_Commentvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var Comment = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "72d6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "8b6f":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "8eaf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Versions_vue_vue_type_style_index_0_id_7a9ef4e8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8b6f");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Versions_vue_vue_type_style_index_0_id_7a9ef4e8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Versions_vue_vue_type_style_index_0_id_7a9ef4e8_prod_lang_scss__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "bf12":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "d261":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "dd98":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/RightAside.vue?vue&type=template&id=10c69596&scoped=true
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('aside', {
    staticClass: "has-background-light",
    attrs: {
      "id": "right-side-bar"
    }
  }, [_c('div', {
    staticClass: "cass--right-aside--top-bar"
  }, [_c('button', {
    staticClass: "delete has-text-white",
    attrs: {
      "aria-label": "close"
    },
    on: {
      "click": function click($event) {
        return _vm.$store.commit('app/closeRightAside');
      }
    }
  }, [_vm._m(0)]), _c('div', {
    staticClass: "cass--right-aside--title"
  }, [_vm.rightAsideContent === 'FilterAndSort' ? _c('span', [_vm._v(" Filter & sort ")]) : _vm.rightAsideContent === 'ListItemInfo' ? _c('span', [_vm._v(" Information ")]) : _vm.rightAsideContent === 'Comments' ? _c('span', [_vm._v(" Comments ")]) : _vm._e()])]), _vm._t("right-aside-content", function () {
    return [_c(_vm.rightAsideContent, {
      tag: "Component",
      on: {
        "editResourceDetails": function editResourceDetails($event) {
          return _vm.$emit('editResource', $event);
        }
      }
    })];
  })], 2);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-times"
  })]);
}];

// CONCATENATED MODULE: ./src/components/framework/RightAside.vue?vue&type=template&id=10c69596&scoped=true

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Comments.vue?vue&type=template&id=4ed1e043
var Commentsvue_type_template_id_4ed1e043_render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "has-background-lightest",
    attrs: {
      "id": "right-side-bar__comments"
    }
  }, [_vm.isCommentsBusy ? _c('div', {
    staticClass: "has-text-centered"
  }, [_vm._m(0)]) : _vm._e(), !_vm.isCommentsBusy ? _c('div', [_vm.commentWrapperList.length <= 0 ? _c('div', {
    staticClass: "has-text-centered"
  }, [_vm._m(1)]) : _vm._e(), _vm.commentWrapperList.length > 0 ? _vm._l(_vm.commentWrapperList, function (commentWrapper, index) {
    return _c('div', {
      key: index,
      staticClass: "comment-list"
    }, [_c('h4', {
      staticClass: "comment-list__about",
      on: {
        "click": function click($event) {
          return _vm.setUpScroll(commentWrapper);
        }
      }
    }, [_vm._v(" " + _vm._s(commentWrapper.aboutName) + " ")]), _c('Comment', {
      key: commentWrapper.commentId,
      attrs: {
        "comment": commentWrapper,
        "canReply": _vm.canReplyToComments
      }
    }), _c('div', {
      staticClass: "buttons is-right"
    }, [_c('div', {
      staticClass: "button is-small is-outlined is-primary",
      attrs: {
        "title": "reply"
      },
      on: {
        "click": function click($event) {
          return _vm.handleClickReply(commentWrapper);
        }
      }
    }, [_vm._m(2, true), _c('span', [_vm._v("reply")])])])], 1);
  }) : _vm._e()], 2) : _vm._e()]);
};
var Commentsvue_type_template_id_4ed1e043_staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon is-large has-text-center has-text-link"
  }, [_c('i', {
    staticClass: "fas fa-2x fa-spinner is-info fa-pulse"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "has-text-center"
  }, [_c('p', [_c('i', {
    staticClass: "fa fa-exclamation-circle"
  }), _vm._v(" No comments available")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-reply"
  })]);
}];

// CONCATENATED MODULE: ./src/components/framework/Comments.vue?vue&type=template&id=4ed1e043

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/regenerator.js + 1 modules
var regenerator = __webpack_require__("c14f");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("1da1");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js
var createForOfIteratorHelper = __webpack_require__("b85c");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__("14d9");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.sort.js
var es_array_sort = __webpack_require__("4e82");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__("841c");

// EXTERNAL MODULE: ./src/components/framework/Comment.vue + 4 modules
var Comment = __webpack_require__("6675");

// EXTERNAL MODULE: ./src/mixins/common.js
var common = __webpack_require__("872c");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Comments.vue?vue&type=script&lang=js











/* harmony default export */ var Commentsvue_type_script_lang_js = ({
  name: 'Comments',
  mixins: [common["a" /* default */]],
  data: function data() {
    return {
      COMMENT_SEARCH_SIZE: 10000,
      isCommentsBusy: false,
      localFrameworkCommentList: [],
      commentAboutMap: {},
      commentWrapperList: [],
      commentWrapperMap: {},
      canReplyToComments: false
    };
  },
  components: {
    Comment: Comment["default"]
  },
  methods: {
    setUpScroll: function setUpScroll(comment) {
      var scrollObj = {
        ts: Date.now(),
        scrollId: '#scroll-' + comment.aboutId.split('/').pop()
      };
      this.$store.commit('editor/setCommentScrollTo', scrollObj);
    },
    handleClickReply: function handleClickReply(comment) {
      this.$store.commit('editor/setAddCommentAboutId', comment.aboutId);
      this.$store.commit('editor/setAddCommentType', 'reply');
      this.$store.commit('editor/setCommentToReply', comment.comment);
      this.$store.commit('app/showModal', {
        component: 'AddComment'
      });
    },
    determineCanModifyComment: function determineCanModifyComment(comment) {
      if (this.loggedOnPerson.shortId().equals(comment.creator)) return true;else return false;
    },
    buildCommentWrapper: function buildCommentWrapper(comment, aboutName, isTopLevel) {
      var commentWrapper = {};
      var commentCreatorPerson = this.frameworkCommentPersonMap[comment.creator];
      commentWrapper.comment = comment;
      commentWrapper.creator = commentCreatorPerson;
      commentWrapper.aboutId = comment.about;
      commentWrapper.aboutName = aboutName;
      commentWrapper.commentId = comment.shortId();
      commentWrapper.creatorName = commentCreatorPerson.name;
      commentWrapper.creatorEmail = commentCreatorPerson.email;
      commentWrapper.dateCreated = comment.dateCreated - 0;
      if (comment.lastEditDate) commentWrapper.lastEditDate = comment.lastEditDate - 0;
      commentWrapper.commentText = comment.text;
      commentWrapper.isTopLevel = isTopLevel;
      commentWrapper.canModify = this.determineCanModifyComment(comment);
      commentWrapper.replies = [];
      return commentWrapper;
    },
    buildFrameworkCommentWrappers: function buildFrameworkCommentWrappers() {
      var fwkComments = this.commentAboutMap[this.currentFramework.shortId()];
      if (fwkComments && fwkComments.length > 0) {
        var _iterator = Object(createForOfIteratorHelper["a" /* default */])(fwkComments),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var fc = _step.value;
            var cw = this.buildCommentWrapper(fc, this.currentFramework.getName(), true);
            this.commentWrapperList.push(cw);
            this.commentWrapperMap[fc.shortId()] = cw;
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
    },
    getCompetencyName: function getCompetencyName(compId) {
      return Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee() {
        var comp;
        return Object(regenerator["a" /* default */])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              _context.n = 1;
              return EcRepository.get(compId);
            case 1:
              comp = _context.v;
              if (!comp) {
                _context.n = 2;
                break;
              }
              return _context.a(2, comp.getName());
            case 2:
              return _context.a(2, 'Unknown Competency');
            case 3:
              return _context.a(2);
          }
        }, _callee);
      }))();
    },
    buildCompetencyCommentWrappers: function () {
      var _buildCompetencyCommentWrappers = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee2() {
        var _iterator2, _step2, fwkCompId, compComments, compName, _iterator3, _step3, cc, cw, _t;
        return Object(regenerator["a" /* default */])().w(function (_context2) {
          while (1) switch (_context2.p = _context2.n) {
            case 0:
              if (!this.currentFramework.competency) {
                _context2.n = 8;
                break;
              }
              _iterator2 = Object(createForOfIteratorHelper["a" /* default */])(this.currentFramework.competency);
              _context2.p = 1;
              _iterator2.s();
            case 2:
              if ((_step2 = _iterator2.n()).done) {
                _context2.n = 5;
                break;
              }
              fwkCompId = _step2.value;
              compComments = this.commentAboutMap[fwkCompId];
              if (!(compComments && compComments.length > 0)) {
                _context2.n = 4;
                break;
              }
              _context2.n = 3;
              return this.getCompetencyName(fwkCompId);
            case 3:
              compName = _context2.v;
              _iterator3 = Object(createForOfIteratorHelper["a" /* default */])(compComments);
              try {
                for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                  cc = _step3.value;
                  cw = this.buildCommentWrapper(cc, compName, true);
                  this.commentWrapperList.push(cw);
                  this.commentWrapperMap[cc.shortId()] = cw;
                }
              } catch (err) {
                _iterator3.e(err);
              } finally {
                _iterator3.f();
              }
            case 4:
              _context2.n = 2;
              break;
            case 5:
              _context2.n = 7;
              break;
            case 6:
              _context2.p = 6;
              _t = _context2.v;
              _iterator2.e(_t);
            case 7:
              _context2.p = 7;
              _iterator2.f();
              return _context2.f(7);
            case 8:
              return _context2.a(2);
          }
        }, _callee2, this, [[1, 6, 7, 8]]);
      }));
      function buildCompetencyCommentWrappers() {
        return _buildCompetencyCommentWrappers.apply(this, arguments);
      }
      return buildCompetencyCommentWrappers;
    }(),
    addRepliesToParentWrapper: function addRepliesToParentWrapper(replyList) {
      var _iterator4 = Object(createForOfIteratorHelper["a" /* default */])(replyList),
        _step4;
      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var replyId = _step4.value;
          var reply = this.commentWrapperMap[replyId];
          var replyAboutId = reply.aboutId;
          var parent = this.commentWrapperMap[replyAboutId];
          if (parent) parent.replies.push(reply);
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
    },
    buildReplyCommentWrappers: function buildReplyCommentWrappers() {
      var replyList = [];
      var _iterator5 = Object(createForOfIteratorHelper["a" /* default */])(this.frameworkCommentList),
        _step5;
      try {
        for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
          var c = _step5.value;
          var commentId = c.shortId();
          var commentReplies = this.commentAboutMap[commentId];
          if (commentReplies && commentReplies.length > 0) {
            var _iterator6 = Object(createForOfIteratorHelper["a" /* default */])(commentReplies),
              _step6;
            try {
              for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                var cr = _step6.value;
                var cw = this.buildCommentWrapper(cr, 'reply', false);
                this.commentWrapperMap[cr.shortId()] = cw;
                replyList.push(cr.shortId());
              }
            } catch (err) {
              _iterator6.e(err);
            } finally {
              _iterator6.f();
            }
          }
        }
      } catch (err) {
        _iterator5.e(err);
      } finally {
        _iterator5.f();
      }
      this.addRepliesToParentWrapper(replyList);
    },
    buildCommentDisplayStructures: function () {
      var _buildCommentDisplayStructures = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee3() {
        return Object(regenerator["a" /* default */])().w(function (_context3) {
          while (1) switch (_context3.n) {
            case 0:
              this.buildFrameworkCommentWrappers();
              _context3.n = 1;
              return this.buildCompetencyCommentWrappers();
            case 1:
              this.buildReplyCommentWrappers();
            case 2:
              return _context3.a(2);
          }
        }, _callee3, this);
      }));
      function buildCommentDisplayStructures() {
        return _buildCommentDisplayStructures.apply(this, arguments);
      }
      return buildCommentDisplayStructures;
    }(),
    buildCommentAboutMap: function buildCommentAboutMap() {
      var _iterator7 = Object(createForOfIteratorHelper["a" /* default */])(this.frameworkCommentList),
        _step7;
      try {
        for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
          var c = _step7.value;
          var ca = c.about;
          if (!this.commentAboutMap[ca]) this.commentAboutMap[ca] = [];
          this.commentAboutMap[ca].push(c);
        }
      } catch (err) {
        _iterator7.e(err);
      } finally {
        _iterator7.f();
      }
    },
    parseComments: function parseComments() {
      if (!this.currentFramework) this.clearAllFrameworkCommentData();else {
        this.isCommentsBusy = true;
        this.commentAboutMap = {};
        this.commentWrapperList = [];
        this.commentWrapperMap = {};
        this.buildCommentAboutMap();
        this.buildCommentDisplayStructures();
        this.isCommentsBusy = false;
      }
    },
    buildFrameworkCommentPersonMapSuccess: function buildFrameworkCommentPersonMapSuccess(ecPersonList) {
      var commentPersonMap = {};
      var _iterator8 = Object(createForOfIteratorHelper["a" /* default */])(ecPersonList),
        _step8;
      try {
        for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
          var p = _step8.value;
          commentPersonMap[p.shortId()] = p;
        }
      } catch (err) {
        _iterator8.e(err);
      } finally {
        _iterator8.f();
      }
      this.$store.commit('editor/setFrameworkCommentDataLoaded', true);
      this.$store.commit('editor/setFrameworkCommentPersonMap', commentPersonMap);
      this.$store.commit('editor/setFrameworkCommentList', this.localFrameworkCommentList); // this SHOULD trigger parseComments
    },
    buildFrameworkCommentPersonMapFailure: function buildFrameworkCommentPersonMapFailure(msg) {
      appLog('buildFrameworkCommentPersonMapFailure: ' + msg);
      this.isCommentsBusy = false;
    },
    buildCommentCreatorList: function buildCommentCreatorList() {
      var commentCreators = [];
      var _iterator9 = Object(createForOfIteratorHelper["a" /* default */])(this.localFrameworkCommentList),
        _step9;
      try {
        for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
          var c = _step9.value;
          if (!commentCreators.includes(c.creator)) commentCreators.push(c.creator);
        }
      } catch (err) {
        _iterator9.e(err);
      } finally {
        _iterator9.f();
      }
      return commentCreators;
    },
    buildFrameworkCommentPersonMap: function buildFrameworkCommentPersonMap() {
      var commentCreators = this.buildCommentCreatorList();
      if (commentCreators.length > 0) {
        window.repo.multiget(commentCreators, this.buildFrameworkCommentPersonMapSuccess, this.buildFrameworkCommentPersonMapFailure);
      } else this.buildFrameworkCommentPersonMapSuccess([]);
    },
    sortLocalFrameworkCommentList: function sortLocalFrameworkCommentList() {
      this.localFrameworkCommentList.sort(function (c1, c2) {
        if (c1.dateCreated - 0 > c2.dateCreated - 0) return 1;else if (c2.dateCreated - 0 > c1.dateCreated - 0) return -1;else return 0;
      });
    },
    buildFrameworkCommentListSuccess: function buildFrameworkCommentListSuccess(ecCommentList) {
      this.localFrameworkCommentList = ecCommentList;
      this.sortLocalFrameworkCommentList();
      this.buildFrameworkCommentPersonMap();
    },
    buildFrameworkCommentListFailure: function buildFrameworkCommentListFailure(msg) {
      appLog('buildFrameworkCommentListFailure: ' + msg);
      this.isCommentsBusy = false;
    },
    clearAllFrameworkCommentData: function clearAllFrameworkCommentData() {
      this.isCommentsBusy = false;
      this.localFrameworkCommentList = [];
      this.commentAboutMap = {};
      this.commentWrapperList = [];
      this.commentWrapperMap = {};
      this.canReplyToComments = false;
    },
    buildFrameworkCommentList: function buildFrameworkCommentList() {
      if (!this.currentFramework) this.clearAllFrameworkCommentData();else {
        var paramObj = {};
        paramObj.size = this.COMMENT_SEARCH_SIZE;
        EcComment.search(window.repo, 'isBasedOn:"' + this.currentFramework.shortId() + '"', this.buildFrameworkCommentListSuccess, this.buildFrameworkCommentListFailure, null);
      }
    },
    buildCommentDataSet: function buildCommentDataSet() {
      if (!this.frameworkCommentList || this.frameworkCommentList.length <= 0) {
        this.isCommentsBusy = true;
        this.buildFrameworkCommentList();
      } else this.parseComments();
    }
  },
  computed: {
    loggedOnPerson: function loggedOnPerson() {
      return this.$store.getters['user/loggedOnPerson'];
    },
    currentFramework: function currentFramework() {
      return this.$store.getters['editor/framework'];
    },
    currentFrameworkCompetencies: function currentFrameworkCompetencies() {
      return this.$store.getters['editor/framework'].competency;
    },
    frameworkCommentList: function frameworkCommentList() {
      return this.$store.getters['editor/frameworkCommentList'];
    },
    frameworkCommentPersonMap: function frameworkCommentPersonMap() {
      return this.$store.getters['editor/frameworkCommentPersonMap'];
    }
  },
  watch: {
    currentFrameworkCompetencies: function currentFrameworkCompetencies() {
      this.parseComments();
    },
    frameworkCommentList: function frameworkCommentList() {
      this.parseComments();
    }
  },
  mounted: function mounted() {
    this.buildCommentDataSet();
    this.canReplyToComments = this.canAddCommentsCurrentFramework();
  }
});
// CONCATENATED MODULE: ./src/components/framework/Comments.vue?vue&type=script&lang=js
 /* harmony default export */ var framework_Commentsvue_type_script_lang_js = (Commentsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/framework/Comments.vue?vue&type=style&index=0&id=4ed1e043&prod&lang=scss
var Commentsvue_type_style_index_0_id_4ed1e043_prod_lang_scss = __webpack_require__("1443");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/components/framework/Comments.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  framework_Commentsvue_type_script_lang_js,
  Commentsvue_type_template_id_4ed1e043_render,
  Commentsvue_type_template_id_4ed1e043_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var Comments = (component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Versions.vue?vue&type=template&id=7a9ef4e8
var Versionsvue_type_template_id_7a9ef4e8_render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('aside', {
    staticClass: "menu has-background-light",
    attrs: {
      "id": "comments-side-bar"
    }
  }, [_c('p', {
    staticClass: "subtitle is-size-4"
  }, [_c('span', {
    staticClass: "icon",
    on: {
      "click": function click($event) {
        return _vm.$store.commit('app/closeRightAside');
      }
    }
  }, [_c('i', {
    staticClass: "fa fa-caret-right"
  })]), _vm._v(" Version History ")])]);
};
var Versionsvue_type_template_id_7a9ef4e8_staticRenderFns = [];

// CONCATENATED MODULE: ./src/components/framework/Versions.vue?vue&type=template&id=7a9ef4e8

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/Versions.vue?vue&type=script&lang=js
/* harmony default export */ var Versionsvue_type_script_lang_js = ({
  name: 'Versions',
  data: function data() {
    return {
      isCommenter: true,
      isAdmin: false,
      isViewer: true
    };
  },
  components: {}
});
// CONCATENATED MODULE: ./src/components/framework/Versions.vue?vue&type=script&lang=js
 /* harmony default export */ var framework_Versionsvue_type_script_lang_js = (Versionsvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/framework/Versions.vue?vue&type=style&index=0&id=7a9ef4e8&prod&lang=scss
var Versionsvue_type_style_index_0_id_7a9ef4e8_prod_lang_scss = __webpack_require__("8eaf");

// CONCATENATED MODULE: ./src/components/framework/Versions.vue






/* normalize component */

var Versions_component = Object(componentNormalizer["a" /* default */])(
  framework_Versionsvue_type_script_lang_js,
  Versionsvue_type_template_id_7a9ef4e8_render,
  Versionsvue_type_template_id_7a9ef4e8_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var Versions = (Versions_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/ListItemInfo.vue?vue&type=template&id=3aebcc9e

var ListItemInfovue_type_template_id_3aebcc9e_render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "has-background-lightest",
    attrs: {
      "id": "cass__right-aside"
    }
  }, [_c('div', {
    staticClass: "cass__right-aside--header"
  }, [_c('div', {
    staticClass: "right-aside-bar__title"
  }, [_c('span', {
    staticClass: "help"
  }, [_vm._v(_vm._s(_vm.objectTypeForDisplay))]), _c('div', {
    staticClass: "right-aside-bar--title-text is-size-4 is-family-secondary",
    attrs: {
      "title": _vm.objectName
    }
  }, [_vm._v(" " + _vm._s(_vm.objectName) + " ")]), _vm.objectShortId !== _vm.selectedDirectoryId ? _c('div', {
    staticClass: "buttons pt-2"
  }, [_c('div', {
    staticClass: "button is-small is-rounded is-primary",
    on: {
      "click": _vm.openObject
    }
  }, [_c('span', [_vm._v("Open " + _vm._s(_vm.objectTypeForDisplay))]), _vm._m(0)])]) : _vm._e()])]), _c('div', {
    staticClass: "cass__right-aside--body"
  }, [_c('div', {
    staticClass: "cass__right-side--details"
  }, [_c('div', {
    staticClass: "cass__right-side--details-wrapper"
  }, [_vm.objectType === 'Directory' || _vm.objectType === 'Framework' || _vm.objectType === 'ConceptScheme' ? [_c('button', {
    staticClass: "cass__right-side--accordion details",
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('details');
      }
    }
  }, [_vm._v(" Details " + _vm._s(_vm.isCeasn ? "(in CaSS)" : "") + " "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'details' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel details",
    class: _vm.accordion === 'details' ? 'active' : ''
  }, [_vm._m(1), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.lastModified) + " ")]), _vm.object.directory && _vm.object.directory !== _vm.selectedDirectoryId ? [_vm._m(2), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.getName(_vm.object.directory)) + " "), _c('span', {
    staticClass: "button is-primary is-outlined is-small",
    on: {
      "click": _vm.goToParentDirectory
    }
  }, [_vm._v(" Open ")])])] : _vm.object.parentDirectory && _vm.object.parentDirectory !== _vm.selectedDirectoryId ? [_vm._m(3), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.getName(_vm.object.parentDirectory)) + " "), _c('span', {
    staticClass: "inline-link is-small",
    attrs: {
      "title": "Navigate to parent directory"
    },
    on: {
      "click": _vm.goToParentDirectory
    }
  }, [_c('span', [_vm._v("Go to parent")]), _vm._m(4)])])] : _vm._e(), _vm._m(5), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.dateCreated) + " ")]), _vm.objectType === 'Directory' ? _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Subdirectories:")])]) : _vm._e(), _vm.objectType === 'Directory' ? _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.numSubdirectories) + " ")]) : _vm._e(), _vm.objectType === 'Directory' ? [_vm._m(6), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.numObjects) + " ")])] : _vm.objectType === 'Framework' ? [_vm._m(7), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.object.competency ? _vm.object.competency.length : 0) + " ")])] : _vm._e(), _vm.object.Published ? [_vm._m(8), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.object.Published) + " ")])] : _vm._e(), _vm.object.Approved ? [_vm._m(9), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.object.Approved) + " ")])] : _vm._e(), _vm.publisherName ? [_vm._m(10), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.publisherName) + " ")])] : _vm._e(), _vm.creatorName ? [_vm._m(11), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_vm._v(" " + _vm._s(_vm.creatorName) + " ")])] : _vm._e(), [_vm._m(12), _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('span', {
    directives: [{
      name: "clipboard",
      rawName: "v-clipboard",
      value: function value() {
        return _vm.shareLink;
      },
      expression: "() => shareLink"
    }, {
      name: "clipboard",
      rawName: "v-clipboard:success",
      value: _vm.successfulClip,
      expression: "successfulClip",
      arg: "success"
    }, {
      name: "clipboard",
      rawName: "v-clipboard:error",
      value: _vm.errorClip,
      expression: "errorClip",
      arg: "error"
    }],
    staticClass: "inline-link",
    attrs: {
      "title": "Copy URL to the clipboard."
    }
  }, [_c('span', {
    attrs: {
      "title": _vm.shareLink
    }
  }, [_vm._v("copy link")]), _c('span', {
    staticClass: "icon"
  }, [_vm.clipStatus === 'success' ? _c('i', {
    staticClass: "fa fa-check"
  }) : _vm.clipStatus === 'error' ? _c('i', {
    staticClass: "fa fa-times"
  }) : _c('i', {
    staticClass: "fa fa-link",
    attrs: {
      "name": "copyURL"
    }
  })])])])]], 2)] : _vm._e(), _vm.objectType === 'CreativeWork' || _vm.canEditObject && _vm.objectType === 'Directory' ? [_c('button', {
    staticClass: "cass__right-side--accordion details",
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('properties');
      }
    }
  }, [_vm._v(" Properties "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'properties' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel",
    class: _vm.accordion === 'properties' ? 'active' : ''
  }, [_vm.objectType === 'CreativeWork' ? [_c('div', {
    staticClass: "cass__right-aside--property"
  }, [_c('div', {
    staticClass: "cass__right-aside--property-text"
  }, [_c('span', [_vm._v(" " + _vm._s(_vm.object.url) + " ")])]), _c('div', {
    staticClass: "cass__right-aside--property-label"
  }, [_vm._v(" Url ")])]), _c('div', {
    staticClass: "cass__right-aside--property"
  }, [_c('div', {
    staticClass: "cass__right-aside--property-text"
  }, [_c('span', [_vm._v(" " + _vm._s(_vm.objectName) + " ")])]), _c('div', {
    staticClass: "cass__right-aside--property-label"
  }, [_vm._v(" Name ")])]), _c('div', {
    staticClass: "cass__right-aside--property flex-end"
  }, [_c('div', {
    staticClass: "button is-pulled-right is-primary is-outlined",
    on: {
      "click": function click($event) {
        return _vm.$emit('editResourceDetails', _vm.object);
      }
    }
  }, [_c('span', [_vm._v("Edit")]), _vm._m(13)])])] : _vm._e(), _vm.objectType === 'Directory' ? [_c('div', {
    staticClass: "cass__right-aside--property"
  }, [_c('div', {
    staticClass: "cass__right-aside--property-text"
  }, [_c('span', [_vm._v(" " + _vm._s(_vm.objectName) + " ")])]), _c('div', {
    staticClass: "cass__right-aside--property-label"
  }, [_vm._v(" Directory Name ")]), _vm.canEditObject && _vm.objectType === 'Directory' ? _c('div', {
    staticClass: "cass__right-aside--property flex-end"
  }, [_c('div', {
    staticClass: "button is-pulled-right is-primary is-outlined",
    on: {
      "click": _vm.editDirectory
    }
  }, [_c('span', [_vm._v("Edit")]), _vm._m(14)])]) : _vm._e()])] : _vm._e(), _vm.errorEditing ? _c('span', [_vm._v(" " + _vm._s(_vm.errorEditing) + " ")]) : _vm._e()], 2)] : _vm._e(), _vm.loggedInPerson && _vm.loggedInPerson.name && _vm.canEditObject && !(_vm.objectType === 'CreativeWork' && !_vm.$store.state.featuresEnabled.userManagementEnabled) ? [_c('button', {
    staticClass: "cass__right-side--accordion",
    class: _vm.accordion === 'users' ? 'active' : '',
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('users');
      }
    }
  }, [_vm._v(" Users "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'users' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel users",
    class: _vm.accordion === 'users' ? 'active' : ''
  }, [_c('div', {
    staticClass: "cass__right-aside--whole-item pt-2"
  }, [_c('div', {
    staticClass: "buttons is-centered"
  }, [_c('div', {
    staticClass: "button is-primary is-rounded",
    on: {
      "click": _vm.manageUsers
    }
  }, [_c('span', [_vm._v("Manage Permissions / Share Framework")]), _vm._m(15)])])])])] : _vm._e(), _vm.objectType === 'Directory' ? [_c('button', {
    staticClass: "cass__right-side--accordion",
    class: _vm.accordion === 'description' ? 'active' : '',
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('description');
      }
    }
  }, [_vm._v(" Description "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'description' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel",
    class: _vm.accordion === 'description' ? 'active' : ''
  }, [_vm.objectDescription ? _c('div', {
    staticClass: "p-2"
  }, [_vm._v(" " + _vm._s(_vm.objectDescription) + " ")]) : _c('div', {
    staticClass: "p-2"
  }, [_vm._v(" No description ")])])] : _vm._e(), [_c('button', {
    staticClass: "cass__right-side--accordion",
    class: _vm.accordion === 'copy' ? 'active' : '',
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('copy');
      }
    }
  }, [_vm._v(" Copy " + _vm._s(_vm.objectTypeForDisplay) + " "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'copy' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel",
    class: _vm.accordion === 'copy' ? 'active' : ''
  }, [_vm.copyDirectoryOptions.length < 1 ? _c('p', {
    staticClass: "mx-2"
  }, [_c('em', [_vm._v("Please create a new directory to copy this " + _vm._s(_vm.objectTypeForDisplay) + " into.")])]) : _vm._e(), _vm._l(_vm.copyDirectoryOptions, function (directory) {
    return _c('li', {
      key: directory,
      staticClass: "cass--list-item-info--search-result--li"
    }, [_c('span', {
      staticClass: "cass--list-item-info--search-results--li-text"
    }, [_vm._v(" " + _vm._s(directory.name) + " ")]), _c('span', {
      staticClass: "button is-primary is-outlined is-small is-pulled-right",
      class: {
        'is-loading': _vm.processingCopyOrMove
      },
      attrs: {
        "disabled": _vm.processingCopyOrMove
      },
      on: {
        "click": function click($event) {
          return _vm.copyOrMove(directory, 'copy');
        }
      }
    }, [_vm._v(" copy here ")])]);
  })], 2)], _vm.canEditObject ? [_c('button', {
    staticClass: "cass__right-side--accordion",
    class: _vm.accordion === 'move' ? 'active' : '',
    on: {
      "click": function click($event) {
        return _vm.clickAccordion('move');
      }
    }
  }, [_vm._v(" Move " + _vm._s(_vm.objectTypeForDisplay) + " "), _c('span', {
    staticClass: "icon is-pulled-right"
  }, [_vm.accordion === 'move' ? _c('i', {
    staticClass: "fa fa-minus"
  }) : _c('i', {
    staticClass: "fa fa-plus"
  })])]), _c('div', {
    staticClass: "cass__right-side--accordion-panel",
    class: _vm.accordion === 'move' ? 'active' : ''
  }, [_vm._l(_vm.moveDirectoryOptions, function (directory) {
    return _c('li', {
      key: directory,
      staticClass: "cass--list-item-info--search-result--li"
    }, [_c('span', {
      staticClass: "cass--list-item-info--search-results--li-text"
    }, [_vm._v(" " + _vm._s(directory.name) + " ")]), _c('span', {
      staticClass: "button is-primary is-v-centered is-outlined is-small is-pulled-right",
      class: {
        'is-loading': _vm.processingCopyOrMove
      },
      on: {
        "click": function click($event) {
          return _vm.copyOrMove(directory, 'move');
        }
      }
    }, [_vm._v(" move here ")])]);
  }), _vm.object.directory || _vm.object.parentDirectory ? _c('li', {
    staticClass: "cass--list-item-info--search-result--li"
  }, [_c('span', {
    staticClass: "cass--list-item-info--search-results--li-text has-text-danger"
  }, [_vm._v(" Remove from directory ")]), _c('span', {
    staticClass: "button is-danger is-outlined is-small is-pulled-right",
    class: {
      'is-loading': _vm.processingRemove
    },
    on: {
      "click": _vm.removeFromDirectory
    }
  }, [_vm._v(" remove ")])]) : _vm._e()], 2)] : _vm._e(), _vm.canEditObject && _vm.objectType === 'Directory' ? [_c('div', {}, [_c('div', {
    staticClass: "buttons is-pulled-right p-2",
    on: {
      "click": _vm.deleteDirectory
    }
  }, [_c('div', {
    staticClass: "button is-danger is-outlined"
  }, [_vm._v(" delete directory ")])])])] : _vm._e()], 2)])])]);
};
var ListItemInfovue_type_template_id_3aebcc9e_staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-folder-open"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Last Modified:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Directory:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Parent Directory:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-folder-open"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v(" Date Created: ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Objects:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Item Count:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Published Date:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Approved Date:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Publisher:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('b', [_vm._v("Creator:")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass__right-aside--half-item"
  }, [_c('span', [_c('b', [_vm._v("Share:")])])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-edit"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-edit"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fas fa-users"
  })]);
}];

// CONCATENATED MODULE: ./src/components/framework/ListItemInfo.vue?vue&type=template&id=3aebcc9e

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/toConsumableArray.js + 3 modules
var toConsumableArray = __webpack_require__("2909");

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/arrayWithHoles.js
function _arrayWithHoles(r) {
  if (Array.isArray(r)) return r;
}

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__("a4d3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__("e01a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__("d28b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__("3ca3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/iterableToArrayLimit.js







function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js
var unsupportedIterableToArray = __webpack_require__("06c5");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.error.cause.js
var es_error_cause = __webpack_require__("d9e2");

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/nonIterableRest.js

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/slicedToArray.js




function _slicedToArray(r, e) {
  return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || Object(unsupportedIterableToArray["a" /* default */])(r, e) || _nonIterableRest();
}

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.iterator.constructor.js
var es_iterator_constructor = __webpack_require__("e9f5");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.iterator.filter.js
var es_iterator_filter = __webpack_require__("910d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.iterator.map.js
var es_iterator_map = __webpack_require__("ab43");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.entries.js
var es_object_entries = __webpack_require__("4fad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.js
var es_set = __webpack_require__("6062");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.difference.v2.js
var es_set_difference_v2 = __webpack_require__("1e70");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.intersection.v2.js
var es_set_intersection_v2 = __webpack_require__("79a4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.is-disjoint-from.v2.js
var es_set_is_disjoint_from_v2 = __webpack_require__("c1a1");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.is-subset-of.v2.js
var es_set_is_subset_of_v2 = __webpack_require__("8b00");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.is-superset-of.v2.js
var es_set_is_superset_of_v2 = __webpack_require__("a4e7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.symmetric-difference.v2.js
var es_set_symmetric_difference_v2 = __webpack_require__("1e5a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.union.v2.js
var es_set_union_v2 = __webpack_require__("72c3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/ListItemInfo.vue?vue&type=script&lang=js































/* harmony default export */ var ListItemInfovue_type_script_lang_js = ({
  name: 'ListItemInfo',
  mixins: [common["a" /* default */]],
  components: {},
  data: function data() {
    return {
      accordion: 'details',
      numSubdirectories: "unknown",
      numObjects: "unknown",
      copyingToDirectory: false,
      movingToDirectory: false,
      repo: window.repo,
      frameworksToProcess: 0,
      clipStatus: 'ready',
      ineligibleDirectoriesForMove: [],
      errorEditing: null,
      processingCopyOrMove: false,
      processingRemove: false
    };
  },
  methods: {
    deleteDirectory: function deleteDirectory() {
      this.$store.commit('app/showModal', {
        component: 'DeleteDirectoryConfirm'
      });
    },
    clickAccordion: function clickAccordion(item) {
      if (this.accordion === item) {
        this.accordion = '';
      } else {
        this.accordion = item;
      }
    },
    successfulClip: function successfulClip(_ref) {
      var _this = this;
      var value = _ref.value,
        event = _ref.event;
      appLog('success', value);
      this.clipStatus = 'success';
      setTimeout(function () {
        _this.clipStatus = 'ready';
      }, 1000);
    },
    errorClip: function errorClip(_ref2) {
      var _this2 = this;
      var value = _ref2.value,
        event = _ref2.event;
      appLog('error', value);
      this.clipStatus = 'error';
      setTimeout(function () {
        _this2.clipStatus = 'ready';
      }, 1000);
    },
    setNumSubdirectoriesAndObjects: function setNumSubdirectoriesAndObjects() {
      if (this.objectType === "Directory") {
        if (this.object.directories) {
          this.numSubdirectories = this.object.directories.length;
        } else {
          this.numSubdirectories = 0;
        }
        var objects = 0;
        if (this.object.frameworks) {
          objects += this.object.frameworks.length;
        }
        if (this.object.resources) {
          objects += this.object.resources.length;
        }
        this.numObjects = objects;
      }
    },
    openObject: function openObject() {
      var me = this;
      if (this.objectType === "Directory") {
        this.$store.commit('app/selectDirectory', this.object);
        if (this.$route.name !== "directory") {
          this.$router.push({
            name: "directory"
          });
        }
        this.$store.commit('app/closeRightAside');
      } else if (this.object.type === "CreativeWork") {
        window.open(this.object.url, '_blank');
      } else if (this.$store.getters['editor/conceptMode']) {
        this.$store.commit('app/selectDirectory', null);
        EcConceptScheme.get(this.object.id, function (success) {
          me.$store.commit('editor/framework', success);
          me.$store.commit('editor/clearFrameworkCommentData');
          me.$store.commit('app/setCanViewComments', me.canViewCommentsCurrentFramework());
          me.$store.commit('app/setCanAddComments', me.canAddCommentsCurrentFramework());
          me.$router.push({
            name: "conceptScheme",
            params: {
              frameworkId: me.object.id
            }
          });
        }, appError);
      } else if (this.$store.getters['editor/progressionMode']) {
        this.$store.commit('app/selectDirectory', null);
        EcConceptScheme.get(this.object.id, function (success) {
          me.$store.commit('editor/framework', success);
          me.$store.commit('editor/clearFrameworkCommentData');
          me.$store.commit('app/setCanViewComments', me.canViewCommentsCurrentFramework());
          me.$store.commit('app/setCanAddComments', me.canAddCommentsCurrentFramework());
          me.$router.push({
            name: "progressionModel",
            params: {
              frameworkId: me.object.id
            }
          });
        }, appError);
      } else if (this.objectType === "ConceptScheme") {
        this.$store.commit('app/selectDirectory', null);
        this.$store.commit('editor/conceptMode', true);
        EcConceptScheme.get(this.object.id, function (success) {
          me.$store.commit('editor/framework', success);
          me.$store.commit('editor/clearFrameworkCommentData');
          me.$store.commit('app/setCanViewComments', me.canViewCommentsCurrentFramework());
          me.$store.commit('app/setCanAddComments', me.canAddCommentsCurrentFramework());
          me.$router.push({
            name: "conceptScheme",
            params: {
              frameworkId: me.object.id
            }
          });
        }, appError);
      } else {
        this.$store.commit('app/selectDirectory', null);
        EcFramework.get(this.object.id, function (success) {
          me.$store.commit('editor/framework', success);
          me.$store.commit('editor/clearFrameworkCommentData');
          me.$store.commit('app/setCanViewComments', me.canViewCommentsCurrentFramework());
          me.$store.commit('app/setCanAddComments', me.canAddCommentsCurrentFramework());
          me.$router.push({
            name: "framework",
            params: {
              frameworkId: me.object.id
            }
          });
        }, appError);
      }
    },
    getName: function getName(field) {
      var name = EcArray.isArray(field) ? field : [field];
      if (schema.Thing.getDisplayStringFrom(name).toLowerCase().indexOf("http") !== -1) {
        return this.resolveNameFromUrl(schema.Thing.getDisplayStringFrom(name));
      } else {
        return schema.Thing.getDisplayStringFrom(name);
      }
    },
    goToParentDirectory: function goToParentDirectory() {
      var me = this;
      var directoryId = this.object.directory ? this.object.directory : this.object.parentDirectory;
      EcDirectory.get(directoryId, function (result) {
        me.$store.commit('app/selectDirectory', result);
        if (me.$route.name !== "directory") {
          me.$router.push({
            name: "directory"
          });
        }
        me.$store.commit('app/closeRightAside');
      }, appError);
    },
    copyOrMove: function () {
      var _copyOrMove2 = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee(directory, _copyOrMove) {
        return Object(regenerator["a" /* default */])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (_copyOrMove === 'copy') {
                this.copyingToDirectory = true;
              } else {
                this.movingToDirectory = true;
              }
              this.frameworksToProcess = 0;
              this.processingCopyOrMove = true;
              this.$Progress.start();
              if (this.copyingToDirectory) {
                this.$emit('beginCopy');
              } else if (this.movingToDirectory) {
                this.$emit('beginMove');
              }
              // To do: add confirmation step once we have this in the right spot
              if (!(this.copyingToDirectory && this.objectType === 'Framework')) {
                _context.n = 1;
                break;
              }
              this.copyFrameworkToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 1:
              if (!(this.copyingToDirectory && this.objectType === 'CreativeWork')) {
                _context.n = 2;
                break;
              }
              this.copyResourceToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 2:
              if (!(this.copyingToDirectory && this.objectType === 'Directory')) {
                _context.n = 3;
                break;
              }
              this.copySubdirectoryToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 3:
              if (!(this.copyingToDirectory && this.objectType === 'ConceptScheme')) {
                _context.n = 5;
                break;
              }
              _context.n = 4;
              return this.copyTaxonomyToDirectory(directory, this.object);
            case 4:
              _context.n = 9;
              break;
            case 5:
              if (!(this.movingToDirectory && this.objectType === 'Framework')) {
                _context.n = 6;
                break;
              }
              this.moveFrameworkToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 6:
              if (!(this.movingToDirectory && this.objectType === 'CreativeWork')) {
                _context.n = 7;
                break;
              }
              this.moveResourceToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 7:
              if (!(this.movingToDirectory && this.objectType === 'Directory')) {
                _context.n = 8;
                break;
              }
              this.moveSubdirectoryToDirectory(directory, this.object);
              _context.n = 9;
              break;
            case 8:
              if (!(this.movingToDirectory && this.objectType === 'ConceptScheme')) {
                _context.n = 9;
                break;
              }
              _context.n = 9;
              return this.moveTaxonomyToDirectory(directory, this.object);
            case 9:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      function copyOrMove(_x, _x2) {
        return _copyOrMove2.apply(this, arguments);
      }
      return copyOrMove;
    }(),
    removeFromDirectory: function () {
      var _removeFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee2() {
        return Object(regenerator["a" /* default */])().w(function (_context2) {
          while (1) switch (_context2.n) {
            case 0:
              this.$Progress.start();
              if (!(this.objectType === 'Framework')) {
                _context2.n = 2;
                break;
              }
              _context2.n = 1;
              return this.removeFrameworkFromDirectory(this.object);
            case 1:
              _context2.n = 7;
              break;
            case 2:
              if (!(this.objectType === 'CreativeWork')) {
                _context2.n = 4;
                break;
              }
              _context2.n = 3;
              return this.removeResourceFromDirectory(this.object);
            case 3:
              _context2.n = 7;
              break;
            case 4:
              if (!(this.objectType === 'Directory')) {
                _context2.n = 6;
                break;
              }
              _context2.n = 5;
              return this.removeSubdirectoryFromDirectory(this.object);
            case 5:
              _context2.n = 7;
              break;
            case 6:
              if (!(this.objectType === 'ConceptScheme')) {
                _context2.n = 7;
                break;
              }
              _context2.n = 7;
              return this.removeTaxonomyFromDirectory(this.object);
            case 7:
              return _context2.a(2);
          }
        }, _callee2, this);
      }));
      function removeFromDirectory() {
        return _removeFromDirectory.apply(this, arguments);
      }
      return removeFromDirectory;
    }(),
    multiput: function () {
      var _multiput = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee3(toSave, shouldRefresh) {
        return Object(regenerator["a" /* default */])().w(function (_context3) {
          while (1) switch (_context3.p = _context3.n) {
            case 0:
              this.frameworksToProcess--;
              if (!(this.frameworksToProcess <= 0)) {
                _context3.n = 4;
                break;
              }
              _context3.p = 1;
              _context3.n = 2;
              return this.repo.multiput(toSave);
            case 2:
              if (this.movingToDirectory) {
                // Remove the moved item from the right panel
                this.$store.commit('app/rightAsideObject', null);
                this.$store.commit('app/closeRightAside');
              }
              if (shouldRefresh) {
                // If removing or moving, need to refresh search results
                this.$store.commit('app/refreshSearch', true);
              }
            case 3:
              _context3.p = 3;
              this.processingCopyOrMove = false;
              this.$Progress.finish();
              this.copyingToDirectory = false;
              this.movingToDirectory = false;
              return _context3.f(3);
            case 4:
              return _context3.a(2);
          }
        }, _callee3, this, [[1,, 3, 4]]);
      }));
      function multiput(_x3, _x4) {
        return _multiput.apply(this, arguments);
      }
      return multiput;
    }(),
    getCopyTaxonomyName: function getCopyTaxonomyName(t) {
      var name = t['dcterms:title'];
      if (!EcArray.isArray(name)) {
        name = [name];
      }
      for (var each in name) {
        if (name[each]["@value"]) {
          name[each]["@value"] = "Copy of " + name[each]["@value"];
        } else {
          name[each] = "Copy of " + name[each];
        }
      }
      if (name.length === 1) {
        name = name[0];
      }
      return name;
    },
    getCopyFrameworkName: function getCopyFrameworkName(f) {
      var name = f.name;
      if (!EcArray.isArray(name)) {
        name = [name];
      }
      for (var each in name) {
        if (name[each]["@value"]) {
          name[each]["@value"] = "Copy of " + name[each]["@value"];
        } else {
          name[each] = "Copy of " + name[each];
        }
      }
      if (name.length === 1) {
        name = name[0];
      }
      return name;
    },
    copyTaxonomyToDirectory: function () {
      var _copyTaxonomyToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee4(directory, taxonomy, toSaveFromSubdirectory) {
        var toSave, t, name, idMap, taxons, newTaxons, _iterator, _step, taxon, newTaxon, _iterator2, _step2, obj, _i, _Object$entries, _Object$entries$_i, key, value;
        return Object(regenerator["a" /* default */])().w(function (_context4) {
          while (1) switch (_context4.n) {
            case 0:
              toSave = [];
              if (toSaveFromSubdirectory) {
                toSave = toSaveFromSubdirectory;
              }
              t = new EcConceptScheme();
              t.copyFrom(taxonomy);
              if (this.queryParams.newObjectEndpoint != null) {
                t.generateShortId(this.queryParams.newObjectEndpoint);
              } else {
                t.generateId(this.repo.selectedServer);
              }
              t.directory = directory.shortId();
              t["schema:dateCreated"] = new Date().toISOString();
              t["schema:dateModified"] = new Date().toISOString();
              delete t.owner;
              delete t.reader;
              if (directory.owner) {
                t.owner = directory.owner;
              }
              if (directory.reader) {
                t.reader = directory.reader;
              }
              if (EcIdentityManager.default.ids.length > 0) {
                t.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              name = this.getCopyTaxonomyName(t);
              t.name = name;
              t['ceasn:derivedFrom'] = taxonomy.id;
              // Original framework was encrypted, make sure the copy is too
              if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[taxonomy.shortId()]) {
                EcEncryptedValue.encryptOnSaveMap[t.shortId()] = true;
              }
              // Add this framework as a child of the directory
              if (!directory.taxonomies) {
                directory.taxonomies = [];
              }
              EcArray.setAdd(directory.taxonomies, t.shortId());
              toSave.push(directory);
              idMap = {};
              idMap[taxonomy.shortId()] = t.shortId();
              _context4.n = 1;
              return EcConcept.search(this.repo, 'skos\\:inScheme:"' + taxonomy.shortId() + '"', null, null, {
                size: 10000
              });
            case 1:
              taxons = _context4.v;
              // First pass, create new taxons with new IDs
              newTaxons = [];
              _iterator = Object(createForOfIteratorHelper["a" /* default */])(taxons);
              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  taxon = _step.value;
                  newTaxon = new EcConcept().copyFrom(taxon);
                  if (this.queryParams.newObjectEndpoint != null) {
                    newTaxon.generateShortId(this.queryParams.newObjectEndpoint);
                  } else {
                    newTaxon.generateId(this.repo.selectedServer);
                  }
                  idMap[taxon.shortId()] = newTaxon.shortId();
                  newTaxon["schema:dateCreated"] = new Date().toISOString();
                  newTaxon["schema:dateModified"] = new Date().toISOString();
                  delete newTaxon.owner;
                  delete newTaxon.reader;
                  if (t.owner) {
                    newTaxon.owner = t.owner;
                  }
                  if (t.reader) {
                    newTaxon.reader = t.reader;
                  }
                  if (EcIdentityManager.default.ids.length > 0) {
                    newTaxon.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
                  }
                  newTaxon['ceasn:derivedFrom'] = taxon.id;
                  // If the original competency was encrypted, make sure the copy is too
                  if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[taxon.shortId()]) {
                    EcEncryptedValue.encryptOnSaveMap[newTaxon.shortId()] = true;
                  }
                  newTaxons.push(newTaxon);
                }
                // Second pass, change properties inside new taxons to reflect new IDs
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
              _iterator2 = Object(createForOfIteratorHelper["a" /* default */])([t].concat(newTaxons));
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  obj = _step2.value;
                  for (_i = 0, _Object$entries = Object.entries(obj); _i < _Object$entries.length; _i++) {
                    _Object$entries$_i = _slicedToArray(_Object$entries[_i], 2), key = _Object$entries$_i[0], value = _Object$entries$_i[1];
                    if (Array.isArray(value)) {
                      obj[key] = value.map(function (x) {
                        if (idMap[x]) {
                          return idMap[x];
                        }
                        return x;
                      });
                    } else if (idMap[value]) {
                      obj[key] = idMap[value];
                    }
                  }
                  toSave.push(obj);
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
              _context4.n = 2;
              return this.multiput(toSave);
            case 2:
              return _context4.a(2);
          }
        }, _callee4, this);
      }));
      function copyTaxonomyToDirectory(_x5, _x6, _x7) {
        return _copyTaxonomyToDirectory.apply(this, arguments);
      }
      return copyTaxonomyToDirectory;
    }(),
    copyFrameworkToDirectory: function copyFrameworkToDirectory(directory, framework, toSaveFromSubdirectory) {
      var toSave = [];
      if (toSaveFromSubdirectory) {
        toSave = toSaveFromSubdirectory;
      }
      var f = new EcFramework();
      f.copyFrom(framework);
      if (f.competency && Array.isArray(f.competency)) {
        f.competency = Object(toConsumableArray["a" /* default */])(new Set(f.competency));
      }
      if (f.relation && Array.isArray(f.relation)) {
        f.relation = Object(toConsumableArray["a" /* default */])(new Set(f.relation));
      }
      if (this.queryParams.newObjectEndpoint != null) {
        f.generateShortId(this.queryParams.newObjectEndpoint);
      } else {
        f.generateId(this.repo.selectedServer);
      }
      f.directory = directory.shortId();
      f["schema:dateCreated"] = new Date().toISOString();
      f["schema:dateModified"] = new Date().toISOString();
      delete f.owner;
      delete f.reader;
      if (directory.owner) {
        f.owner = directory.owner;
      }
      if (directory.reader) {
        f.reader = directory.reader;
      }
      if (EcIdentityManager.default.ids.length > 0) {
        f.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
      }
      var name = this.getCopyFrameworkName(f);
      f.name = name;
      f['ceasn:derivedFrom'] = framework.id;
      // Original framework was encrypted, make sure the copy is too
      if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[framework.shortId()]) {
        EcEncryptedValue.encryptOnSaveMap[f.shortId()] = true;
      }
      // Add this framework as a child of the directory
      if (!directory.frameworks) {
        directory.frameworks = [];
      }
      EcArray.setAdd(directory.frameworks, f.shortId());
      toSave.push(directory);
      var competencyMap = {};
      // to do: replace all the competency (etc) URLs in framework object and THEN push framework obj
      if (framework.competency && framework.competency.length > 0) {
        this.copyCompetenciesToDirectory(f, toSave, competencyMap);
      } else if (framework.level && framework.level.length > 0) {
        this.copyLevelsToDirectory(f, toSave, competencyMap);
      } else if (framework.relation && framework.relation.length > 0) {
        this.copyRelationsToDirectory(f, toSave, competencyMap);
      } else {
        toSave.push(f);
        this.multiput(toSave);
      }
    },
    copyCompetenciesToDirectory: function copyCompetenciesToDirectory(framework, toSave, competencyMap) {
      var me = this;
      new EcAsyncHelper().each(framework.competency, function (competencyId, done) {
        EcCompetency.get(competencyId, function (competency) {
          var c = new EcCompetency();
          c.copyFrom(competency);
          if (me.queryParams.newObjectEndpoint != null) {
            c.generateShortId(me.queryParams.newObjectEndpoint);
          } else {
            c.generateId(me.repo.selectedServer);
          }
          competencyMap[competency.shortId()] = c.shortId();
          var index = framework.competency.indexOf(competencyId);
          if (index !== -1) {
            framework.competency[index] = c.shortId();
          }
          c["schema:dateCreated"] = new Date().toISOString();
          c["schema:dateModified"] = new Date().toISOString();
          delete c.owner;
          delete c.reader;
          if (framework.owner) {
            c.owner = framework.owner;
          }
          if (framework.reader) {
            c.reader = framework.reader;
          }
          if (EcIdentityManager.default.ids.length > 0) {
            c.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
          }
          c['ceasn:derivedFrom'] = competency.id;
          // If the original competency was encrypted, make sure the copy is too
          if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[competency.shortId()]) {
            EcEncryptedValue.encryptOnSaveMap[c.shortId()] = true;
          }
          toSave.push(c);
          done();
        }, done);
      }, function (competencyIds) {
        if (framework.level && framework.level.length > 0) {
          me.copyLevelsToDirectory(framework, toSave, competencyMap);
        } else if (framework.relation && framework.relation.length > 0) {
          me.copyRelationsToDirectory(framework, toSave, competencyMap);
        } else {
          toSave.push(framework);
          me.multiput(toSave);
        }
      });
    },
    copyLevelsToDirectory: function copyLevelsToDirectory(framework, toSave, competencyMap) {
      var me = this;
      new EcAsyncHelper().each(framework.level, function (levelId, done) {
        EcLevel.get(levelId, function (level) {
          var c = new EcLevel();
          c.copyFrom(level);
          if (me.queryParams.newObjectEndpoint != null) {
            c.generateShortId(me.queryParams.newObjectEndpoint);
          } else {
            c.generateId(me.repo.selectedServer);
          }
          // If original level was encrypted, encrypt the copy too
          if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[level.shortId()]) {
            EcEncryptedValue.encryptOnSaveMap[c.shortId()] = true;
          }
          var index = framework.level.indexOf(levelId);
          if (index !== -1) {
            framework.level[index] = c.shortId();
          }
          if (c.competency) {
            if (!EcArray.isArray(c.competency)) {
              c.competency = [c.competency];
            }
            for (var each in c.competency) {
              c.competency[each] = competencyMap[c.competency[each]];
            }
          }
          c["schema:dateCreated"] = new Date().toISOString();
          c["schema:dateModified"] = new Date().toISOString();
          delete c.owner;
          delete c.reader;
          if (framework.owner) {
            c.owner = framework.owner;
          }
          if (framework.reader) {
            c.reader = framework.reader;
          }
          if (EcIdentityManager.default.ids.length > 0) {
            c.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
          }
          c['ceasn:derivedFrom'] = level.id;
          toSave.push(c);
          done();
        }, done);
      }, function (competencyIds) {
        if (framework.relation && framework.relation.length > 0) {
          me.copyRelationsToDirectory(framework, toSave, competencyMap);
        } else {
          toSave.push(framework);
          me.multiput(toSave);
        }
      });
    },
    copyRelationsToDirectory: function copyRelationsToDirectory(framework, toSave, competencyMap) {
      var me = this;
      new EcAsyncHelper().each(framework.relation, function (relationId, done) {
        EcAlignment.get(relationId, function (relation) {
          var c = new EcAlignment();
          c.copyFrom(relation);
          if (me.queryParams.newObjectEndpoint != null) {
            c.generateShortId(me.queryParams.newObjectEndpoint);
          } else {
            c.generateId(me.repo.selectedServer);
          }
          // If original relation was encrypted, make sure copy is too
          if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[relation.shortId()]) {
            EcEncryptedValue.encryptOnSaveMap[c.shortId()] = true;
          }
          var index = framework.relation.indexOf(relationId);
          if (index !== -1) {
            framework.relation[index] = c.shortId();
          }
          if (relation.source && competencyMap[relation.source]) {
            c.source = competencyMap[relation.source];
          }
          if (relation.target && competencyMap[relation.target]) {
            c.target = competencyMap[relation.target];
          }
          c["schema:dateCreated"] = new Date().toISOString();
          c["schema:dateModified"] = new Date().toISOString();
          delete c.owner;
          delete c.reader;
          if (framework.owner) {
            c.owner = framework.owner;
          }
          if (framework.reader) {
            c.reader = framework.reader;
          }
          if (EcIdentityManager.default.ids.length > 0) {
            c.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
          }
          c['ceasn:derivedFrom'] = relation.id;
          toSave.push(c);
          done();
        }, done);
      }, function (competencyIds) {
        toSave.push(framework);
        me.multiput(toSave);
      });
    },
    copyResourceToDirectory: function copyResourceToDirectory(directory, resource, toSaveFromSubdirectory) {
      var me = this;
      var c = new schema.CreativeWork();
      if (this.queryParams.newObjectEndpoint != null) {
        c.generateShortId(this.queryParams.newObjectEndpoint);
      } else {
        c.generateId(this.repo.selectedServer);
      }
      c.name = "Copy of " + resource.name;
      c.url = resource.url;
      c.directory = directory.shortId();
      if (directory.owner) {
        c.owner = directory.owner;
      }
      if (directory.reader) {
        c.reader = directory.reader;
      }
      if (EcIdentityManager.default.ids.length > 0) {
        c.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
      }

      // If original resource is encrypted, make sure copy is too
      if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[resource.shortId()]) {
        EcEncryptedValue.encryptOnSaveMap[c.shortId()] = true;
      }
      // Add resource as a child of the directory
      if (!directory.resources) {
        directory.resources = [];
      }
      EcArray.setAdd(directory.resources, c.shortId());
      var toSave = [c, directory];
      if (toSaveFromSubdirectory) {
        toSave = toSave.concat(toSaveFromSubdirectory);
      }
      me.multiput(toSave);
    },
    copySubdirectoryToDirectory: function () {
      var _copySubdirectoryToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee5(directory, oldSubdirectory, passedInToSave) {
        var _toSave;
        var toSave, subdirectory, children, validChildren, _iterator3, _step3, _child, _obj, done, _i2, _validChildren, obj, _t, _t2, _t3;
        return Object(regenerator["a" /* default */])().w(function (_context5) {
          while (1) switch (_context5.p = _context5.n) {
            case 0:
              toSave = [];
              if (passedInToSave) {
                toSave = passedInToSave;
              }
              subdirectory = new EcDirectory();
              subdirectory.copyFrom(oldSubdirectory);
              if (this.queryParams.newObjectEndpoint != null) {
                subdirectory.generateShortId(this.queryParams.newObjectEndpoint);
              } else {
                subdirectory.generateId(this.repo.selectedServer);
              }
              subdirectory.parentDirectory = directory.shortId();
              subdirectory["schema:dateCreated"] = new Date().toISOString();
              subdirectory["schema:dateModified"] = new Date().toISOString();
              delete subdirectory.owner;
              delete subdirectory.reader;
              if (directory.owner) {
                subdirectory.owner = directory.owner;
              }
              if (directory.reader) {
                subdirectory.reader = directory.reader;
              }
              if (EcIdentityManager.default.ids.length > 0) {
                subdirectory.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              subdirectory['ceasn:derivedFrom'] = oldSubdirectory.id;
              subdirectory.name = "Copy of " + subdirectory.name;
              // If original directory was encrypted, make sure the copy is too
              if (EcEncryptedValue.encryptOnSaveMap && EcEncryptedValue.encryptOnSaveMap[oldSubdirectory.shortId()]) {
                EcEncryptedValue.encryptOnSaveMap[subdirectory.shortId()] = true;
              }
              // Add this directory as a child of the parent
              if (!directory.directories) {
                directory.directories = [];
              }
              EcArray.setAdd(directory.directories, subdirectory.shortId());
              _context5.n = 1;
              return this.$store.dispatch('editor/getDirectoryChildren', oldSubdirectory);
            case 1:
              children = _context5.v;
              // Remove children that do not resolve from the copy
              validChildren = [];
              _iterator3 = Object(createForOfIteratorHelper["a" /* default */])(children);
              _context5.p = 2;
              _iterator3.s();
            case 3:
              if ((_step3 = _iterator3.n()).done) {
                _context5.n = 10;
                break;
              }
              _child = _step3.value;
              _context5.p = 4;
              _context5.n = 5;
              return EcRepository.get(_child);
            case 5:
              _obj = _context5.v;
              if (!(_obj.type === 'EncryptedValue')) {
                _context5.n = 7;
                break;
              }
              _context5.n = 6;
              return EcEncryptedValue.fromEncryptedValue(_obj);
            case 6:
              _obj = _context5.v;
            case 7:
              validChildren.push(_obj);
              _context5.n = 9;
              break;
            case 8:
              _context5.p = 8;
              _t = _context5.v;
              EcArray.setRemove(subdirectory.directories || [], _child);
              EcArray.setRemove(subdirectory.frameworks || [], _child);
              EcArray.setRemove(subdirectory.resources || [], _child);
            case 9:
              _context5.n = 3;
              break;
            case 10:
              _context5.n = 12;
              break;
            case 11:
              _context5.p = 11;
              _t2 = _context5.v;
              _iterator3.e(_t2);
            case 12:
              _context5.p = 12;
              _iterator3.f();
              return _context5.f(12);
            case 13:
              (_toSave = toSave).push.apply(_toSave, [directory, subdirectory]);
              done = [];
              _i2 = 0, _validChildren = validChildren;
            case 14:
              if (!(_i2 < _validChildren.length)) {
                _context5.n = 25;
                break;
              }
              obj = _validChildren[_i2];
              _context5.p = 15;
              if (!(obj.type === 'Framework')) {
                _context5.n = 17;
                break;
              }
              _context5.n = 16;
              return this.copyFrameworkToDirectory(subdirectory, obj, toSave);
            case 16:
              _context5.n = 22;
              break;
            case 17:
              if (!(obj.type === 'CreativeWork')) {
                _context5.n = 19;
                break;
              }
              _context5.n = 18;
              return this.copyResourceToDirectory(subdirectory, obj, toSave);
            case 18:
              _context5.n = 22;
              break;
            case 19:
              if (!(obj.type === 'ConceptScheme')) {
                _context5.n = 21;
                break;
              }
              _context5.n = 20;
              return this.copyTaxonomyToDirectory(subdirectory, obj, toSave);
            case 20:
              _context5.n = 22;
              break;
            case 21:
              if (obj.type === 'Directory') {
                this.frameworksToProcess--;
                this.copySubdirectoryToDirectory(subdirectory, obj, toSave);
              }
            case 22:
              done.push(child);
              _context5.n = 24;
              break;
            case 23:
              _context5.p = 23;
              _t3 = _context5.v;
              appError(_t3);
            case 24:
              _i2++;
              _context5.n = 14;
              break;
            case 25:
              if (!(done.length === 0)) {
                _context5.n = 26;
                break;
              }
              _context5.n = 26;
              return this.multiput(toSave, true);
            case 26:
              return _context5.a(2);
          }
        }, _callee5, this, [[15, 23], [4, 8], [2, 11, 12, 13]]);
      }));
      function copySubdirectoryToDirectory(_x8, _x9, _x0) {
        return _copySubdirectoryToDirectory.apply(this, arguments);
      }
      return copySubdirectoryToDirectory;
    }(),
    moveTaxonomyToDirectory: function () {
      var _moveTaxonomyToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee6(directory, taxonomy, toSaveFromSubdirectory) {
        var _toSave3, _toSave2, _iterator4, _step4, each, taxons, _iterator5, _step5, taxon, _iterator6, _step6, _each, _t4;
        return Object(regenerator["a" /* default */])().w(function (_context6) {
          while (1) switch (_context6.p = _context6.n) {
            case 0:
              _context6.p = 0;
              _toSave2 = [];
              if (toSaveFromSubdirectory) {
                _toSave2 = toSaveFromSubdirectory;
              }

              // If the taxonomy was already in a directory, remove it first
              if (!taxonomy.directory) {
                _context6.n = 1;
                break;
              }
              _context6.n = 1;
              return this.removeTaxonomyFromDirectory(taxonomy);
            case 1:
              if (directory.owner) {
                _iterator4 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
                    each = _step4.value;
                    taxonomy.addOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator4.e(err);
                } finally {
                  _iterator4.f();
                }
              }
              taxonomy.reader = directory.reader;
              taxonomy.directory = directory.shortId();
              taxonomy["schema:dateModified"] = new Date().toISOString();
              // Add this taxonomy as a child of the directory
              if (!directory.taxonomies) {
                directory.taxonomies = [];
              }
              _context6.n = 2;
              return EcConcept.search(this.repo, 'skos\\:inScheme:"' + taxonomy.shortId() + '"', null, null, {
                size: 10000
              });
            case 2:
              taxons = _context6.v;
              _iterator5 = Object(createForOfIteratorHelper["a" /* default */])(taxons);
              try {
                for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                  taxon = _step5.value;
                  if (directory.owner) {
                    _iterator6 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                    try {
                      for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                        _each = _step6.value;
                        taxon.addOwner(EcPk.fromPem(_each));
                      }
                    } catch (err) {
                      _iterator6.e(err);
                    } finally {
                      _iterator6.f();
                    }
                  }
                  taxon.reader = directory.reader;
                  taxon["schema:dateModified"] = new Date().toISOString();
                  _toSave2.push(taxon);
                }
              } catch (err) {
                _iterator5.e(err);
              } finally {
                _iterator5.f();
              }
              EcArray.setAdd(directory.taxonomies, taxonomy.shortId());
              (_toSave3 = _toSave2).push.apply(_toSave3, [taxonomy, directory]);
              _context6.n = 3;
              return this.multiput(_toSave2, true);
            case 3:
              _context6.n = 5;
              break;
            case 4:
              _context6.p = 4;
              _t4 = _context6.v;
              appError(_t4);
            case 5:
              return _context6.a(2);
          }
        }, _callee6, this, [[0, 4]]);
      }));
      function moveTaxonomyToDirectory(_x1, _x10, _x11) {
        return _moveTaxonomyToDirectory.apply(this, arguments);
      }
      return moveTaxonomyToDirectory;
    }(),
    moveFrameworkToDirectory: function () {
      var _moveFrameworkToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee7(directory, framework, toSaveFromSubdirectory) {
        var _toSave5, _toSave4, _iterator7, _step7, each, subobjects, _t5;
        return Object(regenerator["a" /* default */])().w(function (_context7) {
          while (1) switch (_context7.p = _context7.n) {
            case 0:
              _context7.p = 0;
              _toSave4 = [];
              if (toSaveFromSubdirectory) {
                _toSave4 = toSaveFromSubdirectory;
              }
              if (framework.competency && Array.isArray(framework.competency)) {
                framework.competency = Object(toConsumableArray["a" /* default */])(new Set(framework.competency));
              }
              if (framework.relation && Array.isArray(framework.relation)) {
                framework.relation = Object(toConsumableArray["a" /* default */])(new Set(framework.relation));
              }

              // If the framework was already in a directory, remove it first
              if (!framework.directory) {
                _context7.n = 1;
                break;
              }
              _context7.n = 1;
              return this.removeFrameworkFromDirectory(framework);
            case 1:
              if (directory.owner) {
                _iterator7 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator7.s(); !(_step7 = _iterator7.n()).done;) {
                    each = _step7.value;
                    framework.addOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator7.e(err);
                } finally {
                  _iterator7.f();
                }
              }
              framework.reader = directory.reader;
              framework.directory = directory.shortId();
              framework["schema:dateModified"] = new Date().toISOString();
              // Add this framework as a child of the directory
              if (!directory.frameworks) {
                directory.frameworks = [];
              }
              EcArray.setAdd(directory.frameworks, framework.shortId());
              (_toSave5 = _toSave4).push.apply(_toSave5, [framework, directory]);
              subobjects = [];
              if (framework.competency && framework.competency.length > 0) {
                subobjects = framework.competency;
              }
              if (framework.level && framework.level.length > 0) {
                subobjects = subobjects.concat(framework.level);
              }
              if (framework.relation && framework.relation.length > 0) {
                subobjects = subobjects.concat(framework.relation);
              }
              if (!(subobjects.length > 0)) {
                _context7.n = 3;
                break;
              }
              _context7.n = 2;
              return this.moveSubobjectsToDirectory(subobjects, directory, _toSave4);
            case 2:
              _context7.n = 4;
              break;
            case 3:
              _context7.n = 4;
              return this.multiput(_toSave4, true);
            case 4:
              _context7.n = 6;
              break;
            case 5:
              _context7.p = 5;
              _t5 = _context7.v;
              appError(_t5);
            case 6:
              return _context7.a(2);
          }
        }, _callee7, this, [[0, 5]]);
      }));
      function moveFrameworkToDirectory(_x12, _x13, _x14) {
        return _moveFrameworkToDirectory.apply(this, arguments);
      }
      return moveFrameworkToDirectory;
    }(),
    moveSubobjectsToDirectory: function () {
      var _moveSubobjectsToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee8(subobjects, directory, toSave) {
        var me;
        return Object(regenerator["a" /* default */])().w(function (_context8) {
          while (1) switch (_context8.n) {
            case 0:
              me = this;
              return _context8.a(2, new Promise(function (resolve, reject) {
                new EcAsyncHelper().each(subobjects, function (id, done) {
                  EcRepository.get(id, function (obj) {
                    if (directory.owner) {
                      var _iterator8 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner),
                        _step8;
                      try {
                        for (_iterator8.s(); !(_step8 = _iterator8.n()).done;) {
                          var each = _step8.value;
                          obj.addOwner(EcPk.fromPem(each));
                        }
                      } catch (err) {
                        _iterator8.e(err);
                      } finally {
                        _iterator8.f();
                      }
                    }
                    obj.reader = directory.reader;
                    obj["schema:dateModified"] = new Date().toISOString();
                    toSave.push(obj);
                    done();
                  }, done);
                }, function (ids) {
                  me.multiput(toSave, true).then(resolve).catch(reject);
                });
              }));
          }
        }, _callee8, this);
      }));
      function moveSubobjectsToDirectory(_x15, _x16, _x17) {
        return _moveSubobjectsToDirectory.apply(this, arguments);
      }
      return moveSubobjectsToDirectory;
    }(),
    moveResourceToDirectory: function () {
      var _moveResourceToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee9(directory, resource, toSaveFromSubdirectory) {
        var me, _iterator9, _step9, each, toSave;
        return Object(regenerator["a" /* default */])().w(function (_context9) {
          while (1) switch (_context9.n) {
            case 0:
              me = this; // If the resource was already in a directory, remove it first
              if (!resource.directory) {
                _context9.n = 1;
                break;
              }
              _context9.n = 1;
              return this.removeResourceFromDirectory(resource);
            case 1:
              if (directory.owner) {
                _iterator9 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator9.s(); !(_step9 = _iterator9.n()).done;) {
                    each = _step9.value;
                    resource.addOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator9.e(err);
                } finally {
                  _iterator9.f();
                }
              }
              resource.reader = directory.reader;
              resource.directory = directory.shortId();
              // Add this resource as a child of the directory
              if (!directory.resources) {
                directory.resources = [];
              }
              EcArray.setAdd(directory.resources, resource.shortId());
              toSave = [directory, resource];
              if (toSaveFromSubdirectory) {
                toSave = toSave.concat(toSaveFromSubdirectory);
              }
              me.multiput(toSave, true);
            case 2:
              return _context9.a(2);
          }
        }, _callee9, this);
      }));
      function moveResourceToDirectory(_x18, _x19, _x20) {
        return _moveResourceToDirectory.apply(this, arguments);
      }
      return moveResourceToDirectory;
    }(),
    moveSubdirectoryToDirectory: function () {
      var _moveSubdirectoryToDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee1(directory, subdirectory, passedInToSave) {
        var _toSave6;
        var me, toSave, _iterator0, _step0, each, children, success;
        return Object(regenerator["a" /* default */])().w(function (_context1) {
          while (1) switch (_context1.n) {
            case 0:
              me = this;
              toSave = [];
              if (passedInToSave) {
                toSave = passedInToSave;
              }
              // If the subdirectory is already in a directory, remove it first
              if (!subdirectory.parentDirectory) {
                _context1.n = 1;
                break;
              }
              _context1.n = 1;
              return this.removeSubdirectoryFromDirectory(subdirectory);
            case 1:
              subdirectory.parentDirectory = directory.shortId();
              subdirectory["schema:dateModified"] = new Date().toISOString();
              if (directory.owner) {
                _iterator0 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator0.s(); !(_step0 = _iterator0.n()).done;) {
                    each = _step0.value;
                    subdirectory.addOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator0.e(err);
                } finally {
                  _iterator0.f();
                }
              }
              subdirectory.reader = directory.reader;
              // Add this directory as a child of the directory
              if (!directory.directories) {
                directory.directories = [];
              }
              EcArray.setAdd(directory.directories, subdirectory.shortId());
              (_toSave6 = toSave).push.apply(_toSave6, [subdirectory, directory]);
              _context1.n = 2;
              return this.$store.dispatch('editor/getDirectoryChildren', subdirectory);
            case 2:
              children = _context1.v;
              _context1.n = 3;
              return window.repo.multiget(children);
            case 3:
              success = _context1.v;
              this.frameworksToProcess += success.length;
              return _context1.a(2, new Promise(function (resolve, reject) {
                new EcAsyncHelper().each(success, /*#__PURE__*/function () {
                  var _ref3 = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee0(obj, done) {
                    return Object(regenerator["a" /* default */])().w(function (_context0) {
                      while (1) switch (_context0.n) {
                        case 0:
                          if (!(obj.type === 'EncryptedValue')) {
                            _context0.n = 2;
                            break;
                          }
                          _context0.n = 1;
                          return EcEncryptedValue.fromEncryptedValue(obj);
                        case 1:
                          obj = _context0.v;
                        case 2:
                          if (!(obj.type === 'Framework')) {
                            _context0.n = 4;
                            break;
                          }
                          _context0.n = 3;
                          return me.moveFrameworkToDirectory(subdirectory, obj, toSave);
                        case 3:
                          _context0.n = 10;
                          break;
                        case 4:
                          if (!(obj.type === 'CreativeWork')) {
                            _context0.n = 6;
                            break;
                          }
                          _context0.n = 5;
                          return me.moveResourceToDirectory(subdirectory, obj, toSave);
                        case 5:
                          _context0.n = 10;
                          break;
                        case 6:
                          if (!(obj.type === 'ConceptScheme')) {
                            _context0.n = 8;
                            break;
                          }
                          _context0.n = 7;
                          return me.moveTaxonomyToDirectory(subdirectory, obj, toSave);
                        case 7:
                          _context0.n = 10;
                          break;
                        case 8:
                          if (!(obj.type === "Directory")) {
                            _context0.n = 10;
                            break;
                          }
                          _context0.n = 9;
                          return me.frameworksToProcess--;
                        case 9:
                          _context0.n = 10;
                          return me.moveSubdirectoryToDirectory(subdirectory, obj, toSave);
                        case 10:
                          done();
                        case 11:
                          return _context0.a(2);
                      }
                    }, _callee0);
                  }));
                  return function (_x24, _x25) {
                    return _ref3.apply(this, arguments);
                  };
                }(), function (ids) {
                  if (ids.length === 0) {
                    me.multiput(toSave, true).then(resolve).catch(reject);
                  } else {
                    resolve();
                  }
                });
              }));
          }
        }, _callee1, this);
      }));
      function moveSubdirectoryToDirectory(_x21, _x22, _x23) {
        return _moveSubdirectoryToDirectory.apply(this, arguments);
      }
      return moveSubdirectoryToDirectory;
    }(),
    removeTaxonomyFromDirectory: function () {
      var _removeTaxonomyFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee10(taxonomy) {
        var me, _toSave7, directory, _iterator1, _step1, each, _iterator10, _step10, _each2;
        return Object(regenerator["a" /* default */])().w(function (_context10) {
          while (1) switch (_context10.p = _context10.n) {
            case 0:
              this.processingRemove = true;
              _context10.p = 1;
              me = this;
              _toSave7 = [];
              this.$Progress.start();
              _context10.n = 2;
              return EcDirectory.get(taxonomy.directory);
            case 2:
              directory = _context10.v;
              if (directory.owner) {
                _iterator1 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator1.s(); !(_step1 = _iterator1.n()).done;) {
                    each = _step1.value;
                    taxonomy.removeOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator1.e(err);
                } finally {
                  _iterator1.f();
                }
                taxonomy.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              if (directory.reader) {
                _iterator10 = Object(createForOfIteratorHelper["a" /* default */])(directory.reader);
                try {
                  for (_iterator10.s(); !(_step10 = _iterator10.n()).done;) {
                    _each2 = _step10.value;
                    taxonomy.removeReader(EcPk.fromPem(_each2));
                  }
                } catch (err) {
                  _iterator10.e(err);
                } finally {
                  _iterator10.f();
                }
              }
              delete taxonomy.directory;
              taxonomy["schema:dateModified"] = new Date().toISOString();
              // remove this framework from the list of children
              if (directory.taxonomies) {
                EcArray.setRemove(directory.taxonomies, taxonomy.shortId());
              }
              _toSave7.push.apply(_toSave7, [taxonomy, directory]);
              _context10.n = 3;
              return me.multiput(_toSave7, true);
            case 3:
              _context10.p = 3;
              this.processingRemove = false;
              return _context10.f(3);
            case 4:
              return _context10.a(2);
          }
        }, _callee10, this, [[1,, 3, 4]]);
      }));
      function removeTaxonomyFromDirectory(_x26) {
        return _removeTaxonomyFromDirectory.apply(this, arguments);
      }
      return removeTaxonomyFromDirectory;
    }(),
    removeFrameworkFromDirectory: function () {
      var _removeFrameworkFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee11(framework) {
        var me, _toSave8, directory, _iterator11, _step11, each, _iterator12, _step12, _each3, subobjects;
        return Object(regenerator["a" /* default */])().w(function (_context11) {
          while (1) switch (_context11.p = _context11.n) {
            case 0:
              this.processingRemove = true;
              _context11.p = 1;
              me = this;
              _toSave8 = [];
              this.$Progress.start();
              _context11.n = 2;
              return EcDirectory.get(framework.directory);
            case 2:
              directory = _context11.v;
              if (directory.owner) {
                _iterator11 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator11.s(); !(_step11 = _iterator11.n()).done;) {
                    each = _step11.value;
                    framework.removeOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator11.e(err);
                } finally {
                  _iterator11.f();
                }
                framework.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              if (directory.reader) {
                _iterator12 = Object(createForOfIteratorHelper["a" /* default */])(directory.reader);
                try {
                  for (_iterator12.s(); !(_step12 = _iterator12.n()).done;) {
                    _each3 = _step12.value;
                    framework.removeReader(EcPk.fromPem(_each3));
                  }
                } catch (err) {
                  _iterator12.e(err);
                } finally {
                  _iterator12.f();
                }
              }
              delete framework.directory;
              framework["schema:dateModified"] = new Date().toISOString();
              // remove this framework from the list of children
              if (directory.frameworks) {
                EcArray.setRemove(directory.frameworks, framework.shortId());
              }
              _toSave8.push.apply(_toSave8, [framework, directory]);
              subobjects = [];
              if (framework.competency && framework.competency.length > 0) {
                subobjects = framework.competency;
              }
              if (framework.level && framework.level.length > 0) {
                subobjects = subobjects.concat(framework.level);
              }
              if (framework.relation && framework.relation.length > 0) {
                subobjects = subobjects.concat(framework.relation);
              }
              if (!(subobjects.length > 0)) {
                _context11.n = 4;
                break;
              }
              _context11.n = 3;
              return me.removeSubobjectsFromDirectory(subobjects, directory, _toSave8);
            case 3:
              _context11.n = 5;
              break;
            case 4:
              _context11.n = 5;
              return me.multiput(_toSave8, true);
            case 5:
              _context11.p = 5;
              this.processingRemove = false;
              return _context11.f(5);
            case 6:
              return _context11.a(2);
          }
        }, _callee11, this, [[1,, 5, 6]]);
      }));
      function removeFrameworkFromDirectory(_x27) {
        return _removeFrameworkFromDirectory.apply(this, arguments);
      }
      return removeFrameworkFromDirectory;
    }(),
    removeSubobjectsFromDirectory: function () {
      var _removeSubobjectsFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee13(subobjects, directory, toSave) {
        var me;
        return Object(regenerator["a" /* default */])().w(function (_context13) {
          while (1) switch (_context13.n) {
            case 0:
              me = this;
              return _context13.a(2, new Promise(function (resolve, reject) {
                new EcAsyncHelper().each(subobjects, function (id, done) {
                  EcRepository.get(id, /*#__PURE__*/function () {
                    var _ref4 = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee12(obj) {
                      var _iterator13, _step13, each, _iterator14, _step14, _each4;
                      return Object(regenerator["a" /* default */])().w(function (_context12) {
                        while (1) switch (_context12.n) {
                          case 0:
                            if (directory.owner) {
                              _iterator13 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                              try {
                                for (_iterator13.s(); !(_step13 = _iterator13.n()).done;) {
                                  each = _step13.value;
                                  obj.removeOwner(EcPk.fromPem(each));
                                }
                              } catch (err) {
                                _iterator13.e(err);
                              } finally {
                                _iterator13.f();
                              }
                              obj.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
                            }
                            if (directory.reader) {
                              _iterator14 = Object(createForOfIteratorHelper["a" /* default */])(directory.reader);
                              try {
                                for (_iterator14.s(); !(_step14 = _iterator14.n()).done;) {
                                  _each4 = _step14.value;
                                  obj.removeReader(EcPk.fromPem(_each4));
                                }
                              } catch (err) {
                                _iterator14.e(err);
                              } finally {
                                _iterator14.f();
                              }
                            }
                            obj["schema:dateModified"] = new Date().toISOString();
                            toSave.push(obj);
                            done();
                          case 1:
                            return _context12.a(2);
                        }
                      }, _callee12);
                    }));
                    return function (_x31) {
                      return _ref4.apply(this, arguments);
                    };
                  }(), done);
                }, function (ids) {
                  me.multiput(toSave, true).then(resolve).catch(reject);
                });
              }));
          }
        }, _callee13, this);
      }));
      function removeSubobjectsFromDirectory(_x28, _x29, _x30) {
        return _removeSubobjectsFromDirectory.apply(this, arguments);
      }
      return removeSubobjectsFromDirectory;
    }(),
    removeResourceFromDirectory: function () {
      var _removeResourceFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee14(object) {
        var directory, _iterator15, _step15, each, _iterator16, _step16, _each5;
        return Object(regenerator["a" /* default */])().w(function (_context14) {
          while (1) switch (_context14.n) {
            case 0:
              _context14.n = 1;
              return EcDirectory.get(object.directory);
            case 1:
              directory = _context14.v;
              if (directory.owner) {
                _iterator15 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator15.s(); !(_step15 = _iterator15.n()).done;) {
                    each = _step15.value;
                    object.removeOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator15.e(err);
                } finally {
                  _iterator15.f();
                }
                object.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              if (directory.reader) {
                _iterator16 = Object(createForOfIteratorHelper["a" /* default */])(directory.reader);
                try {
                  for (_iterator16.s(); !(_step16 = _iterator16.n()).done;) {
                    _each5 = _step16.value;
                    object.removeReader(EcPk.fromPem(_each5));
                  }
                } catch (err) {
                  _iterator16.e(err);
                } finally {
                  _iterator16.f();
                }
              }
              delete object.directory;
              // Remove this resource from the list of children
              if (directory.resources) {
                EcArray.setRemove(directory.resources, object.shortId());
              }
              toSave = [object, directory];
              _context14.n = 2;
              return this.multiput(toSave, true);
            case 2:
              return _context14.a(2);
          }
        }, _callee14, this);
      }));
      function removeResourceFromDirectory(_x32) {
        return _removeResourceFromDirectory.apply(this, arguments);
      }
      return removeResourceFromDirectory;
    }(),
    removeSubdirectoryFromDirectory: function () {
      var _removeSubdirectoryFromDirectory = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee16(subdirectory) {
        var me, toSave, directory, _iterator17, _step17, each, _iterator18, _step18, _each6, children, success;
        return Object(regenerator["a" /* default */])().w(function (_context16) {
          while (1) switch (_context16.n) {
            case 0:
              me = this;
              toSave = [];
              _context16.n = 1;
              return EcDirectory.get(subdirectory.parentDirectory);
            case 1:
              directory = _context16.v;
              if (directory.owner) {
                _iterator17 = Object(createForOfIteratorHelper["a" /* default */])(directory.owner);
                try {
                  for (_iterator17.s(); !(_step17 = _iterator17.n()).done;) {
                    each = _step17.value;
                    subdirectory.removeOwner(EcPk.fromPem(each));
                  }
                } catch (err) {
                  _iterator17.e(err);
                } finally {
                  _iterator17.f();
                }
                subdirectory.addOwner(EcIdentityManager.default.ids[0].ppk.toPk());
              }
              if (directory.reader) {
                _iterator18 = Object(createForOfIteratorHelper["a" /* default */])(directory.reader);
                try {
                  for (_iterator18.s(); !(_step18 = _iterator18.n()).done;) {
                    _each6 = _step18.value;
                    subdirectory.removeReader(EcPk.fromPem(_each6));
                  }
                } catch (err) {
                  _iterator18.e(err);
                } finally {
                  _iterator18.f();
                }
              }
              delete subdirectory.parentDirectory;
              subdirectory["schema:dateModified"] = new Date().toISOString();
              // Remove this directory from the list of children
              if (directory.directories) {
                EcArray.setRemove(directory.directories, subdirectory.shortId());
              }
              toSave.push.apply(toSave, [subdirectory, directory]);
              _context16.n = 2;
              return me.$store.dispatch('editor/getDirectoryChildren', subdirectory);
            case 2:
              children = _context16.v;
              _context16.n = 3;
              return window.repo.multiget(children);
            case 3:
              success = _context16.v;
              this.frameworksToProcess = success.length;
              return _context16.a(2, new Promise(function (resolve, reject) {
                new EcAsyncHelper().each(success, /*#__PURE__*/function () {
                  var _ref5 = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee15(obj, done) {
                    var subobjects;
                    return Object(regenerator["a" /* default */])().w(function (_context15) {
                      while (1) switch (_context15.n) {
                        case 0:
                          subobjects = [];
                          subobjects.push(obj.shortId());
                          if (obj.competency && obj.competency.length > 0) {
                            subobjects = subobjects.concat(obj.competency);
                          }
                          if (obj.level && obj.level.length > 0) {
                            subobjects = subobjects.concat(obj.level);
                          }
                          if (obj.relation && obj.relation.length > 0) {
                            subobjects = subobjects.concat(obj.relation);
                          }
                          if (!(subobjects.length > 0)) {
                            _context15.n = 1;
                            break;
                          }
                          _context15.n = 1;
                          return me.removeSubobjectsFromDirectory(subobjects, directory, toSave);
                        case 1:
                          done();
                        case 2:
                          return _context15.a(2);
                      }
                    }, _callee15);
                  }));
                  return function (_x34, _x35) {
                    return _ref5.apply(this, arguments);
                  };
                }(), function (ids) {
                  if (ids.length === 0) {
                    me.multiput(toSave, true).then(resolve).catch(reject);
                  } else {
                    resolve();
                  }
                });
              }));
          }
        }, _callee16, this);
      }));
      function removeSubdirectoryFromDirectory(_x33) {
        return _removeSubdirectoryFromDirectory.apply(this, arguments);
      }
      return removeSubdirectoryFromDirectory;
    }(),
    // Make sure user can't move directory into its child/grandchild/etc
    setIneligibleDirectoriesForMove: function () {
      var _setIneligibleDirectoriesForMove = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee17(obj) {
        var _iterator19, _step19, _child2, childObj, _t6;
        return Object(regenerator["a" /* default */])().w(function (_context17) {
          while (1) switch (_context17.p = _context17.n) {
            case 0:
              if (!obj.directories) {
                _context17.n = 8;
                break;
              }
              _iterator19 = Object(createForOfIteratorHelper["a" /* default */])(obj.directories);
              _context17.p = 1;
              _iterator19.s();
            case 2:
              if ((_step19 = _iterator19.n()).done) {
                _context17.n = 5;
                break;
              }
              _child2 = _step19.value;
              _context17.n = 3;
              return EcRepository.get(_child2);
            case 3:
              childObj = _context17.v;
              this.ineligibleDirectoriesForMove.push(childObj.shortId());
              _context17.n = 4;
              return this.setIneligibleDirectoriesForMove(childObj);
            case 4:
              _context17.n = 2;
              break;
            case 5:
              _context17.n = 7;
              break;
            case 6:
              _context17.p = 6;
              _t6 = _context17.v;
              _iterator19.e(_t6);
            case 7:
              _context17.p = 7;
              _iterator19.f();
              return _context17.f(7);
            case 8:
              return _context17.a(2);
          }
        }, _callee17, this, [[1, 6, 7, 8]]);
      }));
      function setIneligibleDirectoriesForMove(_x36) {
        return _setIneligibleDirectoriesForMove.apply(this, arguments);
      }
      return setIneligibleDirectoriesForMove;
    }(),
    manageUsers: function manageUsers() {
      this.$store.commit('app/objForShareModal', this.object);
      this.$store.commit('app/showModal', {
        component: 'Share'
      });
    },
    editDirectory: function editDirectory() {
      this.$store.commit('app/editDirectory', true);
    }
  },
  mounted: function () {
    var _mounted = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee18() {
      var type, obj, _t7;
      return Object(regenerator["a" /* default */])().w(function (_context18) {
        while (1) switch (_context18.n) {
          case 0:
            this.setNumSubdirectoriesAndObjects();
            if (!this.object.encryptedType) {
              _context18.n = 2;
              break;
            }
            type = "Ec" + this.object.encryptedType;
            obj = new window[type]();
            _t7 = obj;
            _context18.n = 1;
            return EcEncryptedValue.fromEncryptedValue(this.object);
          case 1:
            _t7.copyFrom.call(_t7, _context18.v);
            this.$store.commit('app/rightAsideObject', obj);
          case 2:
            if (this.object.type === "Directory") {
              this.setIneligibleDirectoriesForMove(this.object);
            }
          case 3:
            return _context18.a(2);
        }
      }, _callee18, this);
    }));
    function mounted() {
      return _mounted.apply(this, arguments);
    }
    return mounted;
  }(),
  computed: {
    isCeasn: function isCeasn() {
      if (this.queryParams["ceasnDataFields"] && this.queryParams["ceasnDataFields"] === 'true') {
        return true;
      } else {
        return false;
      }
    },
    objectName: function objectName() {
      var name = this.object.name;
      if (!name && this.object["dcterms:title"]) {
        name = this.object["dcterms:title"];
      } else if (!name && this.object["skos:prefLabel"]) {
        name = this.object["skos:prefLabel"];
      }
      return schema.Thing.getDisplayStringFrom(name);
    },
    objectDescription: function objectDescription() {
      var description = this.object.description;
      if (!description && this.object["dcterms:description"]) {
        description = this.object["dcterms:description"];
      } else if (!description && this.object["skos:definition"]) {
        description = this.object["skos:definition"];
      }
      return schema.Thing.getDisplayStringFrom(description);
    },
    objectShortId: function objectShortId() {
      return this.object.shortId();
    },
    object: function object() {
      return this.$store.getters['app/rightAsideObject'];
    },
    objectType: function objectType() {
      return this.object.type;
    },
    objectTypeForDisplay: function objectTypeForDisplay() {
      if (this.objectType === 'CreativeWork') {
        return "Resource";
      }
      if (this.objectType === "ConceptScheme" && this.object.subType === "Progression") {
        return "Progression";
      }
      if (this.objectType === "ConceptScheme") {
        if (this.queryParams.ceasnDataFields === 'true') {
          return "Concept Scheme";
        } else {
          return "Taxonomy";
        }
      }
      if (this.objectType === "Framework" && this.object.subType === "Collection") {
        return "Collection";
      }
      return this.objectType;
    },
    lastModified: function lastModified() {
      if (this.object.getTimestamp()) {
        return this.$moment(new Date(this.object.getTimestamp())).format("MMM D YYYY");
      }
      if (this.object["schema:dateModified"]) {
        return this.$moment(new Date(this.object['schema:dateModified'])).format("MMM D YYYY");
      }
      return "unknown";
    },
    dateCreated: function dateCreated() {
      if (this.object["schema:dateCreated"]) {
        return this.$moment(new Date(this.object['schema:dateCreated'])).format("MMM D YYYY");
      }
      return "unknown";
    },
    publisherName: function publisherName() {
      if (this.object['ceasn:publisherName']) {
        if (this.getName(this.object['ceasn:publisherName'])) {
          return this.getName(this.object['ceasn:publisherName']);
        }
      }
      if (this.object['schema:publisher']) {
        if (this.getName(this.object['schema:publisher'])) {
          return this.getName(this.object['schema:publisher']);
        }
      }
      return null;
    },
    creatorName: function creatorName() {
      if (this.object['schema:creator']) {
        if (this.getName(this.object['schema:creator'])) {
          return this.getName(this.object['schema:creator']);
        }
      }
      return null;
    },
    shareLink: function shareLink() {
      var link = window.location.href;
      link = link.replace('/frameworks', '').replace('/directory', '');
      if (this.objectType === "Directory") {
        if (link.contains('?')) {
          return link + "&directoryId=" + this.objectShortId;
        } else {
          return link + "?directoryId=" + this.objectShortId;
        }
      } else if (this.$store.getters['editor/conceptMode'] === true || this.$store.getters['editor/progressionMode'] === true) {
        if (link.contains('?')) {
          return link + "&concepts=true&frameworkId=" + this.objectShortId;
        } else {
          return link + "?concepts=true&frameworkId=" + this.objectShortId;
        }
      }
      if (link.contains('?')) {
        return link + "&frameworkId=" + this.objectShortId;
      } else {
        return link + "?frameworkId=" + this.objectShortId;
      }
    },
    copyDirectoryOptions: function copyDirectoryOptions() {
      var me = this;
      return this.$store.getters['app/directoryList'].filter(function (directory) {
        return directory.shortId() !== me.object.shortId() && (me.object.parentDirectory ? directory.shortId() !== me.object.parentDirectory : true) && (me.object.directory ? directory.shortId() !== me.object.directory : true);
      });
    },
    moveDirectoryOptions: function moveDirectoryOptions() {
      var me = this;
      if (this.objectType === "Directory") {
        return this.$store.getters['app/directoryList'].filter(function (directory) {
          return directory.shortId() !== me.object.shortId() && (me.object.parentDirectory ? directory.shortId() !== me.object.parentDirectory : true) && (me.object.directory ? directory.shortId() !== me.object.directory : true) && !EcArray.has(me.ineligibleDirectoriesForMove, directory.shortId());
        });
      } else {
        return this.$store.getters['app/directoryList'].filter(function (directory) {
          return directory.shortId() !== me.object.shortId() && (me.object.parentDirectory ? directory.shortId() !== me.object.parentDirectory : true) && (me.object.directory ? directory.shortId() !== me.object.directory : true);
        });
      }
    },
    canEditObject: function canEditObject() {
      return this.canEditAny(this.object);
    },
    queryParams: function queryParams() {
      return this.$store.getters['editor/queryParams'];
    },
    loggedInPerson: function loggedInPerson() {
      return this.$store.getters['user/loggedOnPerson'];
    },
    selectedDirectoryId: function selectedDirectoryId() {
      if (this.$store.getters['app/selectedDirectory']) {
        return this.$store.getters['app/selectedDirectory'].shortId();
      }
      return null;
    }
  },
  watch: {
    objectShortId: function objectShortId() {
      this.copyingToDirectory = false;
      this.movingToDirectory = false;
      this.ineligibleDirectoriesForMove = [];
      this.setNumSubdirectoriesAndObjects();
      if (this.object.type === "Directory") {
        this.setIneligibleDirectoriesForMove(this.object);
      }
    }
  }
});
// CONCATENATED MODULE: ./src/components/framework/ListItemInfo.vue?vue&type=script&lang=js
 /* harmony default export */ var framework_ListItemInfovue_type_script_lang_js = (ListItemInfovue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/framework/ListItemInfo.vue?vue&type=style&index=0&id=3aebcc9e&prod&lang=scss
var ListItemInfovue_type_style_index_0_id_3aebcc9e_prod_lang_scss = __webpack_require__("3558");

// CONCATENATED MODULE: ./src/components/framework/ListItemInfo.vue






/* normalize component */

var ListItemInfo_component = Object(componentNormalizer["a" /* default */])(
  framework_ListItemInfovue_type_script_lang_js,
  ListItemInfovue_type_template_id_3aebcc9e_render,
  ListItemInfovue_type_template_id_3aebcc9e_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var ListItemInfo = (ListItemInfo_component.exports);
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__("fb6a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"40f1aa7e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/frameworks/FilterAndSort.vue?vue&type=template&id=e134a7f8


var FilterAndSortvue_type_template_id_e134a7f8_render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "cass--right-aside--content"
  }, [_c('div', {
    staticClass: "section"
  }, [_c('h3', {
    staticClass: "title is-size-4"
  }, [_vm._v(" Filter and Sort ")]), _c('div', {
    staticClass: "filter-sort-section"
  }, [_c('h3', {
    staticClass: "filter-sort-header"
  }, [_vm._v(" Sort by ")]), _vm._l(_vm.sortResults, function (option) {
    return _c('div', {
      key: option,
      staticClass: "field"
    }, [option.enabled ? [_c('input', {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: _vm.sortBy,
        expression: "sortBy"
      }],
      staticClass: "is-checkradio",
      attrs: {
        "disabled": _vm.isFirstSearchProcessing,
        "id": option.id,
        "type": "radio",
        "name": "sortResults"
      },
      domProps: {
        "value": {
          id: option.id,
          label: option.label
        },
        "checked": _vm._q(_vm.sortBy, {
          id: option.id,
          label: option.label
        })
      },
      on: {
        "change": function change($event) {
          _vm.sortBy = {
            id: option.id,
            label: option.label
          };
        }
      }
    }), _c('label', {
      staticClass: "label",
      attrs: {
        "for": option.id
      }
    }, [_vm._v(_vm._s(option.label))])] : _vm._e()], 2);
  })], 2), _vm.showQuickFilterHeading && !(_vm.$store.getters['editor/conceptMode'] && !_vm.loggedIn) && !(_vm.$store.getters['editor/progressionMode'] && !_vm.loggedIn) ? _c('div', {
    staticClass: "filter-sort-section"
  }, [_c('h3', {
    staticClass: "filter-sort-header"
  }, [_vm._v(" Quick Filters ")]), _vm._l(_vm.quickFilters, function (option) {
    return _c('div', {
      key: option,
      staticClass: "field"
    }, [option.enabled ? [_c('input', {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: option.checked,
        expression: "option.checked"
      }],
      staticClass: "is-checkradio",
      attrs: {
        "disabled": _vm.isFirstSearchProcessing,
        "id": option.id,
        "type": "checkbox",
        "name": option.id
      },
      domProps: {
        "checked": Array.isArray(option.checked) ? _vm._i(option.checked, null) > -1 : option.checked
      },
      on: {
        "change": function change($event) {
          var $$a = option.checked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(option, "checked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(option, "checked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(option, "checked", $$c);
          }
        }
      }
    }), _c('label', {
      staticClass: "label",
      attrs: {
        "for": option.id
      }
    }, [_vm._v(_vm._s(option.label))])] : _vm._e()], 2);
  })], 2) : _vm._e(), !_vm.$store.getters['editor/conceptMode'] && !_vm.$store.getters['editor/progressionMode'] ? _c('div', {
    staticClass: "filter-sort-section"
  }, [_c('h3', {
    staticClass: "filter-sort-header"
  }, [_vm._v(" Apply search term to ")]), _vm._l(_vm.applySearchTo, function (option) {
    return _c('div', {
      key: option,
      staticClass: "field"
    }, [option.enabled ? [_c('input', {
      directives: [{
        name: "model",
        rawName: "v-model",
        value: option.checked,
        expression: "option.checked"
      }],
      staticClass: "is-checkradio",
      attrs: {
        "disabled": _vm.isFirstSearchProcessing,
        "id": option.id,
        "type": "checkbox",
        "name": option.id
      },
      domProps: {
        "checked": Array.isArray(option.checked) ? _vm._i(option.checked, null) > -1 : option.checked
      },
      on: {
        "change": function change($event) {
          var $$a = option.checked,
            $$el = $event.target,
            $$c = $$el.checked ? true : false;
          if (Array.isArray($$a)) {
            var $$v = null,
              $$i = _vm._i($$a, $$v);
            if ($$el.checked) {
              $$i < 0 && _vm.$set(option, "checked", $$a.concat([$$v]));
            } else {
              $$i > -1 && _vm.$set(option, "checked", $$a.slice(0, $$i).concat($$a.slice($$i + 1)));
            }
          } else {
            _vm.$set(option, "checked", $$c);
          }
        }
      }
    }), _c('label', {
      staticClass: "label",
      attrs: {
        "for": option.id
      }
    }, [_vm._v(_vm._s(option.label))])] : _vm._e()], 2);
  })], 2) : _vm._e()])]);
};
var FilterAndSortvue_type_template_id_e134a7f8_staticRenderFns = [];

// CONCATENATED MODULE: ./src/components/frameworks/FilterAndSort.vue?vue&type=template&id=e134a7f8

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.trim.js
var es_string_trim = __webpack_require__("498a");

// EXTERNAL MODULE: ./src/mixins/ctdlasnProfile.js
var ctdlasnProfile = __webpack_require__("f188");

// EXTERNAL MODULE: ./src/mixins/tlaProfile.js
var tlaProfile = __webpack_require__("d6b4");

// EXTERNAL MODULE: ./src/mixins/cassUtil.js
var cassUtil = __webpack_require__("6d79");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/frameworks/FilterAndSort.vue?vue&type=script&lang=js













/* harmony default export */ var FilterAndSortvue_type_script_lang_js = ({
  name: 'FilterAndSort',
  data: function data() {
    return {
      sortResults: [{
        id: 'alphabetical',
        label: 'alphabetical',
        enabled: true
      }, {
        id: 'dateCreated',
        label: 'created date',
        enabled: true
      }, {
        id: 'lastEdited',
        label: 'last modified',
        enabled: true
      }],
      quickFilters: [{
        id: 'configMatchDefault',
        checked: false,
        label: 'Configuration matches default',
        enabled: true
      }, {
        id: 'ownedByMe',
        checked: false,
        label: 'Owned by me',
        enabled: true
      }, {
        id: 'notOwnedByMe',
        checked: false,
        label: 'Not owned by me',
        enabled: true
      }],
      frameworkPropertiesApplySearchTo: [],
      competencyPropertiesApplySearchTo: [],
      otherPropertiesApplySearchTo: [],
      showQuickFilterHeading: true,
      frameworkConfig: null,
      configPropertiesToIgnore: ["@id", "headings", "primaryProperties", "secondaryProperties", "tertiaryProperties", "ctid"],
      searchTermsFromRawSchemata: {}
    };
  },
  mixins: [ctdlasnProfile["a" /* default */], tlaProfile["a" /* default */], cassUtil["a" /* cassUtil */]],
  computed: {
    sortBy: {
      get: function get() {
        return this.$store.getters['app/sortResults'];
      },
      set: function set(val) {
        this.$store.commit('app/sortResults', val);
      }
    },
    loggedIn: function loggedIn() {
      return EcIdentityManager.default.ids && EcIdentityManager.default.ids.length;
    },
    searchByOwnerNameEnabled: function searchByOwnerNameEnabled() {
      return this.$store.state.featuresEnabled.searchByOwnerNameEnabled;
    },
    initialOwnedByMe: function initialOwnedByMe() {
      return this.$store.state.featuresEnabled.ownedByMe;
    },
    configurationsEnabled: function configurationsEnabled() {
      return this.$store.state.featuresEnabled.configurationsEnabled;
    },
    queryParams: function queryParams() {
      return this.$store.getters['editor/queryParams'];
    },
    applySearchTo: function applySearchTo() {
      return this.frameworkPropertiesApplySearchTo.concat(this.competencyPropertiesApplySearchTo).concat(this.otherPropertiesApplySearchTo);
    },
    conceptMode: function conceptMode() {
      return this.$store.getters['editor/conceptMode'];
    },
    progressionMode: function progressionMode() {
      return this.$store.getters['editor/progressionMode'];
    },
    isFirstSearchProcessing: function isFirstSearchProcessing() {
      return this.$store.getters['editor/firstSearchProcessing'];
    }
  },
  mounted: function mounted() {
    if (!this.conceptMode && !this.progressionMode) {
      this.setSearchTermsFromRawSchemata();
      this.getFrameworkConfig();
      this.setOtherPropertiesApplySearchTo();
      this.setCompetencyPropertiesApplySearchTo();
    }
    if (!this.loggedIn) {
      for (var i = 0; i < this.quickFilters.length; i++) {
        if (this.quickFilters[i].id !== "configMatchDefault") {
          this.quickFilters[i].enabled = false;
        }
      }
    }
    if (this.loggedIn && this.initialOwnedByMe) {
      for (var i = 0; i < this.quickFilters.length; i++) {
        if (this.quickFilters[i].id === "ownedByMe") {
          this.quickFilters[i].checked = true;
        }
      }
    }
    if (this.conceptMode || this.progressionMode || !this.configurationsEnabled) {
      for (var i = 0; i < this.quickFilters.length; i++) {
        if (this.quickFilters[i].id === "configMatchDefault") {
          this.quickFilters[i].enabled = false;
        }
      }
    }
    var showFilters = false;
    for (var i = 0; i < this.quickFilters.length; i++) {
      if (this.quickFilters[i].enabled === true) {
        showFilters = true;
      }
    }
    this.showQuickFilterHeading = showFilters;
  },
  watch: {
    applySearchTo: {
      handler: function handler() {
        this.$store.commit('app/applySearchTo', this.applySearchTo);
      },
      deep: true
    },
    quickFilters: {
      handler: function handler() {
        appLog('watched');
        this.$store.commit('app/quickFilters', this.quickFilters);
      },
      deep: true
    },
    frameworkConfig: function frameworkConfig() {
      if (this.frameworkConfig) {
        this.setFrameworkPropertiesApplySearchTo();
      }
    }
  },
  methods: {
    getFrameworkConfig: function () {
      var _getFrameworkConfig = Object(asyncToGenerator["a" /* default */])(/*#__PURE__*/Object(regenerator["a" /* default */])().m(function _callee() {
        var c, me;
        return Object(regenerator["a" /* default */])().w(function (_context) {
          while (1) switch (_context.n) {
            case 0:
              if (!(this.queryParams.ceasnDataFields === "true")) {
                _context.n = 1;
                break;
              }
              this.frameworkConfig = this.ctdlAsnFrameworkProfile;
              _context.n = 5;
              break;
            case 1:
              if (!(this.queryParams.tlaProfile === "true")) {
                _context.n = 2;
                break;
              }
              this.frameworkConfig = this.tlaFrameworkProfile;
              _context.n = 5;
              break;
            case 2:
              if (!(this.getDefaultBrowserConfigId() && !this.getDefaultBrowserConfigId().trim().equals(''))) {
                _context.n = 4;
                break;
              }
              _context.n = 3;
              return EcRepository.get(this.getDefaultBrowserConfigId());
            case 3:
              c = _context.v;
              this.frameworkConfig = c.frameworkConfig;
              _context.n = 5;
              break;
            case 4:
              me = this;
              window.repo.searchWithParams("@type:Configuration", {
                'size': 10000
              }, null, function (ca) {
                var found = false;
                var _iterator = Object(createForOfIteratorHelper["a" /* default */])(ca),
                  _step;
                try {
                  for (_iterator.s(); !(_step = _iterator.n()).done;) {
                    var _c = _step.value;
                    if (_c.isDefault === "true" || _c.isDefault === true) {
                      me.frameworkConfig = _c.frameworkConfig;
                      found = true;
                      break;
                    }
                  }
                } catch (err) {
                  _iterator.e(err);
                } finally {
                  _iterator.f();
                }
                if (!found) {
                  me.setDefaultFrameworkSearchTerms();
                }
              }, function () {
                me.setDefaultFrameworkSearchTerms();
              });
            case 5:
              return _context.a(2);
          }
        }, _callee, this);
      }));
      function getFrameworkConfig() {
        return _getFrameworkConfig.apply(this, arguments);
      }
      return getFrameworkConfig;
    }(),
    setFrameworkPropertiesApplySearchTo: function setFrameworkPropertiesApplySearchTo() {
      var keys = EcObject.keys(this.frameworkConfig);
      var properties = [];
      var _iterator2 = Object(createForOfIteratorHelper["a" /* default */])(keys),
        _step2;
      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var prop = _step2.value;
          if (EcArray.has(this.configPropertiesToIgnore, prop)) {
            continue;
          }
          if (this.frameworkConfig[prop]["http://schema.org/rangeIncludes"][0]["@id"] !== "http://www.w3.org/2000/01/rdf-schema#langString" && this.frameworkConfig[prop]["http://schema.org/rangeIncludes"][0]["@id"] !== "http://schema.org/Text") {
            continue;
          }
          var label = this.frameworkConfig[prop]["http://www.w3.org/2000/01/rdf-schema#label"][0]["@value"];
          var id = "";
          if (prop === "http://schema.org/name") {
            id = "frameworkName";
          } else if (prop === "http://schema.org/description") {
            id = "frameworkDescription";
          } else {
            id = this.getSearchTermForProperty(prop);
          }
          properties.push({
            id: id,
            checked: false,
            label: label,
            enabled: true
          });
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }
      this.frameworkPropertiesApplySearchTo = properties;
    },
    setSearchTermsFromRawSchemata: function setSearchTermsFromRawSchemata() {
      // Used to figure out prefixes to use when searching from the full property URL in the configuration
      var context = this.$store.state.lode.rawSchemata["https://schema.cassproject.org/0.4"]["@context"];
      var keys = EcObject.keys(context);
      var _iterator3 = Object(createForOfIteratorHelper["a" /* default */])(keys),
        _step3;
      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var key = _step3.value;
          if (EcObject.isObject(context[key])) {
            continue;
          }
          this.searchTermsFromRawSchemata[context[key]] = key;
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    },
    getSearchTermForProperty: function getSearchTermForProperty(prop) {
      var keys = EcObject.keys(this.searchTermsFromRawSchemata);
      var shortProp;
      var _iterator4 = Object(createForOfIteratorHelper["a" /* default */])(keys),
        _step4;
      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var key = _step4.value;
          if (prop.indexOf(key) !== -1) {
            if (key === "https://schema.cassproject.org/0.4/") {
              shortProp = prop.replace(key, "");
            } else {
              shortProp = prop.replace(key, this.searchTermsFromRawSchemata[key] + "\\:");
            }
          }
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
      return shortProp;
    },
    setDefaultFrameworkSearchTerms: function setDefaultFrameworkSearchTerms() {
      this.frameworkPropertiesApplySearchTo = [{
        id: 'frameworkName',
        checked: false,
        label: 'Framework name',
        enabled: true
      }, {
        id: 'frameworkDescription',
        checked: false,
        label: 'Framework description',
        enabled: true
      }];
    },
    setOtherPropertiesApplySearchTo: function setOtherPropertiesApplySearchTo() {
      this.otherPropertiesApplySearchTo = [{
        id: 'directoryName',
        checked: false,
        label: 'Directory name',
        enabled: true
      }, {
        id: 'directoryDescription',
        checked: false,
        label: 'Directory description',
        enabled: true
      }];
      if (this.searchByOwnerNameEnabled) {
        this.otherPropertiesApplySearchTo.push({
          id: 'ownerName',
          checked: false,
          label: 'Owner name',
          enabled: true
        });
      }
    },
    setCompetencyPropertiesApplySearchTo: function setCompetencyPropertiesApplySearchTo() {
      if (this.queryParams.ceasnDataFields === 'true') {
        this.competencyPropertiesApplySearchTo = [{
          id: 'competencyLabel',
          checked: false,
          label: 'Competency label',
          enabled: true
        }, {
          id: 'competencyName',
          checked: false,
          label: 'Competency text',
          enabled: true
        }, {
          id: 'competencyDescription',
          checked: false,
          label: 'Competency comment',
          enabled: true
        }];
      } else {
        this.competencyPropertiesApplySearchTo = [{
          id: 'competencyName',
          checked: false,
          label: 'Competency name',
          enabled: true
        }, {
          id: 'competencyDescription',
          checked: false,
          label: 'Competency description',
          enabled: true
        }];
      }
    }
  }
});
// CONCATENATED MODULE: ./src/components/frameworks/FilterAndSort.vue?vue&type=script&lang=js
 /* harmony default export */ var frameworks_FilterAndSortvue_type_script_lang_js = (FilterAndSortvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/frameworks/FilterAndSort.vue?vue&type=style&index=0&id=e134a7f8&prod&lang=scss
var FilterAndSortvue_type_style_index_0_id_e134a7f8_prod_lang_scss = __webpack_require__("3109");

// CONCATENATED MODULE: ./src/components/frameworks/FilterAndSort.vue






/* normalize component */

var FilterAndSort_component = Object(componentNormalizer["a" /* default */])(
  frameworks_FilterAndSortvue_type_script_lang_js,
  FilterAndSortvue_type_template_id_e134a7f8_render,
  FilterAndSortvue_type_template_id_e134a7f8_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var FilterAndSort = (FilterAndSort_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/framework/RightAside.vue?vue&type=script&lang=js




/* harmony default export */ var RightAsidevue_type_script_lang_js = ({
  name: 'RightAside',
  props: {},
  data: function data() {
    return {
      isCommenter: true,
      isAdmin: false,
      isViewer: true
    };
  },
  components: {
    Comments: Comments,
    Versions: Versions,
    FilterAndSort: FilterAndSort,
    ListItemInfo: ListItemInfo
  },
  computed: {
    showRightAside: function showRightAside() {
      return this.$store.getters['app/showRightAside'];
    },
    rightAsideContent: function rightAsideContent() {
      return this.$store.getters['app/rightAsideContent'];
    }
  }
});
// CONCATENATED MODULE: ./src/components/framework/RightAside.vue?vue&type=script&lang=js
 /* harmony default export */ var framework_RightAsidevue_type_script_lang_js = (RightAsidevue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/components/framework/RightAside.vue?vue&type=style&index=0&id=10c69596&prod&lang=scss&scoped=true
var RightAsidevue_type_style_index_0_id_10c69596_prod_lang_scss_scoped_true = __webpack_require__("3486");

// CONCATENATED MODULE: ./src/components/framework/RightAside.vue






/* normalize component */

var RightAside_component = Object(componentNormalizer["a" /* default */])(
  framework_RightAsidevue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  "10c69596",
  null
  
)

/* harmony default export */ var RightAside = __webpack_exports__["default"] = (RightAside_component.exports);

/***/ }),

/***/ "fb6a7":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);
//# sourceMappingURL=chunk-4f51c21e.4d7b7bf3.js.map