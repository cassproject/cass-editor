(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login"],{

/***/ "1175":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_style_index_0_id_49008fc0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3b81");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_style_index_0_id_49008fc0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_style_index_0_id_49008fc0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "35d4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LegacyLogin_vue_vue_type_style_index_0_id_7abac5eb_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("be9a");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LegacyLogin_vue_vue_type_style_index_0_id_7abac5eb_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_LegacyLogin_vue_vue_type_style_index_0_id_7abac5eb_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "3b81":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "50b5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"c0ad154e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/CreateAccount.vue?vue&type=template&id=46e202d0&scoped=true
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "section is-large",
    attrs: {
      "id": "createAccount"
    }
  }, [_c('div', {
    staticClass: "modal",
    class: [{
      'is-active': _vm.createAccountBusy
    }]
  }, [_c('div', {
    staticClass: "modal-background"
  }), _vm._m(0)]), !_vm.createAccountBusy && !_vm.userCreated && !_vm.createUserServerError ? _c('div', {
    staticClass: "modal is-active"
  }, [_c('div', {
    staticClass: "modal-card"
  }, [_vm._m(1), _c('section', {
    staticClass: "modal-card-body"
  }, [_c('div', {
    staticClass: "section"
  }, [_c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("first name")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputFirstName,
      expression: "inputFirstName"
    }],
    staticClass: "input",
    attrs: {
      "type": "text "
    },
    domProps: {
      "value": _vm.inputFirstName
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputFirstName = $event.target.value;
      }
    }
  })])]), _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("last name")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputLastName,
      expression: "inputLastName"
    }],
    staticClass: "input",
    attrs: {
      "type": "text "
    },
    domProps: {
      "value": _vm.inputLastName
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputLastName = $event.target.value;
      }
    }
  })])]), _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("email")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputEmail,
      expression: "inputEmail"
    }],
    staticClass: "input",
    attrs: {
      "type": "text "
    },
    domProps: {
      "value": _vm.inputEmail
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputEmail = $event.target.value;
      }
    }
  })])]), _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("username")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputUserName,
      expression: "inputUserName"
    }],
    staticClass: "input",
    attrs: {
      "type": "text"
    },
    domProps: {
      "value": _vm.inputUserName
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputUserName = $event.target.value;
      }
    }
  })])]), _c('div', {
    staticClass: "field is-grouped"
  }, [_c('div', {
    staticClass: "control is-expanded"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("password")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputPassword,
      expression: "inputPassword"
    }],
    staticClass: "input",
    attrs: {
      "type": "password"
    },
    domProps: {
      "value": _vm.inputPassword
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputPassword = $event.target.value;
      }
    }
  })]), _c('div', {
    staticClass: "control is-expanded"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("confirm password")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.inputPasswordConfirm,
      expression: "inputPasswordConfirm"
    }],
    staticClass: "input",
    attrs: {
      "type": "password"
    },
    domProps: {
      "value": _vm.inputPasswordConfirm
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.inputPasswordConfirm = $event.target.value;
      }
    }
  })])])]), _vm.createAccountInvalid ? _c('div', {
    staticClass: "field has-text-danger"
  }, [_c('div', {
    staticClass: "label has-text-danger"
  }, [_vm._v(" Please correct the following errors: ")]), _vm.usernameInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Username is required ")]) : _vm._e(), _vm.passwordInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Password is required ")]) : _vm._e(), _vm.passwordMismatch ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Passwords do not match ")]) : _vm._e(), _vm.firstNameInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" First Name is required ")]) : _vm._e(), _vm.lastNameInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Last Name is required ")]) : _vm._e(), _vm.emailInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Valid email is required ")]) : _vm._e(), _vm.emailUnavailable ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" That email is unavailable ")]) : _vm._e(), _vm.usernameUnavailable ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" That username is unavailable ")]) : _vm._e()]) : _vm._e()]), _c('footer', {
    staticClass: "modal-card-foot has-background-white"
  }, [_c('div', {
    staticClass: "buttons is-spaced"
  }, [_c('div', {
    staticClass: "button is-dark is-outlined",
    on: {
      "click": _vm.goToLogin
    }
  }, [_vm._m(2), _c('span', [_vm._v("cancel")])]), _c('div', {
    staticClass: "button is-dark is-primary",
    on: {
      "click": _vm.attemptAccountCreate
    }
  }, [_vm._m(3), _c('span', [_vm._v("create")])])])])])]) : _vm._e(), !_vm.createAccountBusy && _vm.userCreated ? _c('div', {
    staticClass: "modal is-active"
  }, [_c('div', {
    staticClass: "modal-card"
  }, [_vm._m(4), _vm._m(5), _c('footer', {
    staticClass: "modal-card-foot has-background-white"
  }, [_c('div', {
    staticClass: "buttons is-spaced"
  }, [_c('div', {
    staticClass: "button is-dark is-outlined",
    on: {
      "click": _vm.goToLogin
    }
  }, [_vm._m(6), _c('span', [_vm._v("ok")])])])])])]) : _vm._e(), !_vm.createAccountBusy && _vm.createUserServerError ? _c('div', {
    staticClass: "modal is-active"
  }, [_c('div', {
    staticClass: "modal-card"
  }, [_vm._m(7), _vm._m(8), _c('footer', {
    staticClass: "modal-card-foot has-background-white"
  }, [_c('div', {
    staticClass: "buttons is-spaced"
  }, [_c('div', {
    staticClass: "button is-dark is-outlined",
    on: {
      "click": _vm.goToLogin
    }
  }, [_vm._m(9), _c('span', [_vm._v("ok")])])])])])]) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "modal-content has-text-centered"
  }, [_c('span', {
    staticClass: "icon is-large has-text-center has-text-link"
  }, [_c('i', {
    staticClass: "fas fa-2x fa-spinner is-info fa-pulse"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('header', {
    staticClass: "modal-card-head has-text-centered has-background-primary"
  }, [_c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Create CaSS Account ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-times"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-sign-in-alt"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('header', {
    staticClass: "modal-card-head has-text-centered has-background-success"
  }, [_c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Account Created ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('section', {
    staticClass: "modal-card-body"
  }, [_c('p', [_vm._v("Your account has been successfully created. Please return to the login screen.")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-times"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('header', {
    staticClass: "modal-card-head has-text-centered has-background-danger"
  }, [_c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Could Not Create Account ")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('section', {
    staticClass: "modal-card-body"
  }, [_c('p', [_vm._v("There was an error when attempting to create your account. Please contact the system administrator.")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-times"
  })]);
}];

// CONCATENATED MODULE: ./src/views/login/CreateAccount.vue?vue&type=template&id=46e202d0&scoped=true

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js
var createForOfIteratorHelper = __webpack_require__("b85c");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__("14d9");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.trim.js
var es_string_trim = __webpack_require__("498a");

// EXTERNAL MODULE: ./src/mixins/cassApi.js
var cassApi = __webpack_require__("f3d2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/CreateAccount.vue?vue&type=script&lang=js








/* harmony default export */ var CreateAccountvue_type_script_lang_js = ({
  name: 'CreateAccount',
  mixins: [cassApi["a" /* cassApi */]],
  data: function data() {
    return {
      PERSON_SEARCH_SIZE: 10000,
      createAccountBusy: false,
      createAccountInvalid: false,
      inputFirstName: '',
      inputLastName: '',
      inputUserName: '',
      inputEmail: '',
      inputPassword: '',
      inputPasswordConfirm: '',
      usernameInvalid: false,
      usernameUnavailable: false,
      passwordInvalid: false,
      passwordMismatch: false,
      firstNameInvalid: false,
      lastNameInvalid: false,
      emailInvalid: false,
      emailUnavailable: false,
      ecRemoteIdentMgr: null,
      userCreated: false,
      createUserServerError: false
    };
  },
  methods: {
    setAllNewAccountValidationsChecksToValid: function setAllNewAccountValidationsChecksToValid() {
      this.createAccountInvalid = false;
      this.usernameInvalid = false;
      this.usernameUnavailable = false;
      this.passwordInvalid = false;
      this.passwordMismatch = false;
      this.firstNameInvalid = false;
      this.lastNameInvalid = false;
      this.emailInvalid = false;
      this.emailUnavailable = false;
    },
    isValidEmail: function isValidEmail(email) {
      var re = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/igm;
      if (re.test(email)) return true;
      return false;
    },
    validateNewAccountData: function validateNewAccountData() {
      if (!this.inputUserName || this.inputUserName.trim().equals('')) {
        this.createAccountInvalid = true;
        this.usernameInvalid = true;
      }
      if (!this.inputPassword || this.inputPassword.trim().equals('') || !this.inputPasswordConfirm || this.inputPasswordConfirm.trim().equals('')) {
        this.createAccountInvalid = true;
        this.passwordInvalid = true;
      } else if (!this.inputPassword.equals(this.inputPasswordConfirm)) {
        this.createAccountInvalid = true;
        this.passwordMismatch = true;
      }
      if (!this.inputFirstName || this.inputFirstName.trim().equals('')) {
        this.createAccountInvalid = true;
        this.firstNameInvalid = true;
      }
      if (!this.inputLastName || this.inputLastName.trim().equals('')) {
        this.createAccountInvalid = true;
        this.lastNameInvalid = true;
      }
      if (!this.inputEmail || this.inputEmail.trim().equals('') || !this.isValidEmail(this.inputEmail)) {
        this.createAccountInvalid = true;
        this.emailInvalid = true;
      }
    },
    checkCreateUserRequestStatus: function checkCreateUserRequestStatus(createUserResponse) {
      if (createUserResponse.status === 409) {
        this.createAccountInvalid = true;
        this.usernameUnavailable = true;
        this.createUserServerError = false;
        this.userCreated = false;
      } else if (createUserResponse.status === 503) {
        this.createUserServerError = true;
        this.userCreated = false;
      } else if (createUserResponse.status === 200) {
        this.createUserServerError = false;
        this.userCreated = true;
      } else {
        appLog('Unexpected create user response status: ' + createUserResponse.status);
      }
      this.createAccountBusy = false;
    },
    buildUserInfoObject: function buildUserInfoObject() {
      var userInfo = {};
      userInfo.firstName = this.inputFirstName;
      userInfo.lastName = this.inputLastName;
      userInfo.username = this.inputUserName;
      userInfo.password = this.inputPassword;
      userInfo.email = this.inputEmail;
      return userInfo;
    },
    performAccountCreation: function performAccountCreation() {
      this.performCreateUser(this.buildUserInfoObject(), this.checkCreateUserRequestStatus);
    },
    handleCheckUsernameFetchIdentitySuccess: function handleCheckUsernameFetchIdentitySuccess(obj) {
      this.createAccountInvalid = true;
      this.usernameUnavailable = true;
      this.createAccountBusy = false;
      EcIdentityManager.default.clearIdentities();
      EcIdentityManager.default.clearContacts();
    },
    handleCheckUsernameFetchIdentityFailure: function handleCheckUsernameFetchIdentityFailure(failMsg) {
      if (failMsg && String(failMsg).toLowerCase().includes('user does not exist.')) {
        this.performAccountCreation();
      } else {
        this.createAccountInvalid = true;
        this.usernameUnavailable = true;
        this.createAccountBusy = false;
        EcIdentityManager.default.clearIdentities();
        EcIdentityManager.default.clearContacts();
      }
    },
    handleCheckUsernameConfigureFromServerSuccess: function handleCheckUsernameConfigureFromServerSuccess(obj) {
      appLog("Fetching identity for username check...");
      // Creates the hashes for storage and retrieval of keys.
      this.ecRemoteIdentMgr.startLogin(this.inputUserName, this.inputPassword);
      // Retrieves the identities and encryption keys from the server.
      this.ecRemoteIdentMgr.fetch(this.handleCheckUsernameFetchIdentitySuccess, this.handleCheckUsernameFetchIdentityFailure);
    },
    handleCheckUsernameConfigureFromServerFail: function handleCheckUsernameConfigureFromServerFail(failMsg) {
      this.createAccountBusy = false;
      appLog('New account configure from server for username check failure: ' + failMsg);
    },
    checkForExistingUsername: function checkForExistingUsername() {
      appLog("Check if new account username already exists");
      this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
      this.ecRemoteIdentMgr.server = window.repo.selectedServer;
      // Retrieves username and password salts from the serve
      this.ecRemoteIdentMgr.configureFromServer(this.handleCheckUsernameConfigureFromServerSuccess, this.handleCheckUsernameConfigureFromServerFail);
    },
    searchPersonsForNewAccountSuccess: function searchPersonsForNewAccountSuccess(ecRemoteLda) {
      appLog("New account person search success: ");
      appLog(ecRemoteLda);
      var emailExists = false;
      var _iterator = Object(createForOfIteratorHelper["a" /* default */])(ecRemoteLda),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var ecrld = _step.value;
          var ep = new EcPerson();
          ep.copyFrom(ecrld);
          if (this.inputEmail.equalsIgnoreCase(ep.email)) {
            emailExists = true;
            break;
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
      if (emailExists) {
        this.createAccountInvalid = true;
        this.emailUnavailable = true;
        this.createAccountBusy = false;
      } else this.checkForExistingUsername();
    },
    searchPersonsForNewAccountFailure: function searchPersonsForNewAccountFailure(msg) {
      // Search fails if the index doesn't exist yet.
      this.checkForExistingUsername();
    },
    verifyEmailAddressForNewAccountAndGo: function verifyEmailAddressForNewAccountAndGo() {
      this.createAccountBusy = true;
      var paramObj = {};
      paramObj.size = this.PERSON_SEARCH_SIZE;
      window.repo.searchWithParams("@type:Person AND email:\"" + this.inputEmail + "\"", paramObj, null, this.searchPersonsForNewAccountSuccess, this.searchPersonsForNewAccountFailure);
    },
    attemptAccountCreate: function attemptAccountCreate() {
      this.setAllNewAccountValidationsChecksToValid();
      this.validateNewAccountData();
      if (!this.createAccountInvalid) this.verifyEmailAddressForNewAccountAndGo();
    },
    goToLogin: function goToLogin() {
      this.createAccountBusy = false;
      this.$router.push({
        path: '/login'
      });
    }
  },
  mounted: function mounted() {}
});
// CONCATENATED MODULE: ./src/views/login/CreateAccount.vue?vue&type=script&lang=js
 /* harmony default export */ var login_CreateAccountvue_type_script_lang_js = (CreateAccountvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/views/login/CreateAccount.vue?vue&type=style&index=0&id=46e202d0&prod&lang=scss&scoped=true
var CreateAccountvue_type_style_index_0_id_46e202d0_prod_lang_scss_scoped_true = __webpack_require__("fa1d");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/views/login/CreateAccount.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  login_CreateAccountvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  "46e202d0",
  null
  
)

/* harmony default export */ var CreateAccount = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "be9a":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "d492":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"c0ad154e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/LegacyLogin.vue?vue&type=template&id=7abac5eb&scoped=true
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "section is-large",
    attrs: {
      "id": "login"
    }
  }, [_c('div', {
    staticClass: "modal",
    class: [{
      'is-active': _vm.loginBusy
    }]
  }, [_c('div', {
    staticClass: "modal-background"
  }), _vm._m(0)]), !_vm.loginBusy ? _c('div', {
    staticClass: "modal is-active"
  }, [_c('div', {
    staticClass: "modal-card"
  }, [!_vm.loginBusy ? _c('header', {
    staticClass: "modal-card-head has-text-centered has-background-primary"
  }, [_vm.amJustLoggingIn ? _c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Login to CaSS Authoring Tool ")]) : _vm._e(), _vm.amCreatingAccount ? _c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Create CaSS Authoring Tool User ")]) : _vm._e(), _vm.amCreatingLinkedPerson ? _c('h4', {
    staticClass: "title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Link User Information ")]) : _vm._e()]) : _vm._e(), _c('section', {
    staticClass: "modal-card-body"
  }, [_vm.amCreatingLinkedPerson ? _c('div', {
    staticClass: "section"
  }, [_vm.amCreatingLinkedPerson ? _c('p', [_vm._v(" No matching user record could be found that matched your login information. Please provide the following: ")]) : _vm._e()]) : _vm._e(), _vm.amJustLoggingIn ? _c('div', {
    staticClass: "section"
  }, [_c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("Username")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.username,
      expression: "username"
    }],
    staticClass: "input",
    attrs: {
      "type": "text",
      "placeholder": "username"
    },
    domProps: {
      "value": _vm.username
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.username = $event.target.value;
      }
    }
  })])]), _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("Password")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.password,
      expression: "password"
    }],
    staticClass: "input",
    attrs: {
      "type": "password",
      "placeholder": "password"
    },
    domProps: {
      "value": _vm.password
    },
    on: {
      "keyup": function keyup($event) {
        if (!$event.type.indexOf('key') && _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")) return null;
        return _vm.attemptCassLogin.apply(null, arguments);
      },
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.password = $event.target.value;
      }
    }
  })])])]) : _vm._e(), _c('div', {
    staticClass: "section"
  }, [_vm.amCreatingAccount || _vm.amCreatingLinkedPerson ? _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("name")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.createLinkPersonName,
      expression: "createLinkPersonName"
    }],
    staticClass: "input",
    attrs: {
      "type": "text "
    },
    domProps: {
      "value": _vm.createLinkPersonName
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.createLinkPersonName = $event.target.value;
      }
    }
  })])]) : _vm._e(), _vm.amCreatingAccount || _vm.amCreatingLinkedPerson ? _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("email")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.createLinkPersonEmail,
      expression: "createLinkPersonEmail"
    }],
    staticClass: "input",
    attrs: {
      "type": "text "
    },
    domProps: {
      "value": _vm.createLinkPersonEmail
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.createLinkPersonEmail = $event.target.value;
      }
    }
  })])]) : _vm._e(), _vm.amCreatingAccount ? _c('div', {
    staticClass: "field"
  }, [_c('div', {
    staticClass: "control"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("username")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.createAccountUsername,
      expression: "createAccountUsername"
    }],
    staticClass: "input",
    attrs: {
      "type": "text"
    },
    domProps: {
      "value": _vm.createAccountUsername
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.createAccountUsername = $event.target.value;
      }
    }
  })])]) : _vm._e(), _vm.amCreatingAccount ? _c('div', {
    staticClass: "field is-grouped"
  }, [_c('div', {
    staticClass: "control is-expanded"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("password")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.createAccountPassword,
      expression: "createAccountPassword"
    }],
    staticClass: "input",
    attrs: {
      "type": "password"
    },
    domProps: {
      "value": _vm.createAccountPassword
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.createAccountPassword = $event.target.value;
      }
    }
  })]), _c('div', {
    staticClass: "control is-expanded"
  }, [_c('label', {
    staticClass: "label"
  }, [_vm._v("Confirm password")]), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: _vm.createAccountPasswordRetype,
      expression: "createAccountPasswordRetype"
    }],
    staticClass: "input",
    attrs: {
      "type": "password"
    },
    domProps: {
      "value": _vm.createAccountPasswordRetype
    },
    on: {
      "input": function input($event) {
        if ($event.target.composing) return;
        _vm.createAccountPasswordRetype = $event.target.value;
      }
    }
  })])]) : _vm._e()]), _vm.createAccountOrLinkPersonDataInvalid ? _c('div', {
    staticClass: "field has-text-danger"
  }, [_c('div', {
    staticClass: "label has-text-danger"
  }, [_vm._v(" Please correct the following errors: ")]), _vm.createAccountUsernameInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Username is required ")]) : _vm._e(), _vm.createAccountPasswordInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Password is required ")]) : _vm._e(), _vm.createAccountPasswordMismatch ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Passwords do not match ")]) : _vm._e(), _vm.createLinkPersonNameInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Name is required ")]) : _vm._e(), _vm.createLinkPersonEmailInvalid ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" Valid email is required ")]) : _vm._e(), _vm.createLinkPersonEmailExists ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" That email is already in use ")]) : _vm._e(), _vm.createAccountUsernameUnavailable ? _c('div', {
    staticClass: "is-size-6"
  }, [_vm._v(" That username is unavailable ")]) : _vm._e()]) : _vm._e(), _vm.identityFetchFailed || _vm.configRetrieveFailed || _vm.loginParamsInvalid ? _c('div', {
    staticClass: "section"
  }, [_vm.identityFetchFailed ? _c('div', [_c('p', [_c('b', [_vm._v("Login failed: " + _vm._s(_vm.identityFailMsg))])])]) : _vm._e(), _vm.configRetrieveFailed ? _c('div', [_c('p', [_c('b', [_vm._v("Could not retrieve configuration from selected server: " + _vm._s(_vm.configFailMsg))])])]) : _vm._e(), _vm.loginParamsInvalid ? _c('div', [_vm._m(1)]) : _vm._e()]) : _vm._e()]), _c('footer', {
    staticClass: "modal-card-foot has-background-white"
  }, [_c('div', {
    staticClass: "buttons is-spaced"
  }, [_vm.amCreatingLinkedPerson || _vm.amCreatingAccount ? _c('div', {
    staticClass: "button is-dark is-outlined",
    on: {
      "click": function click($event) {
        return _vm.setDataToBaseLogin(true);
      }
    }
  }, [_vm._m(2), _c('span', [_vm._v("cancel")])]) : _vm._e(), _vm.amJustLoggingIn ? [!_vm.apiLoginEnabled ? _c('div', {
    staticClass: "button is-outlined is-dark",
    on: {
      "click": _vm.showCreateAccount
    }
  }, [_vm._m(3), _c('span', [_vm._v("create account")])]) : _vm._e(), _c('div', {
    staticClass: "button is-outlined is-primary",
    on: {
      "click": _vm.attemptCassLogin
    }
  }, [_vm._m(4), _c('span', [_vm._v("login")])])] : _vm._e(), _vm.amCreatingAccount ? _c('div', {
    staticClass: "button is-expanded is-primary is-outlined",
    on: {
      "click": _vm.createNewAccount
    }
  }, [_vm._m(5), _c('span', [_vm._v("create")])]) : _vm._e(), _vm.amCreatingLinkedPerson ? _c('div', {
    staticClass: "button is-success is-outlined",
    on: {
      "click": _vm.linkPerson
    }
  }, [_vm._m(6), _c('span', [_vm._v("update")])]) : _vm._e()], 2)]), _vm.apiLoginEnabled ? _c('div', {
    staticClass: "has-text-centered"
  }, [_c('a', {
    on: {
      "click": _vm.goToStandardLogin
    }
  }, [_vm._v("Return to Standard Login")])]) : _vm._e()])]) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "modal-content has-text-centered"
  }, [_c('span', {
    staticClass: "icon is-large has-text-center has-text-link"
  }, [_c('i', {
    staticClass: "fas fa-2x fa-spinner is-info fa-pulse"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('p', [_c('b', [_vm._v("Login failed: Invalid Username/Password")])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-times"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-plus"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-sign-in-alt"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-sign-in-alt"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-sign-in-alt"
  })]);
}];

// CONCATENATED MODULE: ./src/views/login/LegacyLogin.vue?vue&type=template&id=7abac5eb&scoped=true

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js
var createForOfIteratorHelper = __webpack_require__("b85c");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js
var regeneratorRuntime = __webpack_require__("c7eb");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("1da1");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__("14d9");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__("841c");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.trim.js
var es_string_trim = __webpack_require__("498a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/LegacyLogin.vue?vue&type=script&lang=js











/* harmony default export */ var LegacyLoginvue_type_script_lang_js = ({
  name: 'LegacyLogin',
  data: function data() {
    return {
      GROUP_SEARCH_SIZE: 10000,
      PERSON_SEARCH_SIZE: 10000,
      username: '',
      password: '',
      createAccountUsername: '',
      createAccountPassword: '',
      createAccountPasswordRetype: '',
      createLinkPersonName: '',
      createLinkPersonEmail: '',
      loginParamsInvalid: false,
      identityFetchFailed: false,
      configRetrieveFailed: false,
      loginBusy: false,
      ecRemoteIdentMgr: {},
      configFailMsg: '',
      identityFailMsg: '',
      amJustLoggingIn: true,
      amCreatingAccount: false,
      amCreatingLinkedPerson: false,
      createAccountOrLinkPersonDataInvalid: false,
      createAccountUsernameInvalid: false,
      createAccountPasswordInvalid: false,
      createAccountPasswordMismatch: false,
      createLinkPersonNameInvalid: false,
      createLinkPersonEmailInvalid: false,
      createLinkPersonEmailExists: false,
      createAccountUsernameUnavailable: false,
      identityToLinkToPerson: {},
      linkedPerson: {}
    };
  },
  methods: {
    goToStandardLogin: function goToStandardLogin() {
      this.loginBusy = false;
      this.$router.push({
        path: '/login'
      });
    },
    goToAppHome: function goToAppHome() {
      this.loginBusy = false;
      this.$router.push({
        path: '/frameworks'
      });
    },
    addGroupIdentity: function addGroupIdentity(group) {
      return Object(asyncToGenerator["a" /* default */])( /*#__PURE__*/Object(regeneratorRuntime["a" /* default */])().mark(function _callee() {
        var groupPpkSet, i, gPpk, grpIdent;
        return Object(regeneratorRuntime["a" /* default */])().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return group.getOrgKeys();
            case 3:
              groupPpkSet = _context.sent;
              appLog("Adding group identities: " + "(" + group.shortId() + ") - " + group.getName() + " - (" + groupPpkSet.length + ") keys");
              for (i = 0; i < groupPpkSet.length; i++) {
                gPpk = groupPpkSet[i];
                grpIdent = new EcIdentity();
                grpIdent.displayName = group.getName() + " - key[" + i + "]";
                grpIdent.ppk = gPpk;
                EcIdentityManager.default.addIdentityQuietly(grpIdent);
              }
              _context.next = 10;
              break;
            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](0);
            case 10:
            case "end":
              return _context.stop();
          }
        }, _callee, null, [[0, 8]]);
      }))();
    },
    searchRepositoryForGroupsSuccess: function searchRepositoryForGroupsSuccess(ecoa) {
      var linkedPersonShortId = this.linkedPerson.shortId();
      if (ecoa && ecoa.length > 0) {
        var _iterator = Object(createForOfIteratorHelper["a" /* default */])(ecoa),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var eco = _step.value;
            if (eco.employee && eco.employee.length > 0) {
              var _iterator2 = Object(createForOfIteratorHelper["a" /* default */])(eco.employee),
                _step2;
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var e = _step2.value;
                  if (e.equals(linkedPersonShortId)) {
                    this.addGroupIdentity(eco);
                    break;
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
    },
    searchRepositoryForGroupsFailure: function searchRepositoryForGroupsFailure(msg) {
      appLog("Group search failure: " + msg);
      this.goToAppHome();
    },
    addGroupIdentities: function addGroupIdentities() {
      appLog(" Adding group identities...");
      var paramObj = {};
      paramObj.size = this.GROUP_SEARCH_SIZE;
      EcOrganization.search(window.repo, '', this.searchRepositoryForGroupsSuccess, this.searchRepositoryForGroupsFailure, paramObj);
      this.goToAppHome();
    },
    setDataToBaseLogin: function setDataToBaseLogin(clearIdentityManager) {
      this.username = '';
      this.password = '';
      this.createAccountUsername = '';
      this.createAccountPassword = '';
      this.createAccountPasswordRetype = '';
      this.createLinkPersonName = '';
      this.createLinkPersonEmail = '';
      this.loginParamsInvalid = false;
      this.identityFetchFailed = false;
      this.configRetrieveFailed = false;
      this.configFailMsg = "";
      this.identityFailMsg = "";
      this.amCreatingAccount = false;
      this.amCreatingLinkedPerson = false;
      this.createAccountOrLinkPersonDataInvalid = false;
      this.createAccountUsernameInvalid = false;
      this.createAccountPasswordInvalid = false;
      this.createAccountPasswordMismatch = false;
      this.createLinkPersonNameInvalid = false;
      this.createLinkPersonEmailInvalid = false;
      this.createLinkPersonEmailExists = false;
      this.createAccountUsernameUnavailable = false;
      if (clearIdentityManager) {
        this.ecRemoteIdentMgr = {};
        EcIdentityManager.default.clearContacts();
        EcIdentityManager.default.clearIdentities();
        this.identityToLinkToPerson = {};
        this.linkedPerson = {};
      }
      this.amJustLoggingIn = true;
      this.loginBusy = false;
    },
    showCreateAccount: function showCreateAccount() {
      this.setDataToBaseLogin(true);
      this.amJustLoggingIn = false;
      this.amCreatingAccount = true;
    },
    showCreateLinkedPerson: function showCreateLinkedPerson() {
      this.setDataToBaseLogin(false);
      this.amJustLoggingIn = false;
      this.amCreatingLinkedPerson = true;
    },
    setAllNewAccountValidationsChecksToValid: function setAllNewAccountValidationsChecksToValid() {
      this.createAccountOrLinkPersonDataInvalid = false;
      this.createAccountUsernameInvalid = false;
      this.createAccountPasswordInvalid = false;
      this.createAccountPasswordMismatch = false;
      this.createLinkPersonNameInvalid = false;
      this.createLinkPersonEmailInvalid = false;
      this.createLinkPersonEmailExists = false;
      this.createAccountUsernameUnavailable = false;
    },
    isValidEmail: function isValidEmail(email) {
      var re = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/igm;
      if (re.test(email)) return true;
      return false;
    },
    validateNewAccountData: function validateNewAccountData() {
      if (!this.createAccountUsername || this.createAccountUsername.trim().equals('')) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createAccountUsernameInvalid = true;
      }
      if (!this.createAccountPassword || this.createAccountPassword.trim().equals('') || !this.createAccountPasswordRetype || this.createAccountPasswordRetype.trim().equals('')) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createAccountPasswordInvalid = true;
      } else if (!this.createAccountPassword.equals(this.createAccountPasswordRetype)) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createAccountPasswordMismatch = true;
      }
      this.validateLinkPersonData();
    },
    handleCreatePersonSuccess: function handleCreatePersonSuccess() {
      appLog("Person created.");
      if (this.amCreatingAccount) {
        this.goToAppHome();
      } else this.addGroupIdentities();
    },
    createPersonObjectToLinkToIdentity: function createPersonObjectToLinkToIdentity() {
      appLog("Creating person object for identity...");
      var p = new EcPerson();
      p.assignId(window.repo.selectedServer, this.identityToLinkToPerson.ppk.toPk().fingerprint());
      p.addOwner(this.identityToLinkToPerson.ppk.toPk());
      p.name = this.createLinkPersonName;
      p.email = this.createLinkPersonEmail;
      appLog(p);
      this.$store.commit('user/loggedOnPerson', p);
      this.linkedPerson = p;
      EcRepository.save(p, this.handleCreatePersonSuccess, this.handleAttemptLoginFetchIdentityFailure);
    },
    handleCreateAccountFetchIdentitySuccess: function handleCreateAccountFetchIdentitySuccess() {
      appLog("Creating new account identity object...");
      var ident = new EcIdentity();
      ident.displayName = this.createLinkPersonName;
      ident.ppk = EcPpk.generateKey();
      EcIdentityManager.default.addIdentity(ident);
      EcIdentityManager.default.saveContacts();
      EcIdentityManager.default.saveIdentities();
      this.identityToLinkToPerson = ident;
      this.ecRemoteIdentMgr.commit(this.createPersonObjectToLinkToIdentity, this.handleAttemptLoginFetchIdentityFailure);
    },
    handleCreateAccountRemoteIdentityMgrCreateSuccess: function handleCreateAccountRemoteIdentityMgrCreateSuccess() {
      appLog("Creating new account manager fetch...");
      this.ecRemoteIdentMgr.fetch(this.handleCreateAccountFetchIdentitySuccess, this.handleAttemptLoginFetchIdentityFailure);
    },
    handleCreateAccountConfigureFromServerSuccess: function handleCreateAccountConfigureFromServerSuccess(obj) {
      appLog("EcRemoteIdentityManager creating...");
      appLog("Creating new account login...");
      this.ecRemoteIdentMgr.startLogin(this.createAccountUsername, this.createAccountPassword);
      this.ecRemoteIdentMgr.create(this.handleCreateAccountRemoteIdentityMgrCreateSuccess, this.handleAttemptLoginFetchIdentityFailure);
    },
    createNewAccountIdentityAndPerson: function createNewAccountIdentityAndPerson() {
      appLog("Creating new account...");
      appLog("EcRemoteIdentityManager Configuring from server...");
      this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
      this.ecRemoteIdentMgr.server = window.repo.selectedServer;
      this.ecRemoteIdentMgr.configureFromServer(this.handleCreateAccountConfigureFromServerSuccess, this.handleAttemptLoginConfigureFromServerFail);
    },
    handleCheckUsernameFetchIdentitySuccess: function handleCheckUsernameFetchIdentitySuccess(obj) {
      appLog('handleCheckUsernameFetchIdentitySuccess !!!!');
      this.createAccountOrLinkPersonDataInvalid = true;
      this.createAccountUsernameUnavailable = true;
      this.loginBusy = false;
      EcIdentityManager.default.clearIdentities();
      EcIdentityManager.default.clearContacts();
    },
    handleCheckUsernameFetchIdentityFailure: function handleCheckUsernameFetchIdentityFailure(failMsg) {
      appLog('handleCheckUsernameFetchIdentityFailure: ' + failMsg);
      if (failMsg && failMsg.toString().toLowerCase().indexOf('user does not exist') !== -1) {
        this.createNewAccountIdentityAndPerson();
      } else {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createAccountUsernameUnavailable = true;
        this.loginBusy = false;
        EcIdentityManager.default.clearIdentities();
        EcIdentityManager.default.clearContacts();
      }
    },
    handleCheckUsernameConfigureFromServerSuccess: function handleCheckUsernameConfigureFromServerSuccess(obj) {
      appLog("Fetching identity for username check...");
      this.ecRemoteIdentMgr.startLogin(this.createAccountUsername, this.createAccountPassword); // Creates the hashes for storage and retrieval of keys.
      this.ecRemoteIdentMgr.fetch(this.handleCheckUsernameFetchIdentitySuccess, this.handleCheckUsernameFetchIdentityFailure); // Retrieves the identities and encryption keys from the server.
    },
    handleCheckUsernameConfigureFromServerFail: function handleCheckUsernameConfigureFromServerFail(failMsg) {
      this.loginBusy = false;
      appLog('New account configure from server for username check failure: ' + msg);
    },
    checkForExistingUsername: function checkForExistingUsername() {
      appLog("Check if new account username already exists");
      this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
      this.ecRemoteIdentMgr.server = window.repo.selectedServer;
      this.ecRemoteIdentMgr.configureFromServer(this.handleCheckUsernameConfigureFromServerSuccess, this.handleCheckUsernameConfigureFromServerFail); // Retrieves username and password salts from the serve
    },
    searchPersonsForNewAccountSuccess: function searchPersonsForNewAccountSuccess(ecRemoteLda) {
      appLog("New account person search success: ");
      appLog(ecRemoteLda);
      var emailExists = false;
      var _iterator3 = Object(createForOfIteratorHelper["a" /* default */])(ecRemoteLda),
        _step3;
      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var ecrld = _step3.value;
          var ep = new EcPerson();
          ep.copyFrom(ecrld);
          if (this.createLinkPersonEmail.equalsIgnoreCase(ep.email)) {
            emailExists = true;
            break;
          }
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
      if (emailExists) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createLinkPersonEmailExists = true;
        this.loginBusy = false;
      } else {
        this.checkForExistingUsername();
        // this.createNewAccountIdentityAndPerson();
      }
    },
    searchPersonsForNewAccountFailure: function searchPersonsForNewAccountFailure(msg) {
      // Search fails if the index doesn't exist yet.
      this.checkForExistingUsername();
    },
    verifyEmailAddressForNewAccountAndGo: function verifyEmailAddressForNewAccountAndGo() {
      this.loginBusy = true;
      var paramObj = {};
      paramObj.size = this.PERSON_SEARCH_SIZE;
      window.repo.searchWithParams("@type:Person AND email:\"" + this.createLinkPersonEmail + "\"", paramObj, null, this.searchPersonsForNewAccountSuccess, this.searchPersonsForNewAccountFailure);
    },
    createNewAccount: function createNewAccount() {
      this.setAllNewAccountValidationsChecksToValid();
      this.validateNewAccountData();
      if (!this.createAccountOrLinkPersonDataInvalid) this.verifyEmailAddressForNewAccountAndGo();
    },
    validateLinkPersonData: function validateLinkPersonData() {
      if (!this.createLinkPersonName || this.createLinkPersonName.trim().equals('')) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createLinkPersonNameInvalid = true;
      }
      if (!this.createLinkPersonEmail || this.createLinkPersonEmail.trim().equals('') || !this.isValidEmail(this.createLinkPersonEmail)) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createLinkPersonEmailInvalid = true;
      }
    },
    searchPersonsForLinkPersonSuccess: function searchPersonsForLinkPersonSuccess(ecRemoteLda) {
      this.loginBusy = true;
      var emailExists = false;
      var _iterator4 = Object(createForOfIteratorHelper["a" /* default */])(ecRemoteLda),
        _step4;
      try {
        for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
          var ecrld = _step4.value;
          var ep = new EcPerson();
          ep.copyFrom(ecrld);
          if (this.createLinkPersonEmail.equalsIgnoreCase(ep.email)) {
            emailExists = true;
            break;
          }
        }
      } catch (err) {
        _iterator4.e(err);
      } finally {
        _iterator4.f();
      }
      if (emailExists) {
        this.createAccountOrLinkPersonDataInvalid = true;
        this.createLinkPersonEmailExists = true;
        this.loginBusy = false;
      } else {
        this.createPersonObjectToLinkToIdentity();
      }
    },
    verifyEmailAddressForLinkPersonAndGo: function verifyEmailAddressForLinkPersonAndGo() {
      appLog('Validating link person email...');
      var paramObj = {};
      paramObj.size = this.PERSON_SEARCH_SIZE;
      window.repo.searchWithParams("@type:Person AND email:\"" + this.createLinkPersonEmail + "\"", paramObj, null, this.searchPersonsForLinkPersonSuccess, this.searchPersonsForNewAccountFailure);
    },
    linkPerson: function linkPerson() {
      this.setAllNewAccountValidationsChecksToValid();
      this.validateLinkPersonData();
      if (!this.createAccountOrLinkPersonDataInvalid) this.verifyEmailAddressForLinkPersonAndGo();
    },
    areLoginParamsValid: function areLoginParamsValid() {
      if (this.username == null || this.username.length === 0 || this.password == null || this.password.length === 0) {
        this.loginParamsInvalid = true;
        return false;
      }
      return true;
    },
    findLinkedPersonPersonSearchSuccess: function findLinkedPersonPersonSearchSuccess(ecRemoteLda) {
      appLog("Linked person person search success: ");
      appLog(ecRemoteLda);
      this.identityToLinkToPerson = EcIdentityManager.default.ids[0];
      var matchingPersonRecordFound = false;
      var _iterator5 = Object(createForOfIteratorHelper["a" /* default */])(ecRemoteLda),
        _step5;
      try {
        for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
          var ecrld = _step5.value;
          var ep = new EcPerson();
          ep.copyFrom(ecrld);
          if (ep.getGuid().equals(this.identityToLinkToPerson.ppk.toPk().fingerprint())) {
            matchingPersonRecordFound = true;
            this.$store.commit('user/loggedOnPerson', ep);
            this.linkedPerson = ep;
            appLog('Matching person record found: ');
            appLog(ep);
            EcIdentityManager.default.saveContacts();
            EcIdentityManager.default.saveIdentities();
          }
        }
      } catch (err) {
        _iterator5.e(err);
      } finally {
        _iterator5.f();
      }
      if (matchingPersonRecordFound) this.addGroupIdentities();else {
        appLog('Matching person record NOT found');
        this.showCreateLinkedPerson();
      }
    },
    findLinkedPersonPersonSearchFailure: function findLinkedPersonPersonSearchFailure(msg) {
      this.loginBusy = false;
      appLog('Linked person person search failure: ' + msg);
    },
    findLinkedPersonForIdentity: function findLinkedPersonForIdentity() {
      appLog("Finding linked person for identity...");
      var identFingerprint = EcIdentityManager.default.ids[0].ppk.toPk().fingerprint();
      var paramObj = {};
      paramObj.size = this.PERSON_SEARCH_SIZE;
      window.repo.searchWithParams("@type:Person AND @id:\"" + identFingerprint + "\"", paramObj, null, this.findLinkedPersonPersonSearchSuccess, this.findLinkedPersonPersonSearchFailure);
    },
    handleAttemptLoginFetchIdentitySuccess: function handleAttemptLoginFetchIdentitySuccess(obj) {
      if (!EcIdentityManager.default.ids || EcIdentityManager.default.ids.length <= 0) {
        this.handleAttemptLoginFetchIdentityFailure('Login credentials valid but no identity could be found.');
      } else this.findLinkedPersonForIdentity();
    },
    handleAttemptLoginFetchIdentityFailure: function handleAttemptLoginFetchIdentityFailure(failMsg) {
      appError(failMsg);
      this.identityFailMsg = failMsg;
      this.identityFetchFailed = true;
      this.loginBusy = false;
    },
    handleAttemptLoginConfigureFromServerSuccess: function () {
      var _handleAttemptLoginConfigureFromServerSuccess = Object(asyncToGenerator["a" /* default */])( /*#__PURE__*/Object(regeneratorRuntime["a" /* default */])().mark(function _callee2(obj) {
        var _this = this;
        return Object(regeneratorRuntime["a" /* default */])().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              appLog("Fetching identity...");
              this.ecRemoteIdentMgr.startLogin(this.username, this.password); // Creates the hashes for storage and retrieval of keys.
              _context2.next = 4;
              return this.ecRemoteIdentMgr.fetch(null, this.handleAttemptLoginFetchIdentityFailure).then(function (ident) {
                if (ident) {
                  EcIdentityManager.default = ident;
                  _this.handleAttemptLoginFetchIdentitySuccess();
                }
              });
            case 4:
            case "end":
              return _context2.stop();
          }
        }, _callee2, this);
      }));
      function handleAttemptLoginConfigureFromServerSuccess(_x) {
        return _handleAttemptLoginConfigureFromServerSuccess.apply(this, arguments);
      }
      return handleAttemptLoginConfigureFromServerSuccess;
    }(),
    handleAttemptLoginConfigureFromServerFail: function handleAttemptLoginConfigureFromServerFail(failMsg) {
      this.configFailMsg = failMsg;
      this.configRetrieveFailed = true;
      this.loginBusy = false;
    },
    attemptCassLogin: function attemptCassLogin() {
      this.loginParamsInvalid = false;
      this.identityFetchFailed = false;
      this.configRetrieveFailed = false;
      if (this.areLoginParamsValid()) {
        appLog("Attempting CaSS login....");
        this.loginBusy = true;
        EcIdentityManager.default.clearContacts();
        EcIdentityManager.default.clearIdentities();
        this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
        this.ecRemoteIdentMgr.server = window.repo.selectedServer;
        this.ecRemoteIdentMgr.configureFromServer(this.handleAttemptLoginConfigureFromServerSuccess, this.handleAttemptLoginConfigureFromServerFail); // Retrieves username and password salts from the serve
      }
    }
  },
  computed: {
    legacyLoginEnabled: function legacyLoginEnabled() {
      return this.$store.getters['featuresEnabled/legacyLoginEnabled'];
    },
    apiLoginEnabled: function apiLoginEnabled() {
      return this.$store.getters['featuresEnabled/apiLoginEnabled'];
    }
  },
  mounted: function mounted() {
    this.setDataToBaseLogin(true);
  }
});
// CONCATENATED MODULE: ./src/views/login/LegacyLogin.vue?vue&type=script&lang=js
 /* harmony default export */ var login_LegacyLoginvue_type_script_lang_js = (LegacyLoginvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/views/login/LegacyLogin.vue?vue&type=style&index=0&id=7abac5eb&prod&lang=scss&scoped=true
var LegacyLoginvue_type_style_index_0_id_7abac5eb_prod_lang_scss_scoped_true = __webpack_require__("35d4");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/views/login/LegacyLogin.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  login_LegacyLoginvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  "7abac5eb",
  null
  
)

/* harmony default export */ var LegacyLogin = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "eba8":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ede4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"c0ad154e-vue-loader-template"}!./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/loaders/templateLoader.js??ref--7!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/Login.vue?vue&type=template&id=49008fc0&scoped=true
var render = function render() {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "section is-large",
    attrs: {
      "id": "login"
    }
  }, [_c('div', {
    staticClass: "modal",
    class: [{
      'is-active': _vm.loginBusy
    }]
  }, [_c('div', {
    staticClass: "modal-background"
  }), _vm._m(0)]), !_vm.loginBusy ? _c('div', {
    staticClass: "modal is-active"
  }, [_c('div', {
    staticClass: "modal-card"
  }, [!_vm.loginBusy ? _c('header', {
    staticClass: "modal-card-head has-text-centered has-background-primary"
  }, [_c('h3', {
    staticClass: "modal-card-title is-size-2 has-text-centered has-text-white"
  }, [_vm._v(" Login to CaSS ")])]) : _vm._e(), _c('section', {
    staticClass: "modal-card-body"
  }, [_c('div', {
    staticClass: "columns is-mobile is-multiline"
  }, [_c('div', {
    staticClass: "column is-6"
  }, [_c('div', {
    staticClass: "section box py-2 px-2"
  }, [_c('div', {
    staticClass: "modal-card-body has-text-centered"
  }, [_c('div', {
    staticClass: "button is-outlined is-primary",
    on: {
      "click": _vm.attemptExternalCassLogin
    }
  }, [_vm._m(1), _c('span', [_vm._v("login")])])])])]), _c('div', {
    staticClass: "column is-6"
  }, [_c('div', {
    staticClass: "section box py-2 px-2"
  }, [_c('div', {
    staticClass: "modal-card-body has-text-centered"
  }, [_c('div', {
    staticClass: "button is-outlined is-dark",
    on: {
      "click": _vm.goToCreateAccount
    }
  }, [_vm._m(2), _c('span', [_vm._v("create account")])])])])]), _vm.identityFetchFailed || _vm.configRetrieveFailed || _vm.loginParamsInvalid ? _c('div', {
    staticClass: "column is-12"
  }, [_c('div', {
    staticClass: "panel is-warning py-2 px-2 has-text-danger"
  }, [_c('p', {
    staticClass: "panel-heading"
  }, [_vm._v(" Login failed ")]), _vm.identityFetchFailed ? _c('div', {
    staticClass: "panel-block"
  }, [_c('p', [_vm._v("Could not fetch identity: " + _vm._s(_vm.identityFailMsg))])]) : _vm._e(), _vm.configRetrieveFailed ? _c('div', {
    staticClass: "panel-block"
  }, [_c('p', [_vm._v("Could not retrieve configuration from selected server: " + _vm._s(_vm.configFailMsg))])]) : _vm._e(), _vm.loginParamsInvalid ? _c('div', {
    staticClass: "panel-block"
  }, [_c('p', [_vm._v("Login failed: Invalid Username/Password")])]) : _vm._e()])]) : _vm._e(), _vm.legacyLoginEnabled ? _c('div', {
    staticClass: "column is-12 pt-4"
  }, [_c('div', {
    staticClass: "section box p-2 has-text-centered"
  }, [_c('i', {
    staticClass: "fas fa-exclamation-circle"
  }), _vm._v(" For accounts created in CaSS "), _c('b', [_vm._v("1.3 and earlier")]), _vm._v(": "), _c('a', {
    on: {
      "click": _vm.goToLegacyLogin
    }
  }, [_vm._v("Legacy Login")])])]) : _vm._e()])])])]) : _vm._e()]);
};
var staticRenderFns = [function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('div', {
    staticClass: "modal-content has-text-centered"
  }, [_c('span', {
    staticClass: "icon is-large has-text-center has-text-link"
  }, [_c('i', {
    staticClass: "fas fa-2x fa-spinner is-info fa-pulse"
  })])]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-sign-in-alt"
  })]);
}, function () {
  var _vm = this,
    _c = _vm._self._c;
  return _c('span', {
    staticClass: "icon"
  }, [_c('i', {
    staticClass: "fa fa-plus"
  })]);
}];

// CONCATENATED MODULE: ./src/views/login/Login.vue?vue&type=template&id=49008fc0&scoped=true

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js
var createForOfIteratorHelper = __webpack_require__("b85c");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/regeneratorRuntime.js
var regeneratorRuntime = __webpack_require__("c7eb");

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("1da1");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.push.js
var es_array_push = __webpack_require__("14d9");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__("841c");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.trim.js
var es_string_trim = __webpack_require__("498a");

// EXTERNAL MODULE: ./src/mixins/cassApi.js
var cassApi = __webpack_require__("f3d2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--13-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/views/login/Login.vue?vue&type=script&lang=js









/* harmony default export */ var Loginvue_type_script_lang_js = ({
  name: 'Login',
  mixins: [cassApi["a" /* cassApi */]],
  data: function data() {
    return {
      GROUP_SEARCH_SIZE: 10000,
      PERSON_SEARCH_SIZE: 10000,
      loginBusy: false,
      ecRemoteIdentMgr: null,
      identityFetchFailed: false,
      configRetrieveFailed: false,
      loginParamsInvalid: false,
      identityFailMsg: '',
      configFailMsg: '',
      loginCredentials: null,
      identityToLinkToPerson: null,
      linkedPerson: null
    };
  },
  methods: {
    forceLogout: function forceLogout() {
      this.redirectToExternalLogout();
    },
    goToAppHome: function goToAppHome() {
      this.loginBusy = false;
      this.$router.push({
        path: '/frameworks'
      });
    },
    goToLegacyLogin: function goToLegacyLogin() {
      this.loginBusy = false;
      this.loginCredentials = null;
      this.identityToLinkToPerson = null;
      this.$router.push({
        path: '/legacyLogin'
      });
    },
    goToCreateAccount: function goToCreateAccount() {
      this.loginBusy = false;
      this.loginCredentials = null;
      this.identityToLinkToPerson = null;
      this.$router.push({
        path: '/createAccount'
      });
    },
    addGroupIdentity: function () {
      var _addGroupIdentity = Object(asyncToGenerator["a" /* default */])( /*#__PURE__*/Object(regeneratorRuntime["a" /* default */])().mark(function _callee(group) {
        var groupPpkSet, i, gPpk, grpIdent;
        return Object(regeneratorRuntime["a" /* default */])().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return group.getOrgKeys();
            case 3:
              groupPpkSet = _context.sent;
              appLog("Adding group identities: " + "(" + group.shortId() + ") - " + group.getName() + " - (" + groupPpkSet.length + ") keys");
              for (i = 0; i < groupPpkSet.length; i++) {
                gPpk = groupPpkSet[i];
                grpIdent = new EcIdentity();
                grpIdent.displayName = group.getName() + " - key[" + i + "]";
                grpIdent.ppk = gPpk;
                EcIdentityManager.default.addIdentityQuietly(grpIdent);
              }
              _context.next = 10;
              break;
            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](0);
            case 10:
            case "end":
              return _context.stop();
          }
        }, _callee, null, [[0, 8]]);
      }));
      function addGroupIdentity(_x) {
        return _addGroupIdentity.apply(this, arguments);
      }
      return addGroupIdentity;
    }(),
    searchRepositoryForGroupsSuccess: function searchRepositoryForGroupsSuccess(ecoa) {
      var linkedPersonShortId = this.linkedPerson.shortId();
      if (ecoa && ecoa.length > 0) {
        var _iterator = Object(createForOfIteratorHelper["a" /* default */])(ecoa),
          _step;
        try {
          for (_iterator.s(); !(_step = _iterator.n()).done;) {
            var eco = _step.value;
            if (eco.employee && eco.employee.length > 0) {
              var _iterator2 = Object(createForOfIteratorHelper["a" /* default */])(eco.employee),
                _step2;
              try {
                for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                  var e = _step2.value;
                  if (!EcObject.isObject(e) && e.equals(linkedPersonShortId)) {
                    this.addGroupIdentity(eco);
                    break;
                  }
                }
              } catch (err) {
                _iterator2.e(err);
              } finally {
                _iterator2.f();
              }
            }
          }
        } catch (err) {
          _iterator.e(err);
        } finally {
          _iterator.f();
        }
      }
      this.goToAppHome();
    },
    searchRepositoryForGroupsFailure: function searchRepositoryForGroupsFailure(msg) {
      appLog("Group search failure: " + msg);
      this.goToAppHome();
    },
    addGroupIdentities: function addGroupIdentities() {
      appLog("Finding assigned groups...");
      var paramObj = {};
      paramObj.size = this.GROUP_SEARCH_SIZE;
      EcOrganization.search(window.repo, '', this.searchRepositoryForGroupsSuccess, this.searchRepositoryForGroupsFailure, paramObj);
      // this.goToAppHome();
    },
    handleCreatePersonSuccess: function handleCreatePersonSuccess() {
      appLog("Person created.");
      this.addGroupIdentities();
    },
    createPersonObjectForIdentity: function createPersonObjectForIdentity() {
      appLog("Creating person object for identity...");
      var p = new EcPerson();
      p.assignId(window.repo.selectedServer, this.identityToLinkToPerson.ppk.toPk().fingerprint());
      p.addOwner(this.identityToLinkToPerson.ppk.toPk());
      p.name = this.loginCredentials.name;
      p.email = this.loginCredentials.email;
      this.$store.commit('user/loggedOnPerson', p);
      this.linkedPerson = p;
      EcRepository.save(p, this.handleCreatePersonSuccess, this.handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck);
    },
    findLinkedPersonPersonSearchSuccess: function findLinkedPersonPersonSearchSuccess(ecRemoteLda) {
      if (!EcArray.isArray(ecRemoteLda)) {
        ecRemoteLda = [ecRemoteLda];
      }
      appLog("Linked person person search success: ");
      appLog(ecRemoteLda);
      this.identityToLinkToPerson = EcIdentityManager.default.ids[0];
      var matchingPersonRecordFound = false;
      var _iterator3 = Object(createForOfIteratorHelper["a" /* default */])(ecRemoteLda),
        _step3;
      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var ecrld = _step3.value;
          var ep = new EcPerson();
          ep.copyFrom(ecrld);
          if (ep.getGuid().equals(this.identityToLinkToPerson.ppk.toPk().fingerprint())) {
            matchingPersonRecordFound = true;
            this.$store.commit('user/loggedOnPerson', ep);
            this.linkedPerson = ep;
            appLog('Matching person record found: ');
            appLog(ep);
            EcIdentityManager.default.saveContacts();
            EcIdentityManager.default.saveIdentities();
          }
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
      if (matchingPersonRecordFound) this.addGroupIdentities();else {
        appLog('Matching person record NOT found');
        this.createPersonObjectForIdentity();
      }
    },
    findLinkedPersonPersonSearchFailure: function findLinkedPersonPersonSearchFailure(msg) {
      this.loginBusy = false;
      appLog('Linked person person search failure: ' + msg);
    },
    findLinkedPersonForIdentity: function findLinkedPersonForIdentity() {
      appLog("Finding linked person for identity...");
      window.EcPerson.getByPk(window.repo, window.EcIdentityManager.default.ids[0].ppk.toPk(), this.findLinkedPersonPersonSearchSuccess, this.findLinkedPersonPersonSearchFailure);
    },
    handleCreateAccountFetchIdentitySuccess: function handleCreateAccountFetchIdentitySuccess() {
      appLog("Creating new account identity object...");
      var ident = new EcIdentity();
      ident.displayName = this.loginCredentials.name;
      ident.ppk = EcPpk.generateKey();
      EcIdentityManager.default.addIdentity(ident);
      EcIdentityManager.default.saveContacts();
      EcIdentityManager.default.saveIdentities();
      this.identityToLinkToPerson = ident;
      this.ecRemoteIdentMgr.commit(this.createPersonObjectForIdentity, this.handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck);
    },
    handleCreateAccountRemoteIdentityMgrCreateSuccess: function handleCreateAccountRemoteIdentityMgrCreateSuccess() {
      appLog("Creating new account manager fetch...");
      this.ecRemoteIdentMgr.fetch(this.handleCreateAccountFetchIdentitySuccess, this.handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck);
    },
    handleCreateAccountConfigureFromServerSuccess: function handleCreateAccountConfigureFromServerSuccess(obj) {
      appLog("Creating new account identity...");
      this.ecRemoteIdentMgr.startLogin(this.loginCredentials.username, this.loginCredentials.password);
      this.ecRemoteIdentMgr.create(this.handleCreateAccountRemoteIdentityMgrCreateSuccess, this.handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck);
    },
    createNewAccountIdentity: function createNewAccountIdentity() {
      appLog("Creating new account...");
      appLog("EcRemoteIdentityManager Configuring from server...");
      this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
      this.ecRemoteIdentMgr.server = window.repo.selectedServer;
      this.ecRemoteIdentMgr.configureFromServer(this.handleCreateAccountConfigureFromServerSuccess, this.handleAttemptLoginConfigureFromServerFail);
    },
    handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck: function handleAttemptLoginFetchIdentityFailureNoCreateAccountCheck(failMsg) {
      // this shouldn't happen, but don't want to cause an unexpected create loop
      this.identityFailMsg = failMsg;
      this.identityFetchFailed = true;
      this.loginBusy = false;
    },
    handleAttemptLoginFetchIdentitySuccess: function handleAttemptLoginFetchIdentitySuccess(obj) {
      if (!EcIdentityManager.default.ids || EcIdentityManager.default.ids.length <= 0) {
        this.handleAttemptLoginFetchIdentityFailure('Login credentials valid but no identity could be found.');
      } else this.findLinkedPersonForIdentity();
    },
    handleAttemptLoginFetchIdentityFailure: function handleAttemptLoginFetchIdentityFailure(failMsg) {
      if (failMsg && failMsg.toLowerCase().trim().equals('user does not exist.')) {
        this.createNewAccountIdentity();
      } else {
        this.identityFailMsg = failMsg;
        this.identityFetchFailed = true;
        this.loginBusy = false;
      }
    },
    handleAttemptLoginConfigureFromServerSuccess: function handleAttemptLoginConfigureFromServerSuccess(obj) {
      appLog("Fetching identity...");
      // Creates the hashes for storage and retrieval of keys.
      this.ecRemoteIdentMgr.startLogin(this.loginCredentials.username, this.loginCredentials.password);
      // Retrieves the identities and encryption keys from the server.
      this.ecRemoteIdentMgr.fetch(this.handleAttemptLoginFetchIdentitySuccess, this.handleAttemptLoginFetchIdentityFailure);
    },
    handleAttemptLoginConfigureFromServerFail: function handleAttemptLoginConfigureFromServerFail(failMsg) {
      this.configFailMsg = failMsg;
      this.configRetrieveFailed = true;
      this.loginBusy = false;
    },
    performInternalCassLogin: function performInternalCassLogin() {
      appLog("Attempting CaSS login....");
      this.loginBusy = true;
      this.identityToLinkToPerson = null;
      EcIdentityManager.default.clearContacts();
      EcIdentityManager.default.clearIdentities();
      this.ecRemoteIdentMgr = new EcRemoteIdentityManager();
      this.ecRemoteIdentMgr.server = window.repo.selectedServer;
      // Retrieve username and password salts from the server
      this.ecRemoteIdentMgr.configureFromServer(this.handleAttemptLoginConfigureFromServerSuccess, this.handleAttemptLoginConfigureFromServerFail);
    },
    attemptExternalCassLogin: function attemptExternalCassLogin() {
      this.redirectToExternalLoginPage();
    },
    handleUserProfileAlreadyLoaded: function handleUserProfileAlreadyLoaded(profileResponse) {
      var co = this.parseCredentialsFromProfileResponse(profileResponse);
      if (co.username && co.username.trim().length > 0 && co.password && co.password.trim().length > 0) {
        this.loginCredentials = co;
        this.performInternalCassLogin();
      } else {
        appLog("Unable to parse credentials from user profile response");
      }
    },
    checkUserProfileRequestStatus: function checkUserProfileRequestStatus(profileResponse) {
      if (profileResponse.status === 401) {
        this.loginBusy = false;
      } else if (profileResponse.status === 200) {
        this.handleUserProfileAlreadyLoaded(profileResponse);
      } else {
        appLog('Unexpected user profile response status: ' + profileResponse.status);
        this.loginBusy = false;
      }
    },
    checkLoginStatus: function checkLoginStatus() {
      this.loginBusy = true;
      this.getUserProfile(this.checkUserProfileRequestStatus);
    }
  },
  computed: {
    legacyLoginEnabled: function legacyLoginEnabled() {
      return this.$store.getters['featuresEnabled/legacyLoginEnabled'];
    },
    apiLoginEnabled: function apiLoginEnabled() {
      return this.$store.getters['featuresEnabled/apiLoginEnabled'];
    }
  },
  mounted: function mounted() {
    if (!this.apiLoginEnabled) this.goToLegacyLogin();else this.checkLoginStatus();
  }
});
// CONCATENATED MODULE: ./src/views/login/Login.vue?vue&type=script&lang=js
 /* harmony default export */ var login_Loginvue_type_script_lang_js = (Loginvue_type_script_lang_js); 
// EXTERNAL MODULE: ./src/views/login/Login.vue?vue&type=style&index=0&id=49008fc0&prod&lang=scss&scoped=true
var Loginvue_type_style_index_0_id_49008fc0_prod_lang_scss_scoped_true = __webpack_require__("1175");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/views/login/Login.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  login_Loginvue_type_script_lang_js,
  render,
  staticRenderFns,
  false,
  null,
  "49008fc0",
  null
  
)

/* harmony default export */ var Login = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "f3d2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cassApi; });
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("14d9");
/* harmony import */ var core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_push_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("b0c0");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9c4");
/* harmony import */ var core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_json_stringify_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("b64b");
/* harmony import */ var core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_keys_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("ddb0");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);












var cassApi = {
  name: 'cassApi',
  data: function data() {
    return {
      USER_PROFILE_SERVICE: "user/profile",
      USER_CREATE_SERVICE: "user",
      USER_LOGIN_SERVICE: "login",
      USER_LOGOUT_SERVICE: "logout",
      LOGOUT_REDIRECT_URL: window.location.origin + "/cass-editor/#/login"
    };
  },
  methods: {
    parseCredentialsFromProfileResponse: function parseCredentialsFromProfileResponse(profileResponse) {
      var pro = JSON.parse(profileResponse.responseText);
      var credentials = {};
      credentials.username = pro["preferred_username"];
      credentials.password = pro["cass_password"];
      if (pro["email"]) {
        credentials.email = pro["email"];
      } else {
        credentials.email = "n/a";
      }
      if (pro["name"]) {
        credentials.name = pro["name"];
      } else if (pro["given_name"] && pro["family_name"]) {
        credentials.name = pro["given_name"] + " " + pro["family_name"];
      } else {
        credentials.name = pro["preferred_username"];
      }
      return credentials;
    },
    performCreateUser: function performCreateUser(userInfo, responseCallback) {
      var oReq = new XMLHttpRequest();
      oReq.addEventListener("load", function (x) {
        return responseCallback(x.currentTarget);
      });
      oReq.withCredentials = true;
      var serviceEndpoint = this.cassApiLocation + this.USER_CREATE_SERVICE;
      oReq.open("POST", serviceEndpoint);
      oReq.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
      oReq.send(JSON.stringify({
        username: userInfo.username,
        password: userInfo.password,
        email: userInfo.email,
        firstName: userInfo.firstName,
        lastName: userInfo.lastName
      }));
    },
    getUserProfile: function getUserProfile(responseCallback) {
      var oReq = new XMLHttpRequest();
      oReq.addEventListener("load", function (x) {
        return responseCallback(x.currentTarget);
      });
      oReq.withCredentials = true;
      var serviceEndpoint = this.cassApiLocation + this.USER_PROFILE_SERVICE;
      oReq.open("GET", serviceEndpoint);
      oReq.send();
    },
    redirectToExternalLogin: function redirectToExternalLogin() {
      appLog("Redirecting to external login...");
      window.location = this.repositorySsoOptions.ssoLogin + "?redirectUrl=" + encodeURIComponent(window.location);
    },
    redirectToExternalLogout: function redirectToExternalLogout() {
      appLog("Redirecting to external logout...");
      window.location = this.repositorySsoOptions.ssoLogout + "?redirectUrl=" + encodeURIComponent(window.location);
    },
    goToLogin: function goToLogin() {
      if (this.apiLoginEnabled) {
        this.$router.push({
          path: '/login'
        });
      } else {
        this.$router.push({
          path: '/legacyLogin'
        });
      }
    },
    checkExternalLogoutStatus: function checkExternalLogoutStatus(logoutResponse) {
      if (logoutResponse.status !== 200) {
        appLog('Logout fired but returned an unexpected response code: ' + logoutResponse.status);
      }
      this.goToLogin();
    },
    performExternalLogout: function performExternalLogout() {
      var _this = this;
      appLog("Performing external logout...");
      var oReq = new XMLHttpRequest();
      oReq.addEventListener("load", function (x) {
        return _this.checkExternalLogoutStatus(x.currentTarget);
      });
      oReq.withCredentials = true;
      var serviceEndpoint = this.cassApiLocation + this.USER_LOGOUT_SERVICE;
      oReq.open("GET", serviceEndpoint);
      oReq.send();
    },
    performApplicationLogout: function performApplicationLogout() {
      appLog("Performing application logout...");
      EcIdentityManager.default.clearContacts();
      EcIdentityManager.default.clearIdentities();
      var clearPerson = {};
      this.$store.commit('user/loggedOnPerson', clearPerson);
      this.$store.commit('app/showModal', {
        component: 'LogoutSuccess'
      });
    },
    performApplicationLogin: function performApplicationLogin() {
      appLog("Performing application login...");
      EcIdentityManager.default.clearContacts();
      EcIdentityManager.default.clearIdentities();
      var clearPerson = {};
      this.$store.commit('user/loggedOnPerson', clearPerson);
      if (this.apiLoginEnabled) this.redirectToExternalLogin();else this.goToLogin();
    },
    addQueryParams: function addQueryParams() {
      var paramObj = this.$store.getters['editor/queryParams'];
      var keys = EcObject.keys(paramObj);
      if (paramObj && keys.length) {
        var toAdd = '?';
        for (var each in keys) {
          if (each !== 0) {
            toAdd += "&";
          }
          var key = keys[each];
          var val = paramObj[key];
          if (EcArray.isArray(val)) {
            for (var i in val) {
              if (i !== 0) {
                toAdd += "&";
              }
              toAdd += key + "=" + val[i];
            }
          } else {
            toAdd += key + "=" + val;
          }
        }
        return toAdd;
      } else {
        return '';
      }
    }
  },
  computed: {
    cassApiLocation: function cassApiLocation() {
      return this.$store.getters['environment/cassApiLocation'];
    },
    repositorySsoOptions: function repositorySsoOptions() {
      return this.$store.getters['user/repositorySsoOptions'];
    },
    apiLoginEnabled: function apiLoginEnabled() {
      return this.$store.getters['featuresEnabled/apiLoginEnabled'];
    }
  }
};

/***/ }),

/***/ "fa1d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateAccount_vue_vue_type_style_index_0_id_46e202d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eba8");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateAccount_vue_vue_type_style_index_0_id_46e202d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_9_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_9_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_9_oneOf_1_2_node_modules_sass_loader_dist_cjs_js_ref_9_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_CreateAccount_vue_vue_type_style_index_0_id_46e202d0_prod_lang_scss_scoped_true__WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ })

}]);
//# sourceMappingURL=login.753dbb68.js.map